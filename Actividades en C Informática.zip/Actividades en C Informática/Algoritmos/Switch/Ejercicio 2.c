#include <stdio.h>

int main() {
	float num1=0, num2=0, resultado=0;
	int operacion=0;
	printf("Ingrese 2 n�meros: \n");
	scanf("%f%f", &num1, &num2);
	printf("Elija un n�mero del 1 al 4 para realizar una operacion: \n");
	scanf("%d", &operacion);
	switch(operacion){
		case 1: resultado=num1+num2;
		printf(" %.2f + %.2f \n", num1, num2);
		printf("El resultado de la operaci�n es: ""%.2f", resultado);
		break;
		case 2: resultado=num1-num2;
		printf(" %.2f - %.2f \n", num1, num2);
		printf("El resultado de la operaci�n es: ""%.2f", resultado);
		break;
		case 3: resultado=num1*num2;
		printf(" %.2f * %.2f \n", num1, num2);
		printf("El resultado de la operaci�n es: ""%.2f", resultado);
		break;
		case 4: resultado=num1/num2;
		printf(" %.2f / %.2f \n", num1, num2);	
		printf("El resultado de la operaci�n es: ""%.2f", resultado);
		break;
	default: resultado=printf("N�mero de operaci�n no v�lido");
	}	
	return 0;
}

