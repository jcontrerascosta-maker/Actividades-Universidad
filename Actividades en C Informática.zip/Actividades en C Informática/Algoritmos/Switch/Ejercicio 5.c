#include <stdio.h>

int main() {
	float limite=0, nuevo_limite=0;
	int tipo=0;
	
	printf("Ponga el monto l�mite de su tarjeta: \n");
	scanf("%f", &limite);
	printf("Seleccione el tipo de tarjeta para calcular su nuevo l�mite: \n Tipo 1 \n Tipo 2 \n Tipo 3 \n Otro (ingrese el n�mero 4) \n");
	scanf("%d", &tipo);
	
	switch(tipo){
	case 1: nuevo_limite= limite + limite*0.25;
		printf("Su nuevo l�mite es: $""%.2f", nuevo_limite);
		break;
	case 2: nuevo_limite= limite + limite*0.35;
		printf("Su nuevo l�mite es: $""%.2f", nuevo_limite);
		break;
	case 3: nuevo_limite= limite + limite*0.40;
		printf("Su nuevo l�mite es: $""%.2f", nuevo_limite);
		break;
	case 4: nuevo_limite= limite + limite*0.50;
	printf("Su nuevo l�mite es: $""%.2f", nuevo_limite);
	break;
	
	default: printf("Opci�n no v�lida");
	}
	return 0;
}

