#include <stdio.h>

int main() {
	int dia=0;
	printf("Elija el d�a de la semana marcando un n�mero del 1 al 7 (la semana comienza el domingo) \n");
	scanf("%d", &dia);
	switch(dia){
		case 1: printf("Eligi� Domingo");
		break;
		case 2: printf("Eligi� Lunes");
		break;
		case 3: printf("Eligi� Martes");
		break;
		case 4: printf("Eligi� Mi�rcoles");
		break;
		case 5: printf("Eligi� Jueves");
		break;
		case 6: printf("Eligi� Viernes");
		break;
		case 7: printf("Eligi� S�bado");
		break;
		default: printf(".N�mero no v�lido");
	}
	return 0;
	
}

