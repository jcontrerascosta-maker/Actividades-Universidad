#include <stdio.h>

int main() {
	float peso=0, precio=0;
	int zona=0;
	printf("Ingrese el peso en gramos del producto que desea comprar para calcular el precio: \n");
	scanf("%f", &peso);
	printf("Ingrese el destino de env�o: \n 1)Am�rica del Norte y Central \n 2)Am�rica del sur \n 3)Europa \n 4)Asia \n");
	scanf("%d", &zona);
	
	switch(zona){
	case 1: precio=30*peso;
	printf("El precio de env�o hacia America del Norte y Central es: ""%.2f"" dolares", precio);
	break;
	case 2: precio=20*peso;
	printf("El precio de env�o hacia America del Sur: ""%.2f"" dolares", precio);
	break;
	case 3: precio=70*peso;
	printf("El precio de env�o hacia Europa es: ""%.2f"" dolares", precio);
	break;
	case 4: precio=100*peso;
	printf("El precio de env�o hacia Asia es: ""%.2f"" dolares", precio);
	break;
	default:printf("error");
	}
	return 0;
}
