#include <stdio.h>

int main() {
	char letra;
	printf("Ingrese una letra para luego calificarla en vocal o consonante: \n");
	scanf("%c", &letra);
	switch(letra){
	case 'A':printf("%c"" es una vocal \n", letra);
	break;
	case 'a':printf("%c"" es una vocal \n", letra);
	break;
	case 'E':printf("%c"" es una vocal \n", letra);
	break;
	case 'e':printf("%c"" es una vocal \n", letra);
	break;
	case 'I':printf("%c"" es una vocal \n", letra);
	break;
	case 'i':printf("%c"" es una vocal \n", letra);
	break;
	case 'O':printf("%c"" es una vocal \n", letra);
	break;
	case 'o':printf("%c"" es una vocal \n", letra);
	break;
	case 'U':printf("%c"" es una vocal \n", letra);
	break;
	case 'u':printf("%c"" es una vocal \n", letra);
	default:printf("%c"" es una consonante \n", letra);
	}
	return 0;
}

