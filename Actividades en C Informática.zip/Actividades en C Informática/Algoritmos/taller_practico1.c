//Joaquin Contreras Costa
#include <stdio.h>

int main(){
	//Definicioin de variables
	int num=0, pares=0, sumatoria=0, mayor=0, menor=99, cantidad=0;
	char opcion;
	
	//inicio del programa
	printf("Ingrese un numero entre 1 y 99 (ingrese 0 para salir del conteo):\n");
	do {
		scanf("%d", &num);
		if(num>=1 && num<=99){
			sumatoria += num;
			cantidad++;
			if (num==0 || num>mayor) {
				mayor=num;
			}
			if (num==0 || num<menor) {
				menor= num;
			}
			if (num %2==0) {
				pares++;
			}
		} else if (num!=0) {
			printf("N�mero fuera del rango v�lido. Por favor, ingresar un numero entre 1 y 99.\n");
		}
	} while (num!=0);
	
	// Men� de opciones
	do {
		printf("\nMen� de opciones:\n");
		printf("a. Sumatoria de todos los n�meros ingresados\n");
		printf("b. Cantidad de n�meros ingresados\n");
		printf("c. N�mero mayor y n�mero menor ingresado\n");
		printf("d. Cantidad de n�meros pares\n");
		printf("e. Salir\n");
		
		scanf(" %c", &opcion);
		
		switch (opcion) {
		case 'a':
			printf("Sumatoria de los n�meros ingresados: %d\n", sumatoria);
			break;
		case 'b':
			printf("Cantidad de n�meros ingresados: %d\n", cantidad);
			break;
		case 'c':
			printf("N�mero mayor ingresado: %d\n", mayor);
			printf("N�mero menor ingresado: %d\n", menor);
			break;
		case 'd':
			printf("Cantidad de n�meros pares: %d\n", pares);
			break;
		case 'e':
			break;
		default:
			printf("Opci�n inv�lida. Por favor, seleccione una opci�n v�lida.\n");
			break;
		}
	} while (opcion !='e');
	
	return 0;
}
