#include<stdio.h>
int main(){
	
	int opcion=1, compra=0;
	float peso=0, precio=459, subtotal=0, total=0, descuento=0; 
	while(opcion>=1 && opcion<=2){
		
		printf("\n\nMENU");
		printf("\n 1.- Comprar Manzanas.");
		printf("\n 2.- Ticket.");
		printf("\n 3.- Salir.");
		printf("\n\nIngrese una opci�n: ");
		scanf("%d", &opcion);
		
		switch(opcion){
			
		case 1:
			if(compra==0){
				printf("Ingrese la cantidad de kg a comprar: ");
				scanf("%f",&peso);
				compra=1;
				subtotal=peso*precio;
				if(peso>0 && peso<=2)
				{
					total=subtotal;
				}
				else if(peso>2&&peso<=5)
				{
					descuento=subtotal*0.10;
					total=subtotal-descuento;
				}else if(peso>5&&peso<=10){
					descuento=subtotal*0.20;
					total=subtotal-descuento;
					}else{
					descuento=subtotal*0.30;
					total=subtotal-descuento;
				}
			}
			else
			   printf("\n Hay una compra en proceso, elija la opci�n Ticket o Salir\n\n");
			break;
		case 2:
			printf("Total a pagar por %.2fKg: %.2f\n",peso, total);
			compra=0, peso=0;
			break;
		case 3:
			
			break;
		default:
			printf("\nOpci�n incorrecta");
			break;
		}
	}
	return 0;
}
	
