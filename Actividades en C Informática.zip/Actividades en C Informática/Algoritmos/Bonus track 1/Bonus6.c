#include <stdio.h>

int main() {
	int anio=0, mes=0, dias_en_mes=0, dmax=0, dmin=0;
	float temp_max= -1000, temp_min=1000, temp_sum=0, temp_promedio=0, temperatura=0;
	

	printf("Ingrese el a�o: ");
	scanf("%d", &anio);
	printf("Ingrese el mes (1-12): ");
	scanf("%d", &mes);
	
	switch (mes) {
	case 1: 
	case 3: 
	case 5: 
	case 7: 
	case 8: 
	case 10: 
	case 12:
		dias_en_mes = 31;
		break;
	case 4: 
	case 6:
	case 9: 
	case 11:
		dias_en_mes = 30;
		break;
	case 2:
		if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 400 == 0))
			dias_en_mes = 29;
		else
			dias_en_mes = 28;
		break;
	default:
		printf("Mes inv�lido.\n");
		return 1;
	}
	
	for(int dia_actual = 1; dia_actual <= dias_en_mes; dia_actual++){
		printf("\nIngrese las 4 temperaturas para el d�a %d:\n", dia_actual);
		for(int i = 0; i < 4; i++){ 
			scanf("%f", &temperatura);
			temp_sum += temperatura;
			if (temperatura > temp_max){
				temp_max = temperatura;
				dmax=dia_actual;
			}
			if (temperatura < temp_min){
				temp_min = temperatura;
				dmin=dia_actual;
			}
		}
	}
	
	temp_promedio = temp_sum / (dias_en_mes * 4);
	
	printf("\nTemperatura m�xima: %.2f el d�a %d\n", temp_max, dmax);
	printf("Temperatura m�nima: %.2f el d�a %d\n", temp_min, dmin);
	printf("Promedio de temperatura mensual: %.2f\n", temp_promedio);
	
	return 0;
}
