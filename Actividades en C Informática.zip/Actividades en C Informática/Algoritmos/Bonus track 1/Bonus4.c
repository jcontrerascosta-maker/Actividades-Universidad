#include <stdio.h>
	int main() {
	float temperatura=0, suma_temperaturas = 0, promedio=0;
	float maximo = 0, minimo = 0;
	int contar_menores_cero = 0, contar_mayores_cero = 0, contar_iguales_cero = 0, contar_temp=0;
	char opcion;
	
	printf("Ingrese las temperaturas (ingrese '100' para terminar la carga):\n");
	do {
		scanf("%f", &temperatura);
			if(temperatura!=100){
				suma_temperaturas += temperatura;
				contar_temp++;
				if(contar_temp==1){
					maximo = temperatura;
					minimo = temperatura;
				}else{
					if (temperatura > maximo)
						maximo = temperatura;
					if (temperatura < minimo)
						minimo = temperatura;
				}
				if (temperatura < 0)
					contar_menores_cero++;
				else if (temperatura > 0)
					contar_mayores_cero++;
				else
					contar_iguales_cero++;
			}
				
	} while (temperatura != 100);
	
	promedio = suma_temperaturas / contar_temp;
	
	do {
		printf("\n Men� de opciones\n");
		printf("1. Temperaturas m�xima y M�nima\n");
		printf("2. Promedio de temperaturas\n");
		printf("3. Cantidad de temperaturas menores a cero\n");
		printf("4. Cantidad de temperaturas mayores a cero\n");
		printf("5. Cantidad temperaturas iguales a cero\n");
		printf("6. Salir\n");
		printf("Ingrese la opci�n deseada: ");
		scanf(" %c", &opcion);
		
		switch (opcion) {
		case '1':
			printf("\nTemperatura m�xima: %.2f\n", maximo);
			printf("Temperatura m�nima: %.2f\n", minimo);
			break;
		case '2':
			printf("Promedio de temperaturas: %.2f\n", promedio);
			break;
		case '3':
			printf("Cantidad de temperaturas menores a cero: %d\n", contar_menores_cero);
			break;
		case '4':
			printf("Cantidad de temperaturas mayores a cero: %d\n", contar_mayores_cero);
			break;
		case '5':
			printf("Cantidad de temperaturas iguales a cero: %d\n", contar_iguales_cero);
			break;
		case '6':
			printf("Saliendo del programa...\n");
			break;
		default:
			printf("Opci�n inv�lida. Por favor, ingrese una opci�n v�lida.\n");
		}
	} while (opcion != '6');
	
	return 0;
}
