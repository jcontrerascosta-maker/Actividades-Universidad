#include <stdio.h>

int main() {
	int legajo=0, dia=0;
	float horas_semana=0, hora_entrada=0, hora_salida_almuerzo=0, hora_entrada_almuerzo=0, hora_salida=0, horas_diarias=0;;
	
	printf("Ingrese el n�mero de legajo: ");
	scanf("%d", &legajo);
	

	printf("\nHorarios de trabajo de lunes a viernes:\n");
	for (dia = 1; dia <= 5; dia++) {
		printf("\nD�a %d:\n", dia);
		printf("Hora de entrada: ");
		scanf("%f", &hora_entrada);
		printf("Hora de salida para almorzar: ");
		scanf("%f", &hora_salida_almuerzo);
		printf("Hora de reingreso: ");
		scanf("%f", &hora_entrada_almuerzo);
		printf("Hora de salida: ");
		scanf("%f", &hora_salida);
		
		horas_diarias = (hora_salida_almuerzo - hora_entrada) + (hora_salida - hora_entrada_almuerzo);
		horas_semana += horas_diarias;
	}
	
	printf("\n Numero de legajo: %d ", legajo);
	printf("\n Total de horas trabajadas en la semana: %.2f.\n", horas_semana);
	
	if (horas_semana < 40) {
		printf("Horas adeudadas en la semana: %.2f \n", 40 - horas_semana);
	} else if (horas_semana == 40) {
		printf("Ha cumplido con las 40 horas pactadas\n");
	} else {
		printf("Horas extras trabajadas en la semana: %.2f \n", horas_semana - 40);
	}
	
	return 0;
}
