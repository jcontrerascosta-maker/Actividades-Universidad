#include <stdio.h>

int main( ) {
	int num=0, i=0;
	printf("Ingrese un numero para realizar su tabla de multiplicar del 1 al 10\n");
	scanf("%d", &num);
	for(i=0; i<10; i++){
		printf("%d X %d = %d \n",(i+1),num,(i+1)*num);
	}
	return 0;
}

