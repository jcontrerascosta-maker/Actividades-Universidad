#include <stdio.h>

int main() {
	int cantidad_numero=0, numeroP=0, numeroN=0, numero=0;
	
	printf("Ingrese un numero positivo o negativo (para realizar el conteo de numeros ingrese 0): \n");
	scanf("%d", &numero);
	
	do{
		cantidad_numero++;
		if(numero>=0){
			numeroP++;
		}
		if(numero<=0){
			numeroN++;
		}
		printf("Ingrese un numero positivo o negativo: \n");
		scanf("%d", &numero);
	} while(numero!=0);
	printf("\nLa cantidad de numeros ingresados es: %d \n%d eran positivos \n%d eran negativos", cantidad_numero, numeroP, numeroN);
	return 0;
}

