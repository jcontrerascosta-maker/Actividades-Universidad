#include <stdio.h>

int main() {
int numero_ingresado=0, numero10=0; 


printf("Ingrese un número aleatorio: \n");
scanf("%d", &numero_ingresado);

while(numero_ingresado!=0){
    if(numero_ingresado==10){
    numero10=numero10+1;
    }
	printf("ingrese otro numero o salga con 0:");
	scanf("%d", &numero_ingresado);
}
printf("el numero 10 se repito %d veces:", numero10);
	return 0;
}
