#include <time.h>
#include <stdlib.h>
#include <stdio.h>

int main() {
	float temperatura=0, Tmax=0, Tmin=100, Tpromedio=0, suma=0;
	int i=0;
	srand(time(NULL)); 
	printf("Temperaturas: \n");
	for(i=0; i<24; i++){
		temperatura= rand() % 51;
		printf("%.2f \n",temperatura);
		suma=suma+temperatura;
		if(i==0){
			Tmax=temperatura;
			Tmin=temperatura;
		}else{
			if(temperatura>Tmax){
				Tmax=temperatura;
			}
			if(temperatura<Tmin){
				Tmin=temperatura;
			}
		}
	}
	Tpromedio=suma/24;
	printf("\n\nMax: %.2f Min: %.2f Promedio: %.2f ",Tmax, Tmin, Tpromedio);
	return 0;
}
