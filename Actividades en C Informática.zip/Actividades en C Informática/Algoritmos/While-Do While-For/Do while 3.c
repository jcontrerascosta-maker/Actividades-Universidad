#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
	int solucion=0, resultado=0, totalpreguntas=0, correctas=0, incorrectas=0, numero2=0, numero1=0;
	char seguir=' ';
	
	srand(time(NULL));
	do{
		numero1= rand() % 11;
		numero2= rand() % 11;
		solucion= numero1*numero2;
		printf("La operacion a realizar es %d x %d", numero1, numero2);
		printf("\nEl resultado es: ");
		scanf("%d", &resultado);
		if(resultado==solucion){
			correctas++;
		}else{
			incorrectas++;
		}
		totalpreguntas++;
		printf("Desea seguir practicando? ingrese : \nSi(S) \nNo(N) \n");
		scanf(" %c", &seguir);
		
	}while(seguir=='s' || seguir=='S');
	printf("La cantidad de operacioines realizadas fueron %d \n %d fueron correctas \n%d fueron incorrectas", totalpreguntas, correctas, incorrectas);
	return 0;
}

