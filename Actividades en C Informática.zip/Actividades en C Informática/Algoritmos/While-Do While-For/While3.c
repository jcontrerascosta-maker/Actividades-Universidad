/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int nota=0, promedio=0, n_aprobadas=0, n_desaprobadas=0, nota_mayor=0, nota_menor=10, cant_notas=0, suma_notas=0, opciones=0;

    printf("ingrese la nota:\n");
    scanf("%d", &nota);

    while(nota!=0){
        cant_notas++;
        suma_notas=suma_notas+nota;
        promedio=suma_notas/cant_notas;
        if(nota>=4){
            n_aprobadas++;}
        else{
            n_desaprobadas++;
        }
        if(nota>nota_mayor){
            nota_mayor=nota;
        }
        if(nota<nota_menor){
            nota_menor=nota;
        }
    printf("\ningrese otra nota:\n");
    scanf("%d", &nota);
    }
    printf("\nQue dato desea leer:\n1(Nota mayor y menor)\n2(Cantidad de evaluaciones aprobadas y desaprobadas)\n3(Promedio general)\n");
    scanf("%d", &opciones);
    switch(opciones){
        case 1: 
            printf("\nLa nota mayor es: %d\n La nota menor es: %d\n", nota_mayor, nota_menor);
            break;
        case 2:
            printf("\nLa cantidad de evaluaciones apobadas son: %d \n La cantidad de evaluaciones desaproadas son: %d", n_aprobadas, n_desaprobadas);
            break;

        case 3:
            printf("\nEl promedio general de las notas es: %d\n", promedio);
            break;

    }
    return 0;
}
