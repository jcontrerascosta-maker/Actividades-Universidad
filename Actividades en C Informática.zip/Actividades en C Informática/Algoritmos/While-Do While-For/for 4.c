#include <stdio.h>

int main() {
	int i=0;
	float sueldo=0, gastos=0, ahorro=0;
	for(i=0; i<12; i++){
		printf("Ingrese su sueldo en el mes %d: \n", i+1);
		scanf("%f", &sueldo);
		printf("Ahora Ingrese sus gastos: \n");
		scanf("%f", &gastos);
		ahorro= ahorro+(sueldo-gastos);
	}
	printf("Los ahorros conseguidos en el a�o fueron $%.2f", ahorro);
	return 0;
}

