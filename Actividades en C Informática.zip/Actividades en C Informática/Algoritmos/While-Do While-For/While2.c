#include <stdio.h>

int main() {
char seguir='s';
float num1=0, num2=0, res=0;
	int op=0;
 printf("\nIngrese los dos numeros:\n");
	scanf("%f%f", &num1, &num2);
	
while(seguir=='s'||seguir=='S'){
	printf("\nIngrese la operacion\n(1: SUMA)\n(2: RESTA)\n(3: MULTIPLICACION)\n(4: DIVISION)\n");
	scanf("%d", &op);
	
	switch(op){
	case 1: res=num1+num2;
		printf("\nel resultado es: ""%.2f" , res);
	break;
	case 2: res=num1-num2;
		printf("\nel resultado es: ""%.2f" , res);
	break;
	case 3: res=num1*num2;
		printf("\nel resultado es: ""%.2f" , res);
	break;
	case 4: res=num1/num2;
		printf("\nel resultado es: ""%.2f" , res);
	break;
	default:
		printf("\nEl numero de operacion es incorrecto");
	break;
}
printf("\nDesea seguir la operacion con los mismos números?: \nSi(S)\nNo(N)\n");
scanf(" %c", &seguir);
	}
	return 0;
}
