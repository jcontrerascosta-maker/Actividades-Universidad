#include <stdio.h>

int main() {
	int edad=0, entradas=0, precio=0, total=0;
	do{
		printf("Hola! por favor ingrese las edades de su grupo familiar (Cuando termine, ingrese 0): \n");
		scanf("%d", &edad);
		entradas++;
		if(edad<5){
			precio=entradas*0;
			
		}
		if(edad>=5|| edad<=15){
			precio=entradas*20;
		}
		else{
			precio=entradas*40;
		}
		total=total+precio;
	} while(edad!=0);
	printf("El precio total de las entradas es: $%d", total);
	return 0;
}

