#include <stdio.h>

int main() {
	float num=0, promedio=0, suma=0;
	int i=0;
	
	for(i=0; i<5;i++){
		printf("Ingrese un numeros: \n");
		scanf("%f", &num);
		suma=suma+num;
	}
	promedio=suma/5;
	printf("La suma de los numeros es %.2f, y el promedio %.2f", suma, promedio);
	return 0;
}

