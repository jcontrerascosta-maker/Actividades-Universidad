#include <stdio.h>

int main() {
	int edad=0, cantidad_edades=0, sumatoria_total=0, promedio=0;
	
	printf("Ingrese su edad por favor: \n");
	scanf("%d", &edad);
	
	do{
		cantidad_edades++;
		sumatoria_total= sumatoria_total+edad;
		printf("Ingrese su edad por favor: \n");
		scanf("%d", &edad);
		printf("Si quiere saber el promedio de edades, ingrece 0 \n");
	}while(edad!=0);
		
	promedio=sumatoria_total/cantidad_edades;
	printf("El promedio de edad es: %d \n", promedio);
	return 0;
}

