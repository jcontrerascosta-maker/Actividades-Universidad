#include <stdio.h>
int main() {
	
	float importe=-1, total=0, recaudacion=0;
	char rta='s';
	
	while(rta=='s'){
		while(importe!=0){
			printf("Ingrese el importe de un producto $ ");
			scanf("%f",&importe);
			if(importe!=0){
				total=total+importe;
			}
		}
		if(total<50){
			printf("Ud. debe pagar $%.2f \n",total);
		}else{
			if(total<=120){
				total=total-(total*0.15); 
				printf("Su compra tiene un descuento del 15%%, Ud. debe pagar $%.2f\n", total);
			}else{
				total=total-(total*0.20); 
				printf("Su compra tiene un descuento del 20%%, Ud. debe pagar $%.2f\n",total);
			}
		}
		recaudacion=recaudacion+total;
		total=0;
		importe=-1;
		
		printf("\n�Mas clientes (s/n)? ");
		scanf(" %c",&rta);
	}
	printf("\nLa recaudacion del negocio es $%.2f\n",recaudacion);
	
	return 0;
}
