#include <stdio.h>
#include <math.h>

int main() {
	int  operacion=0, seguir=0, num=0, resultado=0;
	float rad=0, seno=0, coseno=0, tangente=0;
	
	do{
		printf("Que operacion quiere realizar?\n");
		printf("1. Potencia de 2 de un numero.\n");
		printf("2. Raiz cuadrada de un numero.\n");
		printf("3. Raiz cubica de un numero.\n");
		printf("4. Calcular el seno, coseno y tangente de un angulo.\n");
		scanf("%d", &operacion);
		
		switch(operacion){
		case 1:
			printf("Potencia de 2.\n");
			printf("Ingrese un numero: ");
			scanf("%d", &num);
			resultado=pow(num,2);
			printf("Resultado: %d\n", resultado);
			break;
			
		case 2:
			printf("Raiz cuadrada.\n");
			printf("Ingrese un numero: ");
			scanf("%d", &num);
			resultado=sqrt(num);
			printf("Resultado: %d\n", resultado);
			break;
			
		case 3:
			printf("Raiz cubica.\n");
			printf("Ingrese un numero: ");
			scanf("%d", &num);
			resultado=cbrt(num);
			printf("Resultado: %d\n", resultado);
			break;
			
		case 4:
			printf("Calcular el seno, coseno y tangente de un angulo.\n");
			printf("Ingrese un angulo en grados: ");
			scanf("%d", &num);
			rad=(((float)num*M_PI)/180);
			seno = sin(rad);
			coseno = cos(rad);
			tangente = tan(rad);
			printf("%d = %.2f en Radianes. \n", num, rad);
			printf("El seno de %d es %.2f\n", num, seno);
			printf("El coseno de %d es %.2f\n", num, coseno);
			printf("La tangente de %d es %.2f\n", num, tangente);
			
			break;
			
		default:
			printf("Error \n");
			break;
		}
		printf("Desea realizar otra operacion?\nSI(1) \nNO(2)");
		scanf("%d", &seguir);
	} while(seguir==1);
	return 0;
}

