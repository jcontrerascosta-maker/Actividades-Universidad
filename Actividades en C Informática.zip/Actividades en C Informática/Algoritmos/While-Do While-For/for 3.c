#include <stdio.h>

int main() {
	int x=0, y=0, PuntosAnalizar=0, i=0, c1=0, c2=0, c3=0, c4=0;
	
	printf("Cuantos puntos cartesianos desea analizar?: ");
	scanf("%d", &PuntosAnalizar);
	 for(i=0; i<PuntosAnalizar; i++){
		 printf("Ingrese las coordenadas (x, y): \n");
		 scanf("%d%d", &x, &y);
		 if(x>=0 && y>=0){
			 c1++;
		 }
		 if(x<=0 && y>=0){
			 c2++;
		 }
		 if(x<=0 && y<=0){
			 c3++;
		 }
		 if(x>=0 && y<=0){
			 c4++;
		 }
	 }
	 printf("Se ingresaron %d puntos: \n%d son del cuadrante 1 \n%d son del cuadrante 2 \n%d son del cuadrante 3 \n%d son del cuadrante 4", PuntosAnalizar, c1, c2, c3, c4);
	return 0;
}

