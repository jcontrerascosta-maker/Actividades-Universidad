//Joaqu�n Contreras Costa

#include <stdio.h>

int main() {
	int edad=0;
	float ingresos=0;
	
	printf("Ingrese su edad e ingresos mensuales: \n");
	scanf("%d %f", &edad, &ingresos);
	
	if(edad>25 && ingresos>=200000)
		printf("Usted debe tributar el impuesto");
	
	else 
		printf("Usted no debe tributar el impuesto");
	
	return 0;
}

