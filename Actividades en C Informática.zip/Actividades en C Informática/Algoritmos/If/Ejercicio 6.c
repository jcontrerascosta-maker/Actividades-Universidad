//Joaquin Contreras Costa

#include <stdio.h>

int main() {
	float mindc=0, mindl=0, factura=0;
	
	printf("Ingrese la cantidad de minutos de llamadas a corta distancia: ");
	scanf("%f", &mindc);
	printf("\n Ingrese la cantidad de minutos de llamadas a larga distancia: ");
	scanf("%f", &mindl);
	
	factura= (mindc*0.05)+(mindl*0.10);
	
	if(mindc>1000 && mindl>=1000){
		
		factura= factura-factura*0.10;
		printf("Usted tiene un descuento del 10 por ciento en su factura, el valor de la misma es: $%.2f", factura);
	}
	else{
		printf("El valor de su factura es: $%.2f", factura);
	}
		
	return 0;
}

