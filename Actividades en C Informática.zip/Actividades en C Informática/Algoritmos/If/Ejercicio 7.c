//Joaquin Contreras Costa
#include <stdio.h>

int main() {
	float grados=0;
	printf("Ingrese una temperatura en grados: ");
	scanf("%f", &grados);
	
	if(grados>100){
		printf("Arriba del punto de ebullicion del agua. ");
	}else{
		printf("Abajo del punto de ebullicion del agua. ");
	}
	return 0;
}
