//Joaquin Contreras Costa
#include <stdio.h>

int main() {
	int unidades=0, unidEstudiadas=0, unidFaltantes=0;
	
	printf("Ingrese la cantidad de unidades que tiene la materia: ");
	scanf("%d", &unidades);
	printf("�Cu�ntas unidades estudi�?: ");
	scanf("%d", &unidEstudiadas);
	
	unidFaltantes= unidades-unidEstudiadas;
	
	if(unidFaltantes==0)
		printf("\n Usted estudi� toda la materia");
	else
		printf("A usted le falta estudiar %d unidades", unidFaltantes);
	
	return 0;
}

