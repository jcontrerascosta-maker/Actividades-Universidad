//Joaquin Contreras Costa

#include <stdio.h>

int main() {
	int num1=0, num2=0;
	printf("Ingrese dos numeros: \n");
	scanf("%d%d",&num1,&num2);
	if(num1>num2)
		printf("%d es mayor que %d", num1, num2);
	else
		printf("%d es menor que %d", num1, num2);
	return 0;
}

