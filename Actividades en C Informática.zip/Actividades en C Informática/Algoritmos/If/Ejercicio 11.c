//Joquin Contreras Costa

#include <stdio.h>

int main() {
	float monto=0, recargo=0, montoCRecargo=0;
	int dia_pago=0;
	printf("Ingrese el monto de la cuota y el dia de pago: \n");
	scanf("%f%d",&monto,&dia_pago);
	if(dia_pago>10){
		if(monto>5000){
			recargo=0.10*monto;
		}else{
			recargo=0.05*monto;
		}
		montoCRecargo=monto+recargo;
		printf("\nRecargo: $%0.f \n El Monto de la factura con recargo es: $%0.f",recargo,montoCRecargo);
	}else{
		printf("\nSu factura no tiene recargo. El monto es: $%0.f",monto);
	}
	return 0;
}
