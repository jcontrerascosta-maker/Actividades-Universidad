//Joaquin Contreras Costa
#include <stdio.h>

int main() {
	int edad=0;
	printf("Ingrese su edad:\n");
	scanf("%d",&edad);
	if(edad<4){
		printf("Su entrada gratuita.\n");
	}else{
		if(edad>=4 && edad<=18){
			printf("Su entrada cuesta $100.\n");
		}else{
			printf("Su entrada cuesta $200.\n");
		}
	}
	return 0;
}

