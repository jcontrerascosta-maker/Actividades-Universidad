//Joaquin Contreras Costa

#include <stdio.h>

int main() {
	int num1=0, num2=0, div=0;
	printf("Ingrese dos numeros: \n");
	scanf("%d%d",&num1,&num2);
	if(num1%num2==0 && num2!=0){
		printf("La division %d / %d es exacta. El resultado es %d\n",num1,num2,num1/num2);
	}else{
		printf("La division no es exacta.\n");
	}
	return 0;
}

