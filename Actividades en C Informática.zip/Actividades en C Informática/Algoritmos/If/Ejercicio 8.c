//Joaquin Contreras Costa
#include <stdio.h>

int main() {
	int num1=0, num2=0, num3=0;
	
	printf("Ingrese 3 n�meros para compararlos: \n");
	scanf("%d%d%d", &num1, &num2, &num3);
	
	if(num1==num2 && num2==num3){
		printf("Todos los numeros son iguales");
	}
	else {
		if(num1!=num2 && num2!=num3 && num1!=num3)
			printf("Los 3 n�meros son diferentes");
		else
			printf("Hay 2 numeros iguales y uno distinto");
	}
	return 0;
}

