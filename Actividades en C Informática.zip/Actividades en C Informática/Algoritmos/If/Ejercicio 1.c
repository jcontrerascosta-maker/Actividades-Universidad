//Joaquin Contreras Costa

#include <stdio.h>

int main() {
	int num=0;
	printf("Ingrese un numero: ");
	scanf("%d",&num);
	
	if(num%2==0)
		printf("%d es un numero par.",num);
	else
		printf("%d es un numero impar.",num);
	
	return 0;
}
