//Joaquin Contreras COsta

#include <stdio.h>

int main() {
	char letra=' ';
	int nota=0;
	printf("Ingrese la inicial de su apellido: \n");
	scanf("%c",&letra);
	printf("Ingrese nota obtenida en el examen de nivelacion: \n");
	scanf("%d",&nota);
	if(letra>='A' && letra<='M'){
		if(nota>=7){
			printf("Grupo A \n");
		}else{
			printf("Grupo C \n");
		}
	}else{
		if(nota>=7){
			printf("Grupo B \n");
		}else{
			printf("Grupo D \n");
		}
	}
	return 0;
}

