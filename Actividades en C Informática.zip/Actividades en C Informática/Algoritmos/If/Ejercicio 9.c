//Joaqu�n Contreras Costa

#include <stdio.h>

int main() {
	int lado1=0, lado2=0, lado3=0;
	printf("Ingrese los lados de un triangulo: \n");
	scanf("%d%d%d",&lado1,&lado2,&lado3);
	if(lado1==lado2 && lado2==lado3){
		printf("Es un tri�ngulo Equilatero.");
	}else{
		if((lado1==lado2 && lado1!=lado3) || (lado1==lado3 && lado1!=lado2) || (lado2==lado3 && lado2!=lado1)){
			printf("Es un tri�ngulo Isosceles");
		}else{
			printf("Es un tri�ngulo Escaleno");
		}
	}
	return 0;
}
