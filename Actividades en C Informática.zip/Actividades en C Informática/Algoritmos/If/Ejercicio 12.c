//Joaquin Contreras Costa

#include <stdio.h>

int main() {
	float renta=0;
	printf("Ingrese su renta anual:\n");
	scanf("%f",&renta);
	if(renta<20000){
		printf("Tipo impositivo de 5%% \n");
	}
	else{
		if(renta>=20000 && renta <30000){
			printf("Tipo impositivo de 10%% \n");
		}else{
			if(renta>=30000 && renta <40000){
				printf("Tipo impositivo de 15%% \n");
			}else{
				printf("Tipo impositivo de 20%% \n");
			}
		}
	}
	return 0;
}

