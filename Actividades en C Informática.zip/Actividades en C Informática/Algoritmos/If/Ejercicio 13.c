//Joaquin COntreras Costa

#include <stdio.h>

int main() {
	int cantidad_alum=0;
	float costo_alum=0, precio=0, pago=0, total=0;
	
	printf("Ingrese la cantidad de alumnos: \n");
	scanf("%d",&cantidad_alum);
	
	if(cantidad_alum>=100){
		precio=65;
	}else{
		if(cantidad_alum>=50 && cantidad_alum<=99){
			precio=70;
		}else{
			if(cantidad_alum>=30 && cantidad_alum<=49){
				precio=95;
			}
			else{
				precio=100;
			}
		}
	}
	total=4000+precio*cantidad_alum;
	costo_alum=total/cantidad_alum;
	pago=total-4000;
	printf("\n Total del viaje: $%0.f. \n Costo por alumno: $%0.f.\n Monto para la agencia: $%0.f.",total, costo_alum,pago);
	
	return 0;
}
