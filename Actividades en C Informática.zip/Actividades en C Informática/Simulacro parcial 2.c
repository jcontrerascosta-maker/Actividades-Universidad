#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Funcion Materias regularizadas
int materiasR(int m[5][7]){
	int materiasR=0;
	for(int i=0; i<5; i++){
		for(int j=5;j<6; j++){
			if(m[i][5]==1){
				materiasR++;
			}
		}
	}
	return materiasR;
}

//Funcion materias recursadas
void recursar(int m[5][7]){
	int recursar=0;
	for(int i=0; i<5; i++){
		for(int j=5;j<6; j++){
			if(m[i][5]==2){
				recursar++;
			}
		}
	}
	printf("\nLas materias a recursar son: %d", recursar);
}
	
//Funcion Promedio final
int promedio(int m[5][7]){
	int suma=0, cantidad=0;
	int promedio=0;
	
	for(int i=0; i<5; i++){
		for(int j=6; j<7; j++){
			if(m[i][7]>=1){
				suma= suma+m[i][7];
				cantidad++;
			}
		}
	}
	promedio= suma/cantidad;
	return promedio;
}

//Funcion imprimir matriz
void imprimir(int m[5][7]){
	printf("Asignatura  Parcial 1     Parcial 2  Recuperatorio 1  Recuperatorio 2  Resultado de cursada   Final\n");
	
	for(int i=0; i<5; i++){
		for(int j=0; j<7; j++){
			printf("%d\t\t", m[i][j]);
		}
		printf("\n");
		
	}
	printf("\n");
}
	
int main() {
	int opcion=0;
	int m[5][7]={
		{1,0,0,0,0,0,0},
		{2,0,0,0,0,0,0},
		{3,0,0,0,0,0,0},
		{4,0,0,0,0,0,0},
		{5,0,0,0,0,0,0}};
	srand(time(NULL));
	
	//Resultados Parciales
	for(int i=0; i<5; i++){
		for(int j=1; j<3; j++){
			m[i][j]= rand() %10+1;
		}
	}
	
	//Resultados Recuperatorios
	for(int i=0; i<5;i++){
		for(int j=1; j<4; j++){
			if(m[i][1]>=4){
				m[i][3]=0;
			}else{
				m[i][3]= rand() %10+1;
			}
			if(m[i][2]>=4){
				m[i][4]=0;
			}else{
				m[i][4]= rand() %10+1;
			}
		}
	}
	
	//Resultado Cursada
	for(int i=0; i<5;i++){
		for(int j=1; j<6; j++){
			if(m[i][1]>=4 || m[i][3]>=4){
				m[i][5]=1;
			}else{
				m[i][5]=2;
			}
			if(m[i][2]>=4 || m[i][4]>=4){
				m[i][5]=1;
			}else{
				m[i][5]= 2;
			}
		}
	}
	//Resultados Finales
	for(int i=0; i<5; i++){
		for(int j=5; j<6; j++){
			if(m[i][5]==1){
				m[i][6]= rand() %10+1;
			}else{
				m[i][6]=0;
			}
		}
	}
	
	do{
		//Menu de opciones
		printf("1.Materias Regularizadas\n2.Materias a recursar\n3.Promedio de examenes finales\n4.Tabla de materias completa\n5.Salir\n\n");
		scanf("%d", &opcion);
		switch(opcion){
		case 1: printf("\nLas materias regularizadas son: %d", materiasR(m));
		break;
		
		case 2: recursar(m);
		break;
		
		case 3:  printf("\nEl promedio de los examenes finales son: %d", promedio(m));
		break;
		
		case 4: imprimir(m);
		break;
		}
	} while(opcion!=5);
	
	
	return 0;
}

