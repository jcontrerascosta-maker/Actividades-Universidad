#include <stdio.h>

int borrarDup(int vec[], int n);

int main(){
	int vector[100];
	int n=0, i;
	
	printf("Ingrese la cantidad de elementos que contiene el vector: ");
	scanf("%d", &n);
	
	printf("\n\nIngrese los elementos del vector: \n");
	for(i=0; i<n; i++){
		scanf("%d",&vector[i]);
	}
	
	n= borrarDup(vector, n);
	
	printf("Vector resultante sin duplicados:\n");
	for(i=0; i<n; i++){
		printf("%d ", vector[i]);
	}
	return 0;
}
	

int borrarDup(int vec[], int n){
	int i, j, k;
	
	for(i=0; i<n; i++){
		for(j=i+1; j<n; j++){
			if (vec[i] == vec[j]) {
				for(k= j; k < n-1; k++) {
					vec[k] = vec[k+1];
				}
				n--;
				j--;
			}
		}
	}
	return n;
}
	
