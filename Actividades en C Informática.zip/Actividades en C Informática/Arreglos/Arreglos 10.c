#include <stdio.h>

int main() {
	int notas[20], notaIngresada=0, notaMax=0, notamin=0, ausentes=0, total=0, aprobadas=0, desaprobadas=0;
	int i=0;
	
	printf("Ingrese las notas de los alumnos (para terminar ingrese -1): \n");
		for(i=0; i<20; i++){
			scanf("%d ", &notaIngresada);
			if(notaIngresada==-1){
				break;
			}
			notas[i]=notaIngresada;
			if(i==0){
				notaMax=notas[i];
				notamin=notas[i];
			}
			if(notas[i]>notaMax){
				notaMax=notas[i];
			}
			if(notas[i]<notamin){
				notamin=notas[i];
			}
			if(notas[i]>=4){
				aprobadas++;
			}
			
			if(notas[i]<4 && notas[i]!=0){
				desaprobadas++;
			}
			
			if(notas[i]==0){
				ausentes++;
			}
		}
		
	total=i;
		
	printf("La nota mayor es: %d\n", notaMax);
	printf("La nota menor es: %d\n", notamin);
	printf("La cantidad de notas totales es: %d\n", total);
	printf("La cantidad de aprobados es: %d\n", aprobadas);
	printf("La cantidad de desaprobados es: %d\n", desaprobadas);
	printf("La cantidad de ausentes es: %d\n", ausentes);
	
	return 0;
}

