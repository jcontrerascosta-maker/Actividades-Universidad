#include <stdio.h>

int main() {
	
	int a[5], promedio=0;

	for(int i=0; i<5; i++){
		printf("ingrese un numero:\n");
		scanf("\n%d", &a[i]);
	}
	
	promedio=(a[0]+a[1]+a[2]+a[3]+a[4])/5;
	printf("\nLos numeros ingresadon son: %d %d %d %d %d,", a[0], a[1], a[2], a[3], a[4]);
	printf("\n\nEl promedio es: %d", promedio);
	return 0;
}

