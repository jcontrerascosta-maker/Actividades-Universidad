#include <stdio.h>

int main() {
	int saldos[50], promedio=0, saldosmenor=0, saldomayor=0, total=0, cantidad=0;
	
	for(int i=0; i<50; i++){
		printf("Ingrese los saldos del proveedor: \n");
		scanf("%d", &saldos[i]);
			if(saldos[i]<=0){
				break;
			}
		
		cantidad++;
		total=total+i;
		promedio= total/cantidad;
		
		for (i = 0; i < cantidad; i++){
			if (saldos[i] < promedio){
				saldosmenor++;
			} else if (saldos[i] > promedio) {
				saldomayor++;
			}
		}
	}
	printf("a. Cantidad de saldos cargados: %d\n", cantidad);
	printf("b. Promedio de saldos: %d\n", promedio);
	printf("c. Cantidad de saldos menores al promedio: %d\n", saldosmenor);
	printf("d. Cantidad de saldos mayores al promedio: %d\n", saldomayor);
	printf("e. Total recaudado en el mes: %d\n", total);	
	
	return 0;
}


