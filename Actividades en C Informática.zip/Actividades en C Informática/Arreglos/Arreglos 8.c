#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int rango(int max, int min){
	return rand()%(max-min)+min;
}
int main() {
	int v[10];
	srand(time(NULL));
	
	printf("Valores: \n");
	for(int i=0; i<10; i++){
		v[i]= rango(30, 15);
		printf("%d ", v[i]);
	}
	printf("\nValores invertidos: \n");
	for(int i=9; i>=0; i--){
		printf("%d ",v[i]);
	}
	return 0;
}

