#include <stdio.h>

int main() {
	
	int a[5];

	for(int i=0; i<5; i++){
			printf("ingrese un numero:\n");
			scanf("\n%d", &a[i]);
	}
	printf("\nLos valores en las posiciones impares son:%d, %d y %d", a[0], a[2], a[4]);
	return 0;
}

