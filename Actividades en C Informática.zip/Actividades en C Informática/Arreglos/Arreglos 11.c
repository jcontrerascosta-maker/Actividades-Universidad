#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int rango(int max, int min){
	return rand()%(max-min)+min;
}
	
int suma(int vector[]){
	int suma=0;
	for(int i=0; i<10; i++){
		suma= suma+vector[i];
	}
	return suma;
}
	
int promedio(int vector[]){
	int promedio= suma(vector)/10;
	return promedio;
}
	
void transformarEnLetras(int vector[]){
	printf("Vector transformado en letras:\n");
	for (int i = 0; i < 10; i++) {
		printf("%c ", vector[i]);
	}
	printf("\n");
}
	
int main() {
	int vector[10];
	int opcion=0;
	srand(time(NULL));
	
	for(int i=0; i<10; i++){
		vector[i]= rango(90, 65);
		printf("%d ", vector[i]);
	}
	
	
	do {
		printf("\n\nMen� de opciones:\n");
		printf("1. Sumar todos los valores\n");
		printf("2. Calcular el promedio\n");
		printf("3. Transformar los n�meros en letras\n");
		printf("4. Salir\n");
		printf("Seleccione una opci�n: ");
		scanf("%d", &opcion);
	switch(opcion){
		case 1: suma(vector);
			printf("\nLa suma de los elementos del vector es: %d\n", suma(vector)); 
			break;
		case 2: promedio(vector);
			printf("\nEl promedio de los elementos del vector es: %d\n", promedio(vector));
			break;
			
		case 3:
			transformarEnLetras(vector);
			break;
		case 4:
			printf("Saliendo del programa\n");
			break;
		default:
			printf("Opci�n inv�lida. Por favor, seleccione una opci�n v�lida.\n");
			break;
		}
	} while(opcion!=4);

	return 0;
}

