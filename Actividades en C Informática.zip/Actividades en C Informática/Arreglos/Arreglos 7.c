#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main() {

	int vector[20], cara=0, cruz=0;
	srand(time(NULL));

	for(int i=0 ; i<20 ; i++){
		vector[i]= rand() % 2;
		if(vector[i]==0){
			cara++;
		}else{
			cruz++;
		}
	}
	printf("La cantidad de veces que salio cara fue %d y cruz %d", cara, cruz);

	return 0;
}

