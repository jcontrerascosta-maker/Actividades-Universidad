#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int numAleatorio(int min, int max) {
	return rand() % (max-min)+min;
}
int main() {
	int v[10], contadorimpar=0, i=0, num=0;
	srand(time(NULL));
	
	do{
		num=numAleatorio(0,100);
		if(num%2==0){
			v[i]=num;
			printf("%d ", v[i]);
			i++;
		}else{
		contadorimpar++;
		}
		
	} while(i<10);
	
	printf("\nCantidad de valores impares no guardados en el vector: %d\n", contadorimpar);
	return 0;
}

