#include <stdio.h>

void abecedarioMayus();
void abecedarioMinus();

int main() {
	abecedarioMayus();
	abecedarioMinus();
	return 0;
}

void abecedarioMayus(){
	int letra=0;
	
	printf("Abecedario en May�scula: \n");
	for(letra=65; letra<=90; letra++){
		printf(" %c", letra);
	}
	printf("\n");
}

void abecedarioMinus() {
	int letra=0;
	
	printf("Abecedario en Min�scula: \n");
	for(letra=97; letra<=122; letra++){
		printf(" %c", letra);
	}
	printf("\n");
	}

