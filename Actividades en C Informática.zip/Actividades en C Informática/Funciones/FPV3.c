#include <stdio.h>
#include <math.h>
#include <stdbool.h>

void cuadrado();
void rectangulo();
void circulo();

int main() {
	char operacion=' ';
	bool valido= false;
	
	do{
		printf("CALCULOS DE PERIMETROS: \n a. Cuadrado\n b. Rectangulo\n c. Circulo\n s. Salir\n");
		printf("\nIngrese una opcion: ");
		
		do{
			scanf(" %c",&operacion);
			if(operacion=='a'||operacion=='b'||operacion=='c'||operacion=='s'){
				valido=true;
			}else{
				printf("\nDebe ingresar una opcion valida. \n");
				valido=false;
			}
		}while(valido==false);
		
		if(operacion!='s'){
			switch(operacion){
			case 'a': cuadrado();
				break;
			case 'b': rectangulo();
				break;
			case 'c': circulo();
				break;
			}
		}
	} while(operacion!='s');
	
	return 0;
}
void cuadrado(){
	float lado=0;
	printf("Ingrese un lado del cuadrado\n");
	scanf("%f",&lado);
	printf("\n Perimetro: %0.2f \n Area: %0.2f \n",(lado*4),(pow(lado,2)));
}
	void rectangulo(){
		float base=0, altura=0;
		printf("Ingrese base y altura del rectangulo \n");
		scanf("%f%f",&base, &altura);
		printf("Perimetro: %0.2f \n Area: %0.2f \n", (2*base+2*altura), (base*altura));
	}
		void circulo(){
			float radio=0;
			printf("Ingrese el radio del circulo \n");
			scanf("%f",&radio);
			printf("Perimetro (circunferencia): %0.2f \n Area: %0.2f \n", (2*M_PI*radio),(M_PI*pow(radio,2)));
		}

