#include <stdio.h>

int mayor(int, int, int);
void menor(int, int, int);

int main() {
	int num1=0, num2=0, num3=0;
	
	printf("Ingrese 3 n�meros para compararlos: \n");
	scanf("%d%d%d", &num1, &num2, &num3);
	printf("El mayor de los n�meros es: %d \n", mayor(num1, num2, num3));
	menor(num1, num2, num3);
	
	return 0;
}

int mayor(int a, int b, int c){
	int max=a;
	
	if(b>max){
		max=b;
	}
	if(c>max){
		max=c;
	}
	return max;
}
	
void menor(int a, int b, int c){
	int min=a;
	
	if(b<min){
		min=b;
	}
	if(c<min){
		min=c;
	}
		printf("El menor de los n�meros es: %d \n", min);
}

