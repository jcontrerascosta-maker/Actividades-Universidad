#include <stdio.h>

int numPar(int);
int main() {
	int num=0;
	printf("Ingrese un numero: ");
	scanf("%d",&num);
	if(numPar(num)==1){
		printf("Par");
	}
	else{
		printf("Impar");}
	return 0;
	
}
int numPar(int num){
	if(num%2==0){
		return 1;
	}
	else{
		return 0;}
}
