#include <stdio.h>

int factorial(int numero);

int main() {
	int num=0;
	printf("Ingrese un numero entero: ");
	scanf("%d", &num);
	printf("El factorial de %d es %d\n", num, factorial(num));
	return 0;
}

int factorial(int numero){
	int fact=1, i=0;
	for (i=1; i<=numero; i++) {
		fact*= i;
	}
	return fact;
}

