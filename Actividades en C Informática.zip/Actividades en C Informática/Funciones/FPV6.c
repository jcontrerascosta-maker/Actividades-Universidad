#include <stdio.h>

int promedio(int, int, int);

int main() {
	int num1=0, num2=0, num3=0;
	printf("Ingrese 3 n�meros para poder sacar su promedio: \n");
	scanf("%d%d%d", &num1, &num2, &num3);
	printf("El promedio de los 3 n�meros es: %d", promedio(num1, num2, num3));
	return 0;
}

int promedio(int a, int b, int c){
	int prom= (a+b+c)/3;
	return prom;
}
