#include <stdio.h>
#include <stdbool.h>
void suma(int, int);
void resta(int, int);
void multiplicacion(int, int);
void division(int, int);

int main() {
	int num1=0, num2=0;
	char operacion=' ';
	bool opcionValida=false;
	do{
		printf("CALCULADORA\n a. Sumar\n b. Restar\n c. Multiplicar\n d. Dividir\n s. Salir \n");
		do{
			scanf(" %c",&operacion);
			if(operacion=='a'||operacion=='b'||operacion=='c'||operacion=='d'||operacion=='s'){
				opcionValida=true;
			}else{
				printf("\nDebe ingresar una opcion valida. \n");
				opcionValida=false;
			}
		}while(opcionValida==false);
		
		if(operacion!='s'){
			printf("Ingrese 2 numeros \n");
			scanf("%d%d", &num1, &num2);
			
			switch(operacion){
			case 'a': suma(num1, num2);
			break;
			case 'b': resta(num1, num2);
			break;
			case 'c':multiplicacion(num1, num2);
			break;
			case 'd':division(num1, num2);
			break;
			}
			
		}
	} while(operacion!='s');
	
	return 0;
}
void suma(int num1, int num2){
	printf("\n%d + %d = %d\n", num1, num2, (num1+num2));
}
void resta(int num1, int num2){
	printf("\n%d - %d = %d\n", num1, num2, (num1-num2));
}
void multiplicacion(int num1, int num2){
	printf("\n%d * %d = %d\n", num1, num2, (num1*num2));
}
void division(int num1, int num2){
	printf("\n%d / %d = %d\n", num1, num2, (num1/num2));
}

