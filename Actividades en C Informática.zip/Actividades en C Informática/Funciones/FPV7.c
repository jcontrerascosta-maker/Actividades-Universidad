#include <stdio.h>

int OMayor(int, int, int);
int sumaMayores(int, int, int);

int main() {
	int num1=0, num2=0, num3=0;
	
	printf("Ingrese 3 numeros: ");
	scanf("%d%d%d", &num1, &num2, &num3);
	
	printf("El mayor de los numeros es: %d \n", OMayor(num1, num2, num3));
	printf("La suma de los dos mayores es: %d", sumaMayores(num1, num2, num3));
	
	return 0;
}


int OMayor(int a, int b, int c) {
	int mayor = a;
	
	if (b > mayor) {
		mayor = b;
	}
	if (c > mayor) {
		mayor = c;
	}
	return mayor;
}

int sumaMayores(int a, int b, int c) {
	int mayor= OMayor(a, b, c);
	int segundoMayor=0;
	
	if (a == mayor) {
		a=0;
		segundoMayor= OMayor(a, b, c);
	} else if (b == mayor) {
		b=0;
		segundoMayor= OMayor(a, b, c);
	} else {
		c=0;
		segundoMayor= OMayor(a, b, c);
	}
	
	return mayor+segundoMayor;
}

