#include <stdio.h>
#include <stdbool.h>

bool igualdad(int, int);

int main() {
	int num1=0, num2=0;
	printf("Ingrese 2 numeros para compararlos: \n");
	scanf("%d%d", &num1,&num2);
	
	if (igualdad(num1, num2)) {
		printf("Los numeros ingresados son iguales.\n");
	} else {
		printf("Los numeros ingresados no son iguales.\n");
	}
	return 0;
}

bool igualdad(int num1, int num2) {
	if (num1 == num2) {
		return true;
	} else {
		return false;
	}
}
