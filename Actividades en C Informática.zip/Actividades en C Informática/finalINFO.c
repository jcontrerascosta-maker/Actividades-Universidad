/* desarrolle un programa que permita gestionar la asistencia de los jugadores en los entrenamientos de 
un equipo de futbol durante un mes. para ello declara e inicializa un arreglo 30x3 con los siguientes datos
numero de jugador, cantidad de asistencias, cantidad de inasistencias, cantidad de llegadas tarde.

crear un menu de opciones 0,5pts que se repetira hasta que el usuario decida finalizar el programa.
este menu debe permitir la eleccion de opciones en letras mayusculas o minusculas para cada caso, llamara
a las siguientes funciones

inicializar arreglo 2pts el numero de jugador se completa con numeros consecutivos comenzando con el 1.
cada mes tiene 24 dias de entrenamiento, por lo uqe la cantidad de dias de asistencias y la cantidad de dias
inasitencia debe sumar 24 dias, la cantidad de llegadas tarde no puede ser mayor a la cantidad de dias de 
asistencia. utilizar numeros aleatorios para completar la carga del arreglo

mostrar un listado de todas las asitencias registradas durante un mes en formato tabla 1,5pts

calcular y mostrar el porcentaje de asistencias y el porcentaje de llegadas tarde del plantel de jugadores 2pts

buscar y mostrar los jugadores que tuvieron una asitencia perfecta sin llegadas tarde 2pts */

#include<stdio.h>
#include<time.h>
#include<stdlib.h>


//prototipos
void menu();
void iniciarArreglo(int [30][3]);
void imprimirRegistro(int [30][3]);
void calcularPorcentaje(int [30][3]);
void asistenciaPerfecta(int [30][3]);

//principal

int main(){
	
	menu();
	
	return 0;
}

void menu(){
	
	char opcion;
	int arreglo[30][3]={0};
	
	
	do{
		
		printf("******MENU******\n");
		printf("a.Iniciar temporada (iniciar arreglo)\n");
		printf("b.Registro\n");
		printf("c.Calcular porcentaje\n");
		printf("d.Jugador/es con asistencia perfecta\n");
		
		printf("Digite 's' para salir.\n");
		scanf(" %c",&opcion);
		
		switch(opcion){
			case 'a':iniciarArreglo(arreglo);break;
			case 'b':imprimirRegistro(arreglo);break;
			case 'c':calcularPorcentaje(arreglo);break;
			case 'd':asistenciaPerfecta(arreglo);break;
		}
	}while(opcion!='s'||opcion!='S');
	
}

void iniciarArreglo(int arreglo[30][3]){
	int i=0, j=0;
	int temporada[30][24]={0}; // cantidad de jugadores x dias de temporada
	
	
	srand(time(NULL));
	
	//0=presente
	//1=asutente
	//2=llegada tarde
	
	for(i=0;i<30;i++){
		for(j=0;j<24;j++){
			temporada[i][j]=rand()%2;
		}
	}
	
	
						
	//contador
	for(i=0;i<30;i++){
		for(j=0;j<24;j++){
			
			if(temporada[i][j]==0){
				arreglo[i][0]++;
			}else if(temporada[i][j]==1){
				arreglo[i][1]++;
			}
		}
	}
	
	for(i=0;i<30;i++){
			arreglo[i][2]=rand()%(arreglo[i][0]);
		}
}

void imprimirRegistro(int arreglo[30][3]){
	int i=0, j=0, k=0;
	
	printf("Jugador\tAsistencias\tInasistencias\tLlegadas tarde\n");
	
	for(i=0;i<30;i++){
		k++;
		printf("%d ",k);
		
		for(j=0;j<3;j++){
			printf("\t %d \t",arreglo[i][j]);
		}
		
		printf("\n");
	}
}

void calcularPorcentaje(int arreglo[30][3]){
	int i=0, j=0;
	int registro[30][2]={0};
	
	printf("Asitencia(%)\tLlegadas tarde(%)\n");
	
	for(i=0;i<30;i++){
		for(j=0;j<2;j++){
			registro[i][j]=(arreglo[i][0]*100/24);
			registro[i][j+1]=(arreglo[i][2]*100/24);
			
			printf("%d \t\t\t",registro[i][j]);
		}
		printf("\n");
	}
		
}

void asistenciaPerfecta(int arreglo[30][3]){
	int i=0, j=0;
	
	for(i=0;i<30;i++){
		for(j=0;j<3;j++){
			
			if(arreglo[i][0]==24&&arreglo[i][2]==0){
				printf("\nEl Jugador %d tiene asistencia perfecta\n",i);
			} else {
				printf("\nNo hay jugadores con asistencia perfecta\n");
			}
		}
	}
}
