#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void imprimir(int alumnos[10][2]);
void NotaMayor(int alumnos[10][2]);
void NotaMenor(int alumnos[10][2]);
void listaMayorMenor(int alumnos[10][2]);
void Aprobados(int alumnos[10][2]);
void grupos(int alumnos[10][2]);

int main() {
	
	int alumnos[10][2]={0};
	char op=' ';
	srand(time(NULL));
	
	//Lista de alumnos
	for(int i=0; i<10; i++){
		alumnos[i][0]=i+1;
		alumnos[i][1]= rand()%10+1;
	}
	imprimir(alumnos);
	
	do{
		
		printf("---------------MENU DE OPCIONES---------------\n");
		printf("a. Nota mas alta.\nb. Nota mas baja.\nc. Mostrar listado ordenado.\nd. Cantidad de estudiantes con 7 o mas, y cantidad de desaprobados\ne. Grupos\nIngrese opcion: ");
		scanf(" %c",&op);
		switch(op){
		case 'A': 
		case 'a': 
			printf("---------------------------------------------\n");
			NotaMayor(alumnos);
			break;
		case 'B': 
		case 'b':
			printf("---------------------------------------------\n");
			NotaMenor(alumnos);
			break;
		case 'C': 
		case 'c':
			printf("---------------------------------------------\n");
			listaMayorMenor(alumnos);
			break;
		case 'D': 
		case 'd':
			printf("---------------------------------------------\n");
			Aprobados(alumnos);
			break;
		case 'E': 
		case 'e':
			printf("---------------------------------------------\n");
			grupos(alumnos);
			break;
		}
		printf("\n\n�Desea seguir (S/N)? ");
		scanf(" %c",&op);
		
	}while(op=='s' || op=='S');
	
	
	return 0;
}


void imprimir(int alumnos[10][2]){
	printf("\nAlumno 	Nota\n");
	for(int i=0; i<10; i++){
		for(int j=0; j<2; j++){
			printf("%d	", alumnos[i][j]);
		}
		printf("\n");
	}
}

void NotaMayor(int alumnos[10][2]){
	int notaMayor=0;
	for(int i=0; i<10; i++){
		if(i==0){
			notaMayor=alumnos[i][1];
		}if(alumnos[i][1]>=notaMayor){
			notaMayor=alumnos[i][1];
		}
	}
	printf("\n La nota mayor es %d", notaMayor);
}
	
void NotaMenor(int alumnos[10][2]){
	int notaMenor=0;
	for(int i=0; i<10; i++){
		if(i==0){
			notaMenor=alumnos[i][1];
		}if(alumnos[i][1]<=notaMenor){
			notaMenor=alumnos[i][1];
		}
	}
	printf("\n La nota mayor es %d", notaMenor);
}
	
	
void listaMayorMenor(int alumnos[10][2]){
	int auxNota=0, auxAlum=0;
	
	for(int i=0-1; i<10-1; i++){
		if(alumnos[i][1]<alumnos[i+1][1]){
			auxNota=alumnos[i][1];
			auxAlum=alumnos[i][0];
			
			alumnos[i][1]=alumnos[i+1][1];
			alumnos[i][0]=alumnos[i+1][0];
			
			alumnos[i+1][1]=auxNota;
			alumnos[i+1][0]=auxAlum;
		}
	}
	printf("\nAlumno 	Nota\n");
	for(int i=0; i<10; i++){
		for(int j=0; j<2; j++){
			printf("%d	", alumnos[i][j]);
		}
		printf("\n");
	}
	
}

void Aprobados(int alumnos[10][2]){
	int aprob=0, desaprob=0;
	
	for(int i=0; i<10; i++){
		if(alumnos[i][2]>=7){
			aprob++;
		}
		if(alumnos[i][2]<7){
			desaprob++;
		}
	}
	printf("\n La cantidad de aprobados son %d y los desaprobados son %d \n", aprob, desaprob);
}


void grupos(int alumnos[10][2]){
	int basico[10]={0}, intermedio[10]={0}, avanzado[10]={0}, b=0, in=0, a=0;
	
	for(int i=0; i<10; i++){
		if(alumnos[i][1]>=1 || alumnos[i][1]<=4){
			basico[b]=alumnos[i][0];
			b++;
		}
		if(alumnos[i][1]>4 || alumnos[i][1]<=7){
			intermedio[in]=alumnos[i][0];
			in++;
		}
		if(alumnos[i][1]>7){
			avanzado[a]= alumnos[i][0]; 
			a++;
		}
	}
	
	printf("\nBasico [1-4]: ");
	for(int i=0; i<b;i++){
		printf("%d - ", basico[i]);
	}
	printf("\nIntermedio [5-7]: ");
	for(int i=0; i<in;i++){
		printf("%d - ", intermedio[i]);
	}
	printf("\nAvanzado [8-10]: ");
	for(int i=0; i<a;i++){
		printf("%d - ", avanzado[i]);
	}
}
	
	
	

