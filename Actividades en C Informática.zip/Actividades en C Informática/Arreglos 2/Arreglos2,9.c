#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

void cargardatos(int p[10][4]);
void prestarLib(int p[10][4]);
void impMatriz(int p[10][4]);
int masSolicitado(int biblioteca[10][4]);

int main() {
	int libros[10][4]={0};
	char op=' ';
	srand(time(NULL));
	cargardatos(libros);
	
	do{
		printf("\nMENU DE OPCIONES - BIBLIOTECA\n");
		printf("a. Prestar libros.\nb. Mostrar.\nc. Mas Prestado.\nIngrese una opci�n:");
		scanf(" %c",&op);
		switch(op){
		case 'a': 
		case 'A': 
			prestarLib(libros);
			break;
		case 'b':
		case 'B': 
			impMatriz(libros);
			break;
		case 'c':
		case 'C': 
			printf("\nEl libro mas prestado es %d",masSolicitado(libros));
			break;
		}
		printf("\n�Desea seguir (S/N)?");
		scanf(" %c",&op);
		
	}while(op=='s' || op=='S');
	
	return 0;
}

void cargardatos(int p[10][4]){
	for(int i=0; i<10; i++){
		p[i][0]= i+1;
		p[i][1]= rand()%100+1;
		p[i][2]= 0;
		p[i][3]= p[i][1];
	}
}

void prestarLib(int p[10][4]){
	int cod=0, cant=0;
	impMatriz(p);
	
	printf("\nIngrese los codigos de los libros que desea pedir (cuando desee salir inserte 0): ");
	do{
		printf("\nCodigo: ");
		scanf("%d", &cod);
		if(cod!=0){
			printf("\nIngrese la cantidad: ");
			scanf("%d", &cant);
			for(int i=0; i<10; i++){
				if(cod==p[i][0]){
					if(cant<=p[i][3]){
						p[i][3]= p[i][3]-cant;
						p[i][2]= p[i][2]+cant;
						printf("Quedan Disponibles: %d del libro %d", p[i][3], p[i][0]);
						break;
					}
					else{
						printf("\nLo siento. No hay suficientes libros del c�digo %d\n", cod);
						break;
					}
				}
			}
		}
		
	} while(cod!=0);
	
}
	
void impMatriz(int p[10][4]){
	printf("\nCod.	Total	Prest. 	Disp.\n");
	for(int i=0; i<10; i++){
		for(int j=0; j<4; j++){
			printf("%d\t", p[i][j]);
		}
		printf("\n");
	}
}
	
int masSolicitado(int biblioteca[10][4]){
		int cod=0, mayor=0, i=0;
		for(i=0;i<10;i++){
			if(i==0){
				cod=biblioteca[i][0];
				mayor=biblioteca[i][2]; //columna de los prestados
			}else{
				if(mayor<biblioteca[i][2]){
					cod=biblioteca[i][0];
					mayor=biblioteca[i][2];
				}
			}
		}
		return cod;
}
	
