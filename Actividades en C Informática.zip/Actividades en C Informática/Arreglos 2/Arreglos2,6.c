#include <stdio.h>

int main() {
	float mejorcombustible=0, precio=0;
	int nombre=0;
	float m[4][5]={
		{1,17,100,40,0},
		{2,19,120,42,0},
		{3,20,95,36,0},
		{4,25,116,41,0}
		};
	
	for(int i=0;i<4;i++){
		m[i][4]= m[i][2]/m[i][3];
	}
	printf("Tipo de combustible - Precio x litro - Kil�metros recorridos - Litros utilizados - Kil�metros x litro \n");
		  
	for(int i=0; i<4;i++){
		for(int j=0; j<5; j++){
			printf("%.2f \t\t\t", m[i][j]);
		}
		printf("\n");
	}
	for(int i=0;i<4;i++){
		precio=m[i][1]/m[i][4];
		if(i==0){
			mejorcombustible=precio;
		}
		 if(precio<=mejorcombustible){
			nombre=i+1 ;
		}
		}
	printf("El mejor combustible es el : %d", nombre);

	return 0;
}

