#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void resultados(int v[5][4]){
	for(int i=0; i<5; i++){
		if(v[i][2]==v[i][3]){
			printf("%d * %d = %d \t Correcto \n", v[i][0],v[i][1],v[i][2]);
		}else{
			printf("%d * %d = %d \t Incorrecto. \t Respuesta: %d\n", v[i][0],v[i][1],v[i][2],v[i][3]);
		}
	}
}
void mensaje(int v[5][4]){
	int correctas=0;
	for(int i=0; i<5; i++){
		if(v[i][2]==v[i][3]){
			correctas++;
		}
	}
	if(correctas==5){
		printf("Felicitaciones");
	}
	if(correctas==3 || correctas==4){
		printf("�Bien!, Vas por buen camino.");
	}
	if(correctas<=2){
		printf("Hay que practicar m�s.");
	}
}

int main() {
	int multip[5][4];
	srand(time(NULL));
	
	printf("Ejercicios: \n");
	for(int i=0; i<5; i++){
		multip[i][0]=rand()%10+1;
		multip[i][1]=rand()%10+1;
		printf(" %d * %d ", multip[i][0], multip[i][1]);
		scanf("%d", &multip[i][2]);
		multip[i][3]=multip[i][0]*multip[i][1];
	}
	resultados(multip);
	mensaje(multip);
	
	return 0;
}

