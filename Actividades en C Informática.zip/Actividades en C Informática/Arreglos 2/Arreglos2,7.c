#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*
void CantEncuestas(int p[15][2]){
	for(int i=0; i<15; i++){
		
		for(int j=0; j<2; j++){
			if(){
				
			}
		}
	}
}
*/	
void cantAB(int p[15][2]){
	int A=0, B=0;
	for(int i=0; i<15; i++){
		for(int j=0; j<1; j++){
			if(p[i][0]==1){
				A++;
			}
			if(p[i][1]==1){
				B++;
			}
		}
	}
	printf("\nLa cantidad de personas que eligieron el producto A fue de %d, y la cantidad que eligieron el B %d \n", A, B);
}
	
void imprimir(int p[15][2]){
	printf("Producto A\tProducto B\n");
	for(int i=0; i<15; i++){
		for(int j=0; j<2; j++){
			printf("%d \t\t", p[i][j]);
		}
		printf("\n");
	}
	
}

int main() {
	int p[15][2];
	int i=0, j=0;
	int opcion=0, numero=0;
	
	srand(time(NULL));
	
	printf("Compraria los productos A y B?:\n1.Si\n2.No\n\n");
	for(i=0; i<15; i++){
		for(j=0; j<2; j++){
			do {
				numero = rand() % 10; 
			} while (numero!=1 && numero!=0 && numero!=9);
			
			if(opcion==9){
				break;
			}
			
			if(numero==1 || numero==0){
				opcion=numero;
			}
			p[i][0]= opcion;
			
			do {
				numero = rand() % 10; 
			} while (numero!=1 && numero!=0);
			opcion=numero;
			p[i][1]= opcion;
		}
	}
	imprimir(p);
	cantAB(p);
	return 0;
}

