#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void genenrarV(int v[10]);
void imptimirV(int v[10], int dup[10]);
void Vx2(int v[10]);
int pares(int v[10]);
void ordenar(int v[10]);

int main(){
	int v[10];
	char op= ' ';
	srand(time(NULL));
	
	do{
		printf("\n***OPCIONES***\n");
		printf("\na.Generar un vector\nb.Generar Duplicado\nc.Pares\n");
		scanf(" %c", &op);
		switch(op){
			case 'A':
			case 'a':
				genenrarV(v);
				break;
			case 'B':
			case 'b':
				Vx2(v);
				break;
			case 'c':
			case 'C':
				printf("%d", pares(v));
				break;
		case 'd':
			ordenar(v);
			
		}
		
	} while(op!='s');
	
	
}

void genenrarV(int v[10]){
	for(int i=0; i<10; i++){
		v[i]= rand() %11;
	}
	
}
	
void Vx2(int v[10]){
	int dup[10];
	for(int i=0; i<10; i++){
		dup[i]= v[i]*2;
	}
	imptimirV(v,dup);
}
	
void imptimirV(int v[10], int dup[10]){
	for(int i=0; i<10; i++){
		printf("%d\t%d\n", v[i],dup[i]);
	}
	printf("\n");
}

int pares(int v[10]){
	int pares=0;
	for(int i=0; i<10; i++){
		if(v[i]%2==0){
			pares++;
		}
	}
	return pares;
}
	
void ordenar(int v[10]){
	int aux=0, posMin=0;;
	
	for(int i=0; i<10-1; i++){
		posMin=i;
		for(int j=i+1; j<10; j++){
			if(v[j]<v[posMin]){
				posMin=j;
			}
		}
		aux=v[i];
		v[i]=v[posMin];
		v[posMin]=aux;
	}
	
	
	for(int i=0; i<10; i++){
		printf("%d\n",v[i]);
	}
}
	
	

	
