#include <stdio.h>

void costProd(float dulces[3][7]);
void precioU(float dulces[3][7]);
void recaudacion(float dulces[3][7]);
void recaTotal(float dulces[3][7]);
void MejorRinde(float dulces[3][7]);
void mostrar(float dulces[3][7]);

int main() {
	float dulces[3][7]={
		{1,3000,10000,500,0,0,0},
		{2,2000,7000,250,0,0,0},
		{3,2000,6000,300,0,0,0}};
	
	costProd(dulces);
	precioU(dulces);
	recaudacion(dulces);
	recaTotal(dulces);
	MejorRinde(dulces);
	mostrar(dulces);
	return 0;
}

void costProd(float dulces[3][7]){
	for(int i=0; i<3; i++){
		dulces[i][4]=dulces[i][2]/dulces[i][3];
	}
}

void precioU(float dulces[3][7]){
	for(int i=0; i<3; i++){
		dulces[i][5]=dulces[i][4]+(dulces[i][4]/2);
	}
}
	
void recaudacion(float dulces[3][7]){
	for(int i=0; i<3; i++){
		dulces[i][6]=dulces[i][3]*dulces[i][5];
	}
}
	
void recaTotal(float dulces[3][7]){ 
	float recaudacionTotal=0;
	for(int i=0; i<3; i++){
		recaudacionTotal= recaudacionTotal+dulces[i][6];
	}
	printf("\nLa recaudacion total fue de $ %.2f\n", recaudacionTotal);
}

void MejorRinde(float dulces[3][7]){
	float Mcod=0, MD=0;
	for(int i=0; i<3; i++){
		if(i==0){
			MD= dulces[i][1]/dulces[i][3];
			Mcod= dulces[i][0];
		}else{
			if(MD>dulces[i][1]/dulces[i][3]){
				Mcod= dulces[i][0];
			}
		}
	}
	printf("\nEl mejor dulce es %.2f\n", Mcod);
}
	
void mostrar(float dulces[3][7]){
	for(int i=0; i<3; i++){
		for(int j=0; j<7; j++){
			printf("%.2f  ", dulces[i][j]);
		}
		printf("\n");
	}
}
	
	
	
	

