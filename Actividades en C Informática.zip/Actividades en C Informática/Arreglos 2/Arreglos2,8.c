#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>


void cargarDatos(int p[10][4]);
void impMatriz(int p[10][4]);
void prestarProd(int p[10][4]);


int main() {
	int productos[10][4]= {0};
	char opcion=' ';
	srand(time(NULL));
	
	//Cargar Datos
	cargarDatos(productos);

	do{
		printf("---------------MENU DE OPCIONES---------------\n");
		printf("a. Prestar un elemento.\nb. Mostrar.\nIngrese opcion: ");
		scanf(" %c",&opcion);
		switch(opcion){
		case 'A':
		case 'a': 
			printf("---------------------------------------------\n");
			//Prestar productos
			prestarProd(productos);
			break;
			
		case 'B': 
		case 'b':
			printf("---------------------------------------------\n");
			//imprimir Matriz
			impMatriz(productos);
			break;
		}
		printf("\n\n�Desea seguir (S/N)? ");
		scanf(" %c",&opcion);
		
	} while(opcion=='s' || opcion=='S');
	
	return 0;
}

void cargarDatos(int p[10][4]){
	for(int i=0; i<10; i++){
		p[i][0]= i+1;
		p[i][1]= rand()%100+1;
		p[i][2]= 0;
		p[i][3]= p[i][1];
	}
}

void impMatriz(int p[10][4]){
	printf("\nC�digo		Total		Prestadas	Disponibles\n");
	for(int i=0; i<10;i++){
		for(int j=0; j<4; j++){
			printf("%d	\t", p[i][j]);
		}
		printf("\n");
	}
}

void prestarProd(int p[10][4]){
	int codigo=0, cant=0;
	bool bandera= false;
	
	printf("Cod.\tTotal\tDispo.\n");
	for(int i=0; i<10;i++){
		if(p[i][2]<p[i][1]){
			printf("%d\t%d\t%d\n",p[i][0],p[i][1],p[i][3]);
		}
	}
	printf("\nIngrese el codigo del elemento: ");
	scanf("%d", &codigo);
	printf("\nIngrese la cantidad de unidades: ");
	scanf("%d", &cant);
	
	for(int i=0; i<10; i++){
		if(p[i][0]==codigo){
			if(cant<=p[i][3]){
				p[i][3]=p[i][3]-cant;
				p[i][2]=p[i][2]+cant;
				printf("Se prestaron %d del codigo %d\n", cant, codigo);
				printf("Quedaron disponible %d.\n", p[i][3]);
				bandera=true;
				break;
			}
		}
	}
	if(bandera!=true){
		printf("No hay stock suficiente\n");
	}
}
	

