//Ver parte de sectores, no comprendi la consigna.

#include <stdio.h>

void inicialSolicitud(int m[6][5]);
void imprimirM(int m[6][5]);
void mostrarRubro(int m[6][5]);
int ganancias(int m[6][5]);

int main(){
	int m[6][5];
	char op=' ';
	
	do{
		printf("FERIA DE LA COMUNA\n");
		printf("a. Registrar solicitud\nb. Mostrar Solicitudes\nc. Mostrar Solicitudes por rubro\nd. Recaudaci�n de la Comuna\n"); 
		scanf(" %c",&op);
		switch(op){
		case 'a': 
		case 'A': 
			inicialSolicitud(m);
			break;
		case 'b':
		case 'B': 
			imprimirM(m);
			break;
		case 'c':
		case 'C': 
			mostrarRubro(m);
			break;
		case 'd':
		case 'D': 
			printf("\n----------------------------------------------------------");
			printf("\nRecaudacion de la comuna $%d",ganancias(m));
			printf("\n----------------------------------------------------------");
			break;
		}
		printf("\n\n�Desea seguir (S/N)?");
		scanf(" %c",&op);
		printf("\n");
		
	}while(op=='s' || op=='S');
	
	
}

void inicialSolicitud(int m[6][5]){
	int Monto=1000;
	for(int i=0; i<6; i++){
		m[i][0]=i+1;
		printf("\nIngrese el Rublo que al que desea asistir: (1-Artesan�a, 2-Gastronom�a o 3-Espect�culo)\n");
		scanf("%d", &m[i][1]);
		printf("\nNecesita una mesa o silla? (1.Si, 0.No) \n");
		scanf("%d", &m[i][2]);
		if(m[i][2]==1){
			m[i][3]=Monto+500;
		}
		if(m[i][2]==0){
			m[i][3]=Monto;
		}		
	}
}
	
void imprimirM(int m[6][5]){
	
	printf("\n\n***RESUMEN DE SOLICITUDES***\n\n");
	printf("N.\tRublo\tM/S\tMonto\tSec.\n");
	
	for(int i=0; i<6; i++){
		for(int j=0; j<5; j++){
			printf("%d\t", m[i][j]);
		}
		printf("\n");
	}
}
	
	
void mostrarRubro(int m[6][5]){
	int rubro=0;
	
	printf("\nIngrese el rubro a buscar: ");
	scanf("%d", &rubro);
	for(int i=0; i<6; i++){
		if(m[i][1]==rubro){
			printf("N.\tRublo\tM/S\tMonto\tSec.\n");
			printf("%d\t%d\t%d\t%d\t%d\n",m[i][0],m[i][1],m[i][2],m[i][3],m[i][4]);
		}
	}
}
	
	
int ganancias(int m[6][5]){
	int ganancias=0;
	
	for(int i=0; i<6; i++){
		ganancias=ganancias+m[i][3];
	}
	return ganancias;
}
	
	
	
