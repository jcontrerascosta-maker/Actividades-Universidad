#include <stdio.h>
#include <stdlib.h>

struct producto{
	int codigo;
	char nombre[50];
	int cantidad;
	int precio;
};

struct node{
	struct producto prod;
	struct node *next;
};


void menu();
void agregar(struct node **);
void mostrar(struct node *);
void borrar(struct node **, int codigo);
void mostrar_sin_stock(struct node *);


int main() {
	struct node *head = NULL;
	int option, codigo;
	
	do {
		menu();
		scanf("%d", &option);
		switch(option) {
		case 1:
			agregar(&head);
			break;
		case 2:
			mostrar(head);
			break;
		case 3:
			printf("Ingrese el codigo del producto a borrar: ");
			scanf("%d", &codigo);
			borrar(&head, codigo);
			break;
		case 4:
			mostrar_sin_stock(head);
			break;
		case 5:
			printf("Saliendo del programa.\n");
			break;
		default:
			printf("Opcion no valida.\n");
		}
	} while (option != 5);
	return 0;
}



void menu() {
	printf("Menu de opciones: \n");
	printf("1. Agregar producto\n");
	printf("2. Mostrar lista de productos\n");
	printf("3. Borrar producto por codigo\n");
	printf("4. Mostrar productos sin stock\n");
	printf("5. Salir\n");
	printf("Ingrese una opcion: ");
}


void agregar(struct node **head){
	struct node *new_node = (struct node *)malloc(sizeof(struct node));
	if(new_node==NULL){
		printf("\nNo hay memoria suficiente...\n");
		exit(1);
	}
	
	printf("\n\nIngrese los datos del producto:\n");
	printf("Codigo: ");
	scanf("%d", &new_node->prod.codigo);
	printf("\nNombre: ");
	scanf(" %s", new_node->prod.nombre);
	printf("\nCantidad: ");
	scanf("%d", &new_node->prod.cantidad);
	printf("\nPrecio: ");
	scanf("%d", &new_node->prod.precio);
	new_node->next=NULL;
	
	if(*head==NULL){
		*head = new_node;
	}else{
		struct node *temp= *head;
		while(temp->next!=NULL){
			temp = temp->next;
		}
		temp->next= new_node;
	}
	
	printf("\nProducto agregado correctamente.\n");
}
	
	
void mostrar(struct node *head){
	if(head==NULL){
		printf("\nLa lista esta vacia...\n");
		return;
	}
	
	struct node *temp= head;
	printf("\n\nLista de productos:\n\n");
	printf("Codigo\tNombre\t\tCantidad\t\tPrecio\n");
	
	while(temp != NULL){
		printf("%d\t%s\t\t%d\t%d\n", temp->prod.codigo, temp->prod.nombre, temp->prod.cantidad, temp->prod.precio);
		temp = temp->next;
	}
}
	
	
	

void borrar(struct node **head, int codigo){
	struct node *temp = *head;
	struct node *prev = NULL;
	
	if(temp == NULL){
		printf("\nLa lista esta vacia\n");
	}
	
	if(temp!=NULL && temp->prod.codigo==codigo){
		*head = temp->next;
		free(temp);
		printf("\nProducto eliminado\n");
		return;
	}
	
	while(temp!=NULL && temp->prod.codigo!=codigo){
		prev=temp;
		temp= temp->next;
	}
	
	if(temp==NULL){
		printf("\nProducto no encontrado");
		return;
	}
	
	prev->next=temp->next;
	free(temp);
	printf("\nProducto con codigo %d eliminado.\n", codigo);
}
	

void mostrar_sin_stock(struct node *head){
	if (head == NULL) {
		printf("\nLa lista de productos esta vacia.\n");
		return;
	}
	
	struct node *temp = head;
	int sin_stock = 0;
	
	printf("\n\nProductos sin stock:\n\n");
	printf("Codigo\tNombre\t\tPrecio\n");
	while (temp != NULL) {
		if (temp->prod.cantidad == 0) {
			printf("%d\t%s\t\t%d\n", temp->prod.codigo, temp->prod.nombre, temp->prod.precio);
			sin_stock = 1;
		}
		temp = temp->next;
	}
	
	if (!sin_stock) {
		printf("\nNo hay productos sin stock.\n");
	}
}
	
