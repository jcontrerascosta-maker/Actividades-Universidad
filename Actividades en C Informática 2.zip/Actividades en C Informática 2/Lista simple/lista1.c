#include <stdio.h>
#include <stdlib.h>

struct node {
	int data;
	struct node *next;
};

void append(struct node **, int);
void print(struct node *);

int main(){
	struct node *head = NULL;
	int valor;
	
	printf("\nIngrese 5 numeros:\n");
	
	for(int i=0; i<5; i++){
		scanf("%d", &valor);
		append(&head, valor);
	}
	printf("\nLista de valores ingresados:\n");
	print(head);
	return 0;
}


void append(struct node **head, int node_data){
	struct node *newNode = NULL;
	struct node *temp = *head;
	
	newNode = (struct node*)malloc(sizeof(struct node));
	if (newNode == NULL) {
		printf("No hay memoria disponible");
		exit(0); // Termina el programa si no hay memoria
	}
	
	newNode->data = node_data;
	newNode->next = NULL;
	
	if (*head == NULL) {
		*head = newNode;
		return;
	}
	
	while (temp->next != NULL) {
		temp = temp->next;
	}
	
	temp->next = newNode;
	
}
	void print(struct node *head) {
		struct node *temp = NULL;
		temp = head; // Puntero temporal para recorrer la lista
		
		// Recorre la lista imprimiendo el valor de cada nodo
		while (temp != NULL) {
			printf("%d\t", temp->data); // Imprime el valor actual del nodo
			temp = temp->next; // Avanza al siguiente nodo
		}
		printf("\n");
	}
	
