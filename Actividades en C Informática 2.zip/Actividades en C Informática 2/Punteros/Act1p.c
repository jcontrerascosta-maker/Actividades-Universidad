#include <stdio.h>

int main() {
	int Entero=1, *pInt=&Entero;
	float Flotante=1.0, *pFloat=&Flotante;
	char Caracter='a', *pChar=&Caracter;
	
	printf("\nEl valor Entero es %d", Entero);
	printf("\nLa direccion de memoria de Entero es %p", &Entero);
	printf("\nEl valor del puntero es %p", pInt);
	printf("\nEl valor al que apunta el puntero es %d", *pInt);
	
	printf("\n\n");
	printf("\nEl valor Flotante es %f", Flotante);
	printf("\nLa direccion de memoria de Entero es %p", &Flotante);
	printf("\nEl valor del puntero es %d", pFloat);
	printf("\nEl valor al que apunta el puntero es %f", *pFloat);
	
	printf("\n\n");
	
	printf("\nEl valor Caracter es %c ", Caracter);
	printf("\nLa direccion de memoria de Entero es %p", &Caracter);
	printf("\nEl valor del puntero es %d", pChar);
	printf("\nEl valor al que apunta el puntero es %c", *pChar);
	return 0;
}

