/*Escribir un programa que simule una calculadora, en 
donde muestre un men� de opciones con las operaciones 
permitidas como a. Suma, b. Resta, c. Multiplicaci�n y 
d. Divisi�n, e. elevar a una potencia, f. calcular la 
ra�z cuadrada de un n�mero. Luego el programa solicita 
que se ingrese dos n�meros (tipo float) y llame a la 
funci�n correspondiente para hacer el c�lculo. Luego 
mostrar el resultado y preguntar si desea realizar otra 
operaci�n o terminar el programa. Usar punteros para la 
resoluci�n de este ejercicio.
*/

#include <stdio.h>
#include <math.h>

void calcular_suma(float *, float, float);
void calcular_resta(float *, float, float);
void calcular_multiplicacion(float *, float, float);
void calcular_division(float *, float, float);
void calcular_potencia(float *, float, float);
void calcular_raiz(float *, float);

int main() {
	float res=0, n1=0, n2=0;
	char op=' ';
	
	printf("Ingrese dos numeros: \n");
	scanf("%f%f", &n1,&n2);
	
	do {
		printf("\nMenu: \n");
		printf("a. Suma\n");
		printf("b. Resta\n");
		printf("c. Multiplicaci�n\n");
		printf("d. Divisi�n\n");
		printf("e. Potencia\n");
		printf("f. Raiz Cuadrada\n");
		printf("s. Salir\n");
		printf("Seleccione una opci�n: ");
		scanf(" %c", &op);
		
		switch (op) {
		case 'a':
		case 'A':
			calcular_suma(&res, n1, n2);
			printf("Resultado de la suma: %.2f\n", res);
			break;
		case 'b':
		case 'B':
			calcular_resta(&res, n1, n2);
			printf("Resultado de la resta: %.2f\n", res);
			break;
		case 'c':
		case 'C':
			calcular_multiplicacion(&res, n1, n2);
			printf("Resultado de la multiplicaci�n: %.2f\n", res);
			break;
		case 'd':
		case 'D':
			calcular_division(&res, n1, n2);
			if (n2 != 0) {
				printf("Resultado de la divisi�n: %.2f\n", res);
			}
			break;
		case 'e':
		case 'E':
			calcular_potencia(&res, n1, n2);
			printf("Resultado de la potencia: %.2f\n", res);
			break;
		case 'f':
		case 'F':
			calcular_raiz(&res, n1);
			if (n1 >= 0) {
				printf("Resultado de la raiz: %.2f\n", res);
			}else{
				printf("No existen raices negativas");
			}
			break;
		case 's':
		case 'S':
			printf("Fin del programa\n");
			break;
		default:
			printf("Opci�n no v�lida.\n");
		}
	} while (op != 's' && op != 'S');
	
	return 0;
}

void calcular_suma(float *res, float n1, float n2) {
	*res = n1 + n2;
}

void calcular_resta(float *res, float n1, float n2) {
	*res = n1 - n2;
}

void calcular_multiplicacion(float *res, float n1, float n2) {
	*res = n1 * n2;
}

void calcular_division(float *res, float n1, float n2) {
	if (n2 != 0) {
		*res = n1 / n2;
	} else {
		printf("Lo siento, no se puede dividir por cero.\n");
	}
}

void calcular_potencia(float *res, float n1, float n2) {
	if (n2 != 0) {
		*res = pow(n1,n2);
	} else {
		printf("%.2f",n1);
	}
}

void calcular_raiz(float *res, float n1) {
	*res = sqrt(n1);
}
