#include <stdio.h>

void swap(int *, int*);
int main(){
	int a=5, b=3;
	
	printf("Valores antes del cambio:\n a.%d\tb.%d", a,b);
	swap(&a,&b);
	printf("\nValores actuales:\n a.%d\tb.%d", a,b);
	return 0;
}

void swap(int *a, int*b){
	int aux;
	aux=*a;
	*a=*b;
	*b=aux;
	
}
	
