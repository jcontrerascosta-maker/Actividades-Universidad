#include <stdio.h>

int main() {
	int VarEntera=15;
	float VarFlotante=5.5;
	char varChar= 'a';
	
	int *puntEntera= &VarEntera;
	float *puntFlotante= &VarFlotante;
	char *puntChar= &varChar;
	
	*puntEntera=10;
	*puntFlotante=10.5;
	*puntChar= 'b';
	
	printf("Nuevo valor de entero: %d\n", VarEntera);
	printf("Nuevo valor de flotante: %f\n", VarFlotante);
	printf("Nuevo valor de caracter: %c\n", varChar);
	
	
	return 0;
}

