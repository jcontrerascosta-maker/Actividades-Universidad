#include <stdio.h>

int restar_por_valor(int, int);
int restar_por_puntero(int *, int *);

int main() {
	int num1=0, num2=0;
	printf("Ingrese dos numeros:\n");
	scanf("%d\n%d", &num1, &num2);
	
	int resultado1 = restar_por_valor(num1, num2);
	printf("Resultado restado por valor: %d\n", resultado1);
	
	int resultado2 = restar_por_puntero(&num1, &num2);
	printf("Resultado restado por puntero: %d\n", resultado2);
	
	return 0;
}


int restar_por_valor(int a, int b) {
	return a + b;
}

int restar_por_puntero(int *a, int *b) {
	return *a + *b;
}
