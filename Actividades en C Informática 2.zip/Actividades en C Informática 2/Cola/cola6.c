#include <stdio.h>
#include <stdlib.h>

struct Producto{
	int codigo;
	char nombre[50];
	int cantidad;
	int precio;
};

struct node{
	struct Producto p;
	struct node *link;
};

int menu();

void agregar(struct node **, struct node **, struct Producto);
void borrar(struct node**, struct node**);
void mostrar(struct node*);
void descontar(struct node*, int, int);

int main() {
	struct node *front=NULL;
	struct node *back=NULL;
	struct Producto p;
	int op=0, codigo=0, cantidad=0;
	
	do{
		op=menu();
		switch(op){
		case 1: 
			printf("Ingrese un producto:\nCodigo: ");
			scanf("%d", &p.codigo);
			printf("Nombre: ");
			scanf(" %s", p.nombre);
			printf("Cantidad: ");
			scanf("%d", &p.cantidad);
			printf("Precio: ");
			scanf("%d", &p.precio);
			agregar(&front, &back, p);
			break;
		case 2: 
			borrar(&front, &back);
			break;
		case 3: 
			mostrar(front);
			break;
		case 4: 
			printf("Ingrese el codigo del producto y la cantidad a descontar:\n");
			scanf("%d%d", &codigo, &cantidad);
			descontar(front, codigo, cantidad);
			break;
		}
	} while(op<6);
	return 0;
}


int menu(void){
	int op=0;
	do{
		printf("--------------------------------------------\n");
		printf("1.- Agregar un nodo a la cola (producto)\n");
		printf("2.- Borrar el primer nodo de la cola\n");
		printf("3.- Imprimir cola\n");
		printf("4.- Descontar stock\n");
		printf("5.- Reponer stock\n");
		printf("6.- Salir\n");
		scanf("%d", &op);
		printf("--------------------------------------------\n");
	}while((op<1)||(op>6));
	return op;
}
	
	
void agregar(struct node **front, struct node **back, struct Producto p){
	struct node *temp= (struct node *)malloc(sizeof(struct node));
	if(temp==NULL){
		printf("\nNo hay memoria suficiente...\n");
		exit(0);
	}
	
	temp->p = p; 
	temp->link = NULL;
	
	if(back==NULL){
		*back = temp;
		*front = *back;
	}else{
		(*back)->link = temp;
		*back=temp;
	}
}
	
	
void borrar(struct node**front, struct node**back){
	struct node *temp;
	
	if(*front==*back && *back==NULL){
		printf("\nLa cola esta vacia...\n");
		exit(0);
	}
	
	temp = *front;
	*front = (*front)->link;
	
	if(*back==temp){
		*back = (*back)->link;
	}
	
	free(temp);
}


void mostrar(struct node *front){
	struct node *temp;
	temp=front;
	printf("Impresion de la cola\n");
	printf("Cod.\tNombre\tCant.\tPrecio\n");
	while(temp!=NULL){
		printf("%d\t%s\t%d\t%d\n", temp->p.codigo, temp->p.nombre, temp->p.cantidad, temp->p.precio);		
		temp=temp->link;
	}
}
	
	
	
	
	
void descontar(struct node*front, int codigo, int cantidad){
	struct node *temp;
	temp=front;
	
	while(temp!=NULL){
		if(temp->p.codigo==codigo){
			temp->p.cantidad= temp->p.cantidad-cantidad;
		}
		temp=temp->link;
	}
}
	
	
