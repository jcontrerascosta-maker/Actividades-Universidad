#include <stdio.h>
#include <stdlib.h>

void mostrar(char *ptr, int cant);

int main() {
	char *ptr;
	int cantidad, agregar;
	
	printf("Cuantos caracteres desea guardar?: \n");
	scanf("%d", &cantidad);
	ptr=(char *)malloc(cantidad*sizeof(char));
	
	printf("Ingrese los caracteres: \n");
	for(int i=0; i<cantidad; i++){
		scanf(" %c", &*(ptr+i));
	}
	
	mostrar(ptr, cantidad);
	
	printf("\nCuantos caracteres desea agregar?: ");
	scanf("%d", &agregar);
	
	ptr=(char *)realloc(ptr, agregar*sizeof(char));
	
	printf("Ingrese los caracteres: \n");
	for(int i=0; i<agregar; i++){
		scanf(" %c", &*(ptr+cantidad+i));
	}
	
	mostrar(ptr, (cantidad+agregar));
	free(ptr);
	return 0;
}

void mostrar(char *ptr, int cant){
	printf("Los caracteres son: \n");
	for(int i=0; i<cant; i++){
		printf("%c ", *(ptr+i));
	}
}
