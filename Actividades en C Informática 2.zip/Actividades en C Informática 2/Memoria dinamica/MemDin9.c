#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main() {
	int filas, columnas, bytes, sumatoria;
	int *valores;
	char opcion=' '; 
	
	printf("\nIngrese el numero de filas: ");
	scanf("%d", &filas);
	printf("\nIngrese el numero de columnas: ");
	scanf("%d", &columnas);
	bytes=filas*columnas;
	valores = (int*) malloc(bytes*sizeof(int));
	
	for (int i = 0; i<bytes; i++){
		*(valores+i)=rand() % 100+1;
	}
	
	do{
		printf("\nQue desea hacer?\na. Mostrar la sumatoria\nb. Mostrar valores\ns. Salir\n");
		scanf(" %c", &opcion);
		switch (opcion){
			case 'a':
				sumatoria=0;
				for (int i= 0; i<bytes; i++)
				{
					sumatoria=sumatoria+*(valores+i);
				}
				printf("%d", sumatoria);
				break;
			case 'b':
				for (int i= 0; i<bytes; i++)
				{
					printf("%d\t", *(valores+i));
				}
				break;
			case 's':
				free(valores);
				break;
			default:
				break;
		}
	}while (opcion!='s'&&opcion!='S');

	return 0;
}

