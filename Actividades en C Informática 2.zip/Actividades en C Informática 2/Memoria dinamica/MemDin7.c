#include <stdio.h>
#include <stdlib.h>

void cargar(char *, int, int );
void mostrar(char *ptr, int cant);

int main() {
	char *ptr;
	int cant=0, agregar=0;
	
	printf("Cuantos caracteres desea guardar?: \n");
	scanf("%d", &cant);
	ptr=(char *)malloc(cant*sizeof(char));
	
	cargar(ptr, cant, agregar);
	mostrar(ptr, cant);
	
	printf("\nCuantos caracteres desea agregar?: ");
	scanf("%d", &agregar);
	ptr=(char *)realloc(ptr, agregar*sizeof(char));
	
	printf("\n");
	cargar(ptr, cant, agregar);
	mostrar(ptr, (cant+agregar));
	
	free(ptr);
	return 0;
}


void cargar(char *ptr, int cant, int agregar){
	printf("Ingrese los caracteres: ");
	if(agregar==0){
		for(int i=0; i<(cant+agregar); i++){
			scanf(" %c", (ptr+i));
		}
	}else{
		for(int i=0; i<agregar; i++){
			scanf(" %c", (ptr+(agregar+1)+i));
		}
	}

	
}
	
void mostrar(char *ptr, int cant){
	printf("Los caracteres son: ");
	for(int i=0; i<cant; i++){
		printf("%c ", *(ptr+i));
		}
	}

