#include <stdio.h>
#include <stdlib.h>

int main() {
	char *ptr;
	int cantidad, agregar;
	
	printf("Cuantos caracteres desea guardar?: \n");
	scanf("%d", &cantidad);
	ptr=(char *)malloc(cantidad*sizeof(char));
	
	printf("Ingrese los caracteres: \n");
	for(int i=0; i<cantidad; i++){
		scanf(" %c", &*(ptr+i));
	}
	
	printf("Los caracteres son: \n");
	for(int i=0; i<cantidad; i++){
		printf("%c ", *(ptr+i));
	}
	
	printf("\nCuantos caracteres desea agregar?: ");
	scanf("%d", &agregar);
	
	ptr=(char *)realloc(ptr, agregar*sizeof(char));
	
	printf("Ingrese los caracteres: \n");
	for(int i=0; i<agregar; i++){
		scanf(" %c", &*(ptr+cantidad+i));
	}
	
	printf("Los caracteres son: \n");
	for(int i=0; i<(cantidad+agregar); i++){
		printf("%c ", *(ptr+i));
	}
	free(ptr);
	return 0;
}

