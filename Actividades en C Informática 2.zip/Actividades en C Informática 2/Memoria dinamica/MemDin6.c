#include <stdio.h>
#include <stdlib.h>

void cargar(char *, int );
void mostrar(char *ptr, int cant);
void inverso(char *ptr, int cant);

int main() {
	char *ptr;
	int cant;
	
	printf("Cunantos caracteres desea cargar?: ");
	scanf("%d", &cant);
	ptr=(char *)malloc(cant*sizeof(char));
	
	cargar(ptr, cant);
	mostrar(ptr, cant);
	inverso(ptr, cant);
	return 0;
}

void cargar(char *ptr, int cant){
	
	for(int i=0; i<cant; i++){
		scanf(" %c", (ptr+i));
	}
	
}
	
void mostrar(char *ptr, int cant){
	for(int i=0; i<cant; i++){
		printf("%c ", *(ptr+i));
	}
}
	
void inverso(char *ptr, int cant){
	for(int i=cant-1; i>=0; i--){
		printf("\n%c ", *(ptr+i));
	}
}
	
	
