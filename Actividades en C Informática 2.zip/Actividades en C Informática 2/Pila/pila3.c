#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

struct node{
	int num;
	struct node *next;
};

int menu(void);
void push(struct node **, int);
void pop(struct node **);
bool vacio(struct node *);
void print(struct node **);

int main(){
	struct node *sp = NULL;
	int num, op=0;
	srand(time(NULL));
	
	do{
		op=menu();
		switch(op){
		case 1:
		{
			for(int i=0; i<5;i++){
				num=rand()%10+1;
				push(&sp, num);
			}
			printf("Valores cargados.\n");
			break;
		}
		case 2:
		{
			pop(&sp);
			break;
		}
		case 3:
		{
			print(&sp);
			break;
		}
//		case 4:
//		{
//			printf("El tama�o de la pila: %d\n", size(&sp));
//			break;
//		}
//		case 5:
//		{
//			top(&sp);
//			break;
//		}
		}
	} while(op<6);
	return 0;
}
	
int menu(void){
	int op=0;
	do{
		printf("--------------------------------------------\n");
		printf("1.- Agregar un nodo a la pila\n");
		printf("2.- Borrar un nodo de la pila\n");
		printf("3.- Imprimir pila\n");
		printf("4.- Tama�o de la pila\n");
		printf("5.- Ultimo valor de la pila\n");
		printf("6.- Salir\n");
		scanf("%d", &op);
		printf("--------------------------------------------\n");
	}while((op<1)||(op>6));
	return op;
}
		
		
void push(struct node **sp, int num){
	struct node *new_node = (struct node *)malloc(sizeof(struct node));
	if(new_node==NULL){
		printf("\nMemoria insuficiente...\n");
		exit(0);
	}
	
	new_node->num= num;
	new_node->next= *sp;
	*sp= new_node;
}
		

bool vacio(struct node *sp){
	if(sp==NULL){
		return(true);
	}else{
		return(false);
	}
}
	
	
void pop(struct node **sp){
	if(vacio(*sp)==false){
		struct node *temp= NULL;
		temp=*sp;
		*sp = (*sp)->next;
		free(temp);
	}else{
		printf("Pila vacia\n");
	}
}
	
void print(struct node **sp){
	if(vacio(*sp)==false){
		struct node *temp= NULL;
		temp=*sp;
		
		while(temp!=NULL){
			printf("%d\t", temp->num);
			temp=temp->next;
		}
	}else{
		printf("Pila vacia\n");
	}
}
	
