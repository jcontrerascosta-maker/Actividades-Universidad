/*Registro de Ventas
	
	Desarrolla un programa que permita la gesti�n de registro de ventas en una tienda de electronica de este a�o utilizando el TDA lista. Para ello cree la/las estructura/s que necesite para almacenar la siguiente informaci�n sobre c�digo de producto (entero), nombre de producto (cadena), cantidad vendida, precio unitario, d�a y mes. Desarrolla las siguientes funciones para: 
	
	Registrar una nueva venta.
	Mostrar un listado de todas las ventas por consola y generar un archivo .txt llamado "ventas.txt", ambos en formato tabla. 
	Borrar una venta 
	Mostrar un listado de ventas por mes en formato tabla. 
	Calcular la cantidad de ventas mayores a 1000. 
	Crea un men� de opciones para que el usuario pueda realizar diferentes acciones antes descritas. 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Producto{
	int cod;
	char nom[25];
	int cant_vent;
	int mes;
};

struct Node{
	struct Producto product;
	struct Node *next;
};


void nuevo_producto(struct Producto *product, int i);
void guardar(struct Node **head, struct Producto prod);
void mostrarLista(struct Node *head);
void generar_archivo(struct Node *head);
void borrar(struct Node **head);
void mostrarMes(struct Node *head);


int main() {
	struct Producto product;
	struct Node *head = NULL;
	int cant=0;
	int op=0;
	
	do{
		printf("\n*****MENU DE OPCIONES*****\n\n");
		printf("1.Agregar venta\n2.Mostrar Ventas\n3.Borrar Venta\n4.Filtrar por mes\n5.Salir\n");
		scanf("%d", &op);
		
		switch(op){
			case 1:
				printf("\nCuantas ventas desea agregar? ");
				scanf("%d", &cant);
				for(int i=0; i<cant; i++){
					nuevo_producto(&product, i);
					guardar(&head, product);
				}
				break;
				
			case 2:
				mostrarLista(head);
				generar_archivo(head);
				break;
				
			case 3:
				borrar(&head);
				break;
				
			case 4:
				mostrarMes(head);
				break;
				
			case 5:
				printf("Saliendo...");
				break;
				
			default:
				printf("\nNumero invalido, intente nuevamente...\n");
				break;
		}
	} while(op!=5);
	
	return 0;
}



void nuevo_producto(struct Producto *product, int i){
	printf("\nIngrese los datos de la nueva venta:\n");
	printf("\nProducto n�: %d", i+1);
	(product)->cod = i+1;
	printf("\nIngrese el nombre del producto: ");
	scanf("%s", (product)->nom);
	printf("\nIngrese la cantidad de ventas: ");
	scanf("%d", &(product)->cant_vent);
	printf("\nMes: ");
	scanf("%d", &(product)->mes);
}
	

void guardar(struct Node **head, struct Producto prod){
	struct Node *newnode = (struct Node*)malloc(sizeof(struct Node));
	if(newnode == NULL){
		printf("\nERROR, memoria insuficiente...\n");
		exit(1);
	}
	
	newnode->product = prod;
	newnode->next = NULL;
	
	if(*head == NULL){
		*head = newnode;
	}else{
		struct Node *temp = *head;
		while(temp->next != NULL){
			temp = temp->next;
		}
		temp->next = newnode;
	}
}	
	

void generar_archivo(struct Node *head){
	FILE *archivo = fopen("ventas.txt", "w");
	if(archivo == NULL){
		printf("\nError al abrir el archivo...");
		exit(1);
	}
	fprintf(archivo, "%-20s\t%-20s\t%-20s\t%-20s\n", "Codigo", "Nombre del producto", "Cant de ventas", "Mes");
	
	struct Node *temp = head;
	
	while(temp != NULL){
		fprintf(archivo, "%-20d\t%-20s\t%-20d\t%-20d\n", temp->product.cod, temp->product.nom, temp->product.cant_vent, temp->product.mes);
		temp = temp->next;
	}
	fclose(archivo);
	printf("\nProducto agregado con exito\n");
}
	
	
void mostrarLista(struct Node *head){
	if(head==NULL){
		printf("\nLa lista de ventas esta vacia\n");
		return;
	}
	
	printf("%-20s\t%-20s\t%-20s\t%-20s\n", "Codigo", "Nombre del producto", "Cant de ventas", "Mes");
	struct Node *temp = head;
	while(temp != NULL){
		printf("%-20d\t%-20s\t%-20d\t%-20d\n", temp->product.cod, temp->product.nom, temp->product.cant_vent, temp->product.mes);
		temp = temp->next;
	}
}
	
	
void borrar(struct Node **head){
	int buscar=0;
	
	if(*head == NULL){
		printf("\nLa lista esta vacia\n");
		return;
	}else{
		printf("\nIngrese el codigo del producto que desea eliminar: ");
		scanf("%d", &buscar);
		struct Node *temp = *head;
		struct Node *prev = NULL;
		
		if(temp!=NULL && temp->product.cod==buscar){
			*head = temp->next;
			free(temp);
			printf("\nVenta del producto %d eliminada\n", buscar);
			return;
		}
		
		while(temp!=NULL && temp->product.cod!=buscar){
			prev = temp;
			temp = temp->next;
		}
		if(temp == NULL){
			printf("\nProducto no encontrado");
			return;
		}else{
			prev->next = temp->next;
			free(temp);
			printf("\nProducto eliminado con exito");
		}
	}
}
	
void mostrarMes(struct Node *head){
	if(head==NULL){
		printf("\nLa lista de ventas esta vacia\n");
		return;
	}
	int buscar;
	printf("\nQue mes desea buscar? ");
	scanf("%d", &buscar);
	printf("%-20s\t%-20s\t%-20s\t%-20s\n", "Codigo", "Nombre del producto", "Cant de ventas", "Mes");
	struct Node *temp = head;
	while(temp != NULL){
		if(temp->product.mes == buscar){
			printf("%-20d\t%-20s\t%-20d\t%-20d\n", temp->product.cod, temp->product.nom, temp->product.cant_vent, temp->product.mes);
		}
		temp = temp->next;
	}
}
	
