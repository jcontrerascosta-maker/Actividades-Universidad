#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

struct viaje{
	int num;
	char nombre[25];
	float costo;
	int mes;
};

struct node{
	struct viaje v;
	struct node *next;
};


void viaje(struct viaje *reserva, int i);
void nuevaPila(struct node **sp, struct viaje reserva);
void mostrar(struct node *sp);
void generar_archivo(struct node *sp);
void borrar(struct node **sp);


int main() {
	struct viaje reserva;
	struct node *sp = NULL;
	int op=0, cant=0;
	srand(time(NULL));
	
	do{
		printf("\n*****MENU DE OPCIONES*****\n\n");
		printf("1.Agregar reserva\n2.Mostrar reserva\n3.Borrar reserva\n4.Filtrar por mes\n5.Salir\n");
		scanf("%d", &op);
		
		switch(op){
		case 1:
			printf("\nCuantas reservas desea agregar? ");
			scanf("%d", &cant);
			for(int i=0; i<cant; i++){
				viaje(&reserva, i);
				nuevaPila(&sp, reserva);
			}
			break;
			
		case 2:
			mostrar(sp);
			generar_archivo(sp);
			break;
			
		case 3:
			borrar(&sp);
			break;
			
		case 4:
			break;
			
		case 5:
			printf("Saliendo...");
			break;
			
		default:
			printf("\nNumero invalido, intente nuevamente...\n");
			break;
		}
	} while(op!=5);
	
	return 0;
}

void viaje(struct viaje *reserva, int i){
	printf("\n\nIngrese los datos de la reserva n� %d", i+1);
	reserva->num = i+1;
	printf("\nIngrese el nombre del viajante: ");
	scanf("%s", reserva->nombre);
	reserva->costo = 1 + rand()%200;
	reserva->mes = 1 + rand()%(12-1+1);
	printf("\nCosto de la reserva: %.2f\nMes de la reserva: %d", reserva->costo,reserva->mes);
}
	
void nuevaPila(struct node **sp, struct viaje reserva){
	struct node *newNode = NULL;
	newNode = (struct node*)malloc(sizeof(struct node));
	if (newNode == NULL) {
		printf("No hay memoria disponible");
		exit(1);
	}
	
	newNode->v = reserva;
	newNode->next = *(sp);
	*(sp) = newNode;
}
	
	
void mostrar(struct node *sp){
	if(sp==NULL){
		printf("\nLa lista de ventas esta vacia\n");
		return;
	}
	
	printf("%-20s\t%-20s\t%-20s\t%-20s\n", "Numero de reserva", "Nombre del viajante", "Costo del viaje", "Mes");
	struct node *temp = sp;
	while(temp != NULL){
		printf("%-20d\t%-20s\t%-20.2f\t%-20d\n", temp->v.num, temp->v.nombre, temp->v.costo, temp->v.mes);
		temp = temp->next;
	}
}
	
	
	
	
void generar_archivo(struct node *sp){
	FILE *archivo = fopen("reservas.txt", "w");
	if(archivo == NULL){
		printf("\nError al abrir el archivo...");
		exit(1);
	}
	fprintf(archivo, "%-20s\t%-20s\t%-20s\t%-20s\n", "Numero de reserva", "Nombre del viajante", "Costo del viaje", "Mes");
	
	struct node *temp = sp;
	while(temp != NULL){
		fprintf(archivo, "%-20d\t%-20s\t%-20.2f\t%-20d\n", temp->v.num, temp->v.nombre, temp->v.costo, temp->v.mes);
		temp = temp->next;
	}
	fclose(archivo);
	printf("\nProducto agregado con exito\n");
}
		
	
	

	
void borrar(struct node **sp){
	if(*sp == NULL){
		printf("\nLa lista esta vacia\n");
		return;
	}else{
		struct node *temp = *(sp);
		*(sp) = (*sp)->next;
		free(temp);
	}
}
	
