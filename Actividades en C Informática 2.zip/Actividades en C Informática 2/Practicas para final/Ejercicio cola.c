/*
Gesti�n de propiedades
	
	Desarrolla un programa que permita la gesti�n de propiedades en venta y/o en alquiler de una inmobiliaria utilizando el TDA cola. Para ello cree la/las estructura/s que necesite para almacenar la siguiente informaci�n sobre c�digo de propiedad (entero), m2 de terreno (decimal), m2 cubiertos (decimal), tipo operaci�n (En venta/En alquiler), precio (decimal), ubicaci�n (cadena) y el estado actual de la propiedad (Desocupada/Ocupada)
	
	Desarrolla las siguientes funciones para: 
	
	Registrar una nueva propiedad. 
	Mostrar un listado de todas las propiedades por consola y generar un archivo .txt llamado "propiedades.txt", ambos en formato tabla. 
	Borrar una propiedad 
	Mostrar un listado de propiedades por tipo de operaci�n en formato tabla. 
	Calcular la cantidad de propiedades ocupadas y desocupadas. 
	Crea un men� de opciones para que el usuario pueda realizar diferentes acciones antes descritas. 
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Propiedades{
	int cod;
	float terreno;
	int operacion;
	char ubicacion[25];
};

struct node{
	struct Propiedades p;
	struct node *link;
};


void nuevaPropiedad(struct Propiedades *propiedad, int i);
void guardarPropiedad(struct node **front, struct node **back, struct Propiedades propiedad);
void mostrar(struct node *front);
void registrar(struct node *front);
void borrar(struct node **front, struct node **back);
void filtrarPorOperacion(struct node *front);

int main() {
	struct Propiedades propiedad;
	struct node *front = NULL;
	struct node *back = NULL;
	int op=0, cant=0;
		
	do{
		printf("\n*****MENU DE OPCIONES*****\n\n");
		printf("1.Agregar propiedad\n2.Mostrar propiedades\n3.Borrar propiedad\n4.Filtrar por operacion\n5.Salir\n");
		scanf("%d", &op);
		
		switch(op){
			case 1:
				printf("\nCuantas propiedades desea agregar? ");
				scanf("%d", &cant);
				for(int i=0; i<cant; i++){
					nuevaPropiedad(&propiedad, i);
					guardarPropiedad(&front, &back, propiedad);
				}
				break;
				
			case 2:
				mostrar(front);
				registrar(front);
				break;
				
			case 3:
				borrar(&front, &back);
				break;
				
			case 4:
				filtrarPorOperacion(front);
				break;
				
			case 5:
				printf("Saliendo...");
				break;
				
			default:
				printf("\nNumero invalido, intente nuevamente...\n");
				break;
		}
	} while(op!=5);
	
	return 0;
}



void nuevaPropiedad(struct Propiedades *propiedad, int i){
	printf("\nPropiedad n�: %d", i+1);
	propiedad->cod = i+1;
	printf("\nINgrese los m2 del terreno: ");
	scanf("%f", &propiedad->terreno);
	printf("Estado de la propiedad: En venta(1) o en alquiler(2)  ");
	scanf("%d", &propiedad->operacion);
	printf("Ingrese la ubicacion: ");
	scanf("%s", propiedad->ubicacion);
}
	

void guardarPropiedad(struct node **front, struct node **back, struct Propiedades propiedad){
	struct node *temp = (struct node*)malloc(sizeof(struct node));
	if(temp == NULL){
		printf("\nERROR, memoria insuficiente...\n");
		exit(1);
	}
	
	temp->p = propiedad;
	temp->link = NULL;
	
	if(*back==NULL){
		*front = temp;
		*back = temp;
	}else{
		(*back)->link = temp;
		*back = temp;
	}
	printf("\nPropiedades agregadas con �xito!\n\n");
}
	

void mostrar(struct node *front){
	struct node *temp = front;
	
	printf("\n%-20s\t%-20s\t%-20s\t%-20s\n", "Codigo", "m2 del terreno", "operacion", "ubicacion");
	while(temp != NULL){
		char *estado = (temp->p.operacion == 1) ? "En venta" : "En alquiler";
		printf("%-20d\t%-20.2f\t%-20s\t%-20s\n", temp->p.cod, temp->p.terreno, estado, temp->p.ubicacion);
		temp = temp->link;
	}
}
	
	
void registrar(struct node *front){
	FILE *archivo = fopen("propiedades.txt", "w");
	if(archivo == NULL){
		printf("\nError al abrir el archivo...");
		exit(1);
	}
	
	struct node *temp = front;
	
	fprintf(archivo, "\n%-20s\t%-20s\t%-20s\t%-20s\n", "Codigo", "m2 del terreno", "operacion", "ubicacion");
	while(temp != NULL){
		char *estado = (temp->p.operacion == 1) ? "En venta" : "En alquiler";
		fprintf(archivo,"%-20d\t%-20.2f\t%-20s\t%-20s\n", temp->p.cod, temp->p.terreno, estado, temp->p.ubicacion);
		temp = temp->link;
	}
	
	fclose(archivo);
}
	
	
	
void borrar(struct node **front, struct node **back){
	if(*front==*back && *back==NULL){
		printf("\nLa cola esta vacia...\n");
		return;
	}
	
	struct node *temp;
	
	temp = *front;
	*front = (*front)->link;
	
	if(*front == NULL){
		*back = NULL;
	}
	printf("\nPropiedad eliminada con exito!");
	free(temp);
}

	
	
	void filtrarPorOperacion(struct node *front) {
		if (front == NULL) {
			printf("\nNo hay propiedades registradas.\n");
			return;
		}
		
		int filtro;
		printf("\nIngrese el tipo de operaci�n a filtrar (1: En venta, 2: En alquiler): ");
		scanf("%d", &filtro);
		
		if (filtro != 1 && filtro != 2) {
			printf("\nOperaci�n inv�lida. Debe ser 1 o 2.\n");
			return;
		}
		
		struct node *temp = front;
		int encontrado = 0;
		
		printf("\n%-20s\t%-20s\t%-20s\t%-20s\n", "Codigo", "m2 del terreno", "Operacion", "Ubicacion");
		
		while (temp != NULL) {
			if (temp->p.operacion == filtro) {
				char *estado = (temp->p.operacion == 1) ? "En venta" : "En alquiler";
				printf("%-20d\t%-20.2f\t%-20s\t%-20s\n", temp->p.cod, temp->p.terreno, estado, temp->p.ubicacion);
				encontrado = 1;
			}
			temp = temp->link;
		}
		
		if (!encontrado) {
			printf("\nNo hay propiedades con esta operaci�n.\n");
		}
	}
	
	
	
	
	
	
