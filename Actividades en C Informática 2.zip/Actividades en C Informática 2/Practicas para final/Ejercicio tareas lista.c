#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct tareas{
	int num;
	char nombre[25];
	int duracion;
	int estado;
};

struct node{
	struct tareas t;
	struct node *next;
};


void agregar(struct tareas *tarea, int i);
void guardar(struct node **head, struct tareas tarea);
void mostrarLista(struct node *head);
void generarArchivo(struct node *head);
void borrar(struct node **head);
void calcularPorcentaje(struct node *head);
	
int main() {
	struct node *head = NULL;
	struct tareas Tarea;
	int op=0, cant=0;
	
	do{
		printf("\n*****MENU DE OPCIONES*****\n\n");
		printf("1.Agregar tarea\n2.Mostrar tareas\n3.Borrar tarea\n4.Calcular porcentaje del proyecto\n5.Salir\n");
		scanf("%d", &op);
		
		switch(op){
		case 1:
			printf("\nCuantas ventas desea agregar? ");
			scanf("%d", &cant);
			for(int i=0; i<cant; i++){
				agregar(&Tarea, i);
				guardar(&head, Tarea);
			}
			break;
			
		case 2:
			mostrarLista(head);
			generarArchivo(head);
			break;
			
		case 3:
			borrar(&head);
			break;
			
		case 4:
			calcularPorcentaje(head);
			break;
			
		case 5:
			printf("Saliendo...");
			break;
			
		default:
			printf("\nNumero invalido, intente nuevamente...\n");
			break;
		}
	} while(op!=5);
	
	return 0;
}


void agregar(struct tareas *tarea, int i){
	printf("Tarea n� %d", i+1);
	tarea->num = i+1;
	printf("\nIngrese el nombre de la tarea: ");
	scanf("%s", tarea->nombre);
	printf("\nIngrese la duracion de la tarea en horas: ");
	scanf("%d", &tarea->duracion);
	printf("Ingrese el estado de la tarea: pendiente(1)-terminada(2)-retrasada(3)\n");
	scanf("%d", &tarea->estado);
}

	
	
void guardar(struct node **head, struct tareas tarea){
	struct node *newnode = (struct node *)malloc(sizeof(struct node));
	if(newnode == NULL){
		printf("\nERROR, memoria insuficiente...\n");
		exit(1);
	}
	
	newnode->t = tarea;
	newnode->next = NULL;
	
	if(*head==NULL){
		*head = newnode;
	}else{
		struct node *temp = *head;
		while(temp->next != NULL){
			temp = temp->next;
		}
		temp->next = newnode;
	}
}
	

void mostrarLista(struct node *head){
	struct node *temp = head;
	
	printf("%-20s\t%-20s\t%-20s\n", "Nombre de la tarea", "Duracion (hs)", "Estado");
	while(temp != NULL){
		char *estado;
		switch(temp->t.estado){
			case 1: estado = "Pendiente"; break;
			case 2: estado = "Terminada"; break;
			case 3: estado = "Retrasada"; break;
		}
		printf("%-20s\t%-20d\t%-20s\n", temp->t.nombre,temp->t.duracion, estado);
		temp = temp->next;
	}
}
	

void generarArchivo(struct node *head){
	FILE *archivo = fopen("tareas.txt", "w");
	if(archivo == NULL){
		printf("\nError al abrir el archivo...");
		exit(1);
	}
	fprintf(archivo, "%-20s\t%-20s\t%-20s\t%-20s\n", "Numero de tarea", "Nombre de la tarea", "Duracion (hs)", "Estado");
	
	struct node *temp = head;
	
	while(temp != NULL){
		char *estado;
		switch(temp->t.estado){
		case 1: estado = "Pendiente"; break;
		case 2: estado = "Terminada"; break;
		case 3: estado = "Retrasada"; break;
		}
		fprintf(archivo, "%-20d\t%-20s\t%-20d\t%-20s\n", temp->t.num, temp->t.nombre,temp->t.duracion, estado);
		temp = temp->next;
	}
	fclose(archivo);
	printf("\nProducto agregado con exito\n");
}
	
void borrar(struct node **head){
	int buscar = 0;
	if(*head == NULL){
		printf("\nLa lista esta vac�a...\n");
		return;
	}else{
		printf("\nIngrese el codigo del producto que desea eliminar: ");
		scanf("%d", &buscar);
		struct node *temp = *head;
		struct node *prev = NULL;
		
		if(temp!=NULL && temp->t.num==buscar){
			*head = temp->next;
			free(temp);
			printf("\nTarea %d eliminada\n", buscar);
			return;
		}
		
		while(temp!=NULL && temp->t.num!=buscar){
			prev = temp;
			temp = temp->next;
		}
		
		if(temp == NULL){
			printf("\nTarea no encontrada");
			return;
		}else{
			prev->next = temp->next;
			free(temp);
			printf("\nTarea eliminada con exito");
		}
	}
}
	
void calcularPorcentaje(struct node *head) {
	int total = 0, terminadas = 0;
	struct node *temp = head;
	
	while (temp != NULL) {
		total++;
		if (temp->t.estado == 2) {
			terminadas++;
		}
		temp = temp->next;
	}
		
	if (total == 0) {
		printf("\nNo hay tareas registradas.\n");
	} else {
		float porcentaje = ((float)terminadas / total) * 100;
		printf("\nPorcentaje de trabajo realizado: %.2f%%\n", porcentaje);
	}
}
	
