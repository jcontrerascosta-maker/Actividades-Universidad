#include <stdio.h>
#include <stdlib.h>

struct Modelo{
	int num;
	char nombre[25];
	int stock;
	float precio;
};

struct node{
	struct Modelo m;
	struct node *next;
};


void nuevo(struct Modelo *autoo, int i);
void agregar_lista(struct node **head, struct Modelo autoo);
void mostrar(struct node *head);
void generar_archivo(struct node *head);
void borrar(struct node **head);
void total(struct node *head);

int main(int argc, char *argv[]) {
	struct Modelo autoo;
	struct node *head = NULL;
	int op=0, cant=0;
		
	do{
		printf("\n*****MENU DE OPCIONES*****\n\n");
		printf("1.Agregar modelo\n2.Mostrar modelos\n3.Borrar modelos\n4.Valor total del inventario\n5.Salir\n");
		scanf("%d", &op);
			
		switch(op){
			case 1:
				printf("\nCuantas ventas desea agregar? ");
				scanf("%d", &cant);
				for(int i=0; i<cant; i++){
					nuevo(&autoo, i);
					agregar_lista(&head, autoo);
				}
				break;
				
			case 2:
				mostrar(head);
				generar_archivo(head);
				break;
				
			case 3:
				borrar(&head);
				break;
				
			case 4:
				total(head);
				break;
				
			case 5:
				printf("Saliendo...");
				break;
				
			default:
				printf("\nNumero invalido, intente nuevamente...\n");
				break;
		}
	} while(op!=5);
		
	return 0;
}

void nuevo(struct Modelo *autoo, int i){
	printf("\nIngrese los datos del nuevo modelo:\n");
	printf("\nModelo n�: %d", i+1);
	autoo->num = i+1;
	printf("\nIngrese el nombre del modelo: ");
	scanf("%s", autoo->nombre);
	printf("\nIngrese el stock: ");
	scanf("%d", &autoo->stock);
	printf("\nIngrese el precio del modelo: ");
	scanf("%f", &autoo->precio);
}
	

void agregar_lista(struct node **head, struct Modelo autoo){
	struct node *newnode = (struct node *)malloc(sizeof(struct node));
	if(newnode == NULL){
		printf("\nERROR, memoria insuficiente...\n");
		exit(1);
	}
	
	newnode->m = autoo;
	newnode->next = NULL;
	
	if(*head == NULL){
		*head = newnode;
	}else{
		struct node *temp = *head;
		while(temp->next != NULL){
			temp = temp->next;
		}
		temp->next = newnode;
	}
}
	
void mostrar(struct node *head){
	if(head == NULL){
		printf("\n La lista esta vac�a...");
		return;
	}
	printf("\n*****LISTA DE MODELOS*****\n");
	printf("%-20s\t%-20s\t%-20s\t%-20s\n", "Codigo del modelo", "Nombre del modelo", "Stock", "Precio unitario");
	struct node *temp = head;
	while(temp != NULL){
		printf("%-20d\t%-20s\t%-20d\t%-20.2f\n", temp->m.num, temp->m.nombre, temp->m.stock, temp->m.precio);
		temp = temp->next;
	}
}
	
	
void generar_archivo(struct node *head){
	FILE *archivo = fopen("inventario.txt", "w");
	if(archivo == NULL){
		printf("\nError al abrir el archivo...");
		exit(1);
	}
	
	fprintf(archivo, "\n*****LISTA DE MODELOS*****\n");
	fprintf(archivo,"%-20s\t%-20s\t%-20s\t%-20s\n", "Codigo del modelo", "Nombre del modelo", "Stock", "Precio unitario");
	struct node *temp = head;
	while(temp != NULL){
		fprintf(archivo, "%-20d\t%-20s\t%-20d\t%-20.2f\n", temp->m.num, temp->m.nombre, temp->m.stock, temp->m.precio);
		temp = temp->next;
	}
	fclose(archivo);
	printf("\nModelo agregado con exito\n");
}
	
	
void borrar(struct node **head){
	int buscar=0;
	if(*head == NULL){
		printf("\nLa lista esta vacia\n");
		return;
	}else{
		printf("\nIngrese el codigo del producto que desea eliminar: ");
		scanf("%d", &buscar);	
		
		struct node *temp = *head;
		struct node *prev = NULL;
		
		if(temp!=NULL && temp->m.num==buscar){
			*head = temp->next;
			free(temp);
			printf("\nVenta del producto %d eliminada\n", buscar);
			return;
		}
		
		while(temp!=NULL && temp->m.num!=buscar){
			prev = temp;
			temp = temp->next;		
		}
		
		if(temp == NULL){
			printf("\nProducto no encontrado");
			return;
		}else{
			prev->next = temp->next;
			free(temp);
			printf("\nProducto eliminado con exito");
		}
	}
}
	

	
void total(struct node *head){
	struct node *temp = head;
	float valor = 0;
	while(temp != NULL){
		valor = (valor + (temp->m.precio * temp->m.stock));
		temp = temp->next;
	}
	printf("\n El precio total del inventario es $ %.2f", valor);
}
	
	
