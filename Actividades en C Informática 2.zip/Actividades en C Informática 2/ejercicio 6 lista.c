#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Estructura del producto
struct producto {
	int codigo;
	char nombre[50];
	int cantidad;
	float precio;
};

// Estructura del nodo de la lista enlazada
struct node {
	struct producto prod;
	struct node *next;
};

void agregar_producto(struct node **head);
void mostrar_productos(struct node *head);
void borrar_producto(struct node **head, int codigo);
void mostrar_sin_stock(struct node *head);
void menu();


int main() {
	struct node *head = NULL;
	int option, codigo;
	
	do {
		menu();
		scanf("%d", &option);
		switch(option) {
		case 1:
			agregar_producto(&head);
			break;
		case 2:
			mostrar_productos(head);
			break;
		case 3:
			printf("Ingrese el codigo del producto a borrar: ");
			scanf("%d", &codigo);
			borrar_producto(&head, codigo);
			break;
		case 4:
			mostrar_sin_stock(head);
			break;
		case 5:
			printf("Saliendo del programa.\n");
			break;
		default:
			printf("Opcion no valida.\n");
		}
	} while (option != 5);
	
	return 0;
}


void agregar_producto(struct node **head){
	struct node *new_node = (struct node *)malloc(sizeof(struct node));
	if(new_node==NULL){
		printf("\nMemoria insuficiente...\n");
		exit(1);
	}
	
	printf("\n\nIngrese los datos del producto:\n");
	printf("Codigo: ");
	scanf("%d", &new_node->prod.codigo);
	printf("Nombre: ");
	scanf(" %s", new_node->prod.nombre);
	printf("Cantidad: ");
	scanf("%d", &new_node->prod.cantidad);
	printf("Precio: ");
	scanf("%f", &new_node->prod.precio);
	new_node->next = NULL;
	
	if(*head==NULL){
		*head = new_node;
	}else{
		struct node *temp = *head;
		while(temp->next != NULL){
			temp = temp->next;
		}
		temp->next = new_node;
	}
	printf("\nProducto agregado correctamente.\n");
}

	
void mostrar_productos(struct node *head){
	struct node *temp = head;
	while(temp != NULL){
		printf("%d\t%s\t\t%d\t%.2f\n", temp->prod.codigo, temp->prod.nombre, temp->prod.cantidad, temp->prod.precio);
		temp = temp->next;	
	}
}
	

void borrar_producto(struct node **head, int codigo){
	struct node *temp = *head;
	struct node *prev = NULL;
	
	if(temp == NULL){
		printf("\nNO hay elementos en la lista\n");
	}
	
	if(temp!=NULL && temp->prod.codigo==codigo){
		*head = temp->next;
		free(temp);
		printf("\nProducto con codigo %d eliminado.\n", codigo);
		return;
	}
	
	while(temp!=NULL && temp->prod.codigo!=codigo){
		prev = temp;
		temp = temp->next;
	}
	
	if (temp == NULL) {
		printf("\nProducto con codigo %d no encontrado.\n", codigo);
		return;
	}
	
	prev->next = temp->next;
	free(temp);
	printf("\nProducto con codigo %d eliminado.\n", codigo);
}
	
	

	// Funcion para mostrar los productos sin stock (cantidad == 0)
	void mostrar_sin_stock(struct node *head) {
		if (head == NULL) {
			printf("\nLa lista de productos esta vacia.\n");
			return;
		}
		
		struct node *temp = head;
		int sin_stock = 0;
		
		printf("\n\nProductos sin stock:\n\n");
		printf("Codigo\tNombre\t\tPrecio\n");
		while (temp != NULL) {
			if (temp->prod.cantidad == 0) {
				printf("%d\t%s\t\t%.2f\n", temp->prod.codigo, temp->prod.nombre, temp->prod.precio);
				sin_stock = 1;
			}
			temp = temp->next;
		}
		
		if (!sin_stock) {
			printf("\nNo hay productos sin stock.\n");
		}
	}

	
	
// Funcion para mostrar el menu de opciones
void menu() {
	printf("Menu de opciones: \n");
	printf("1. Agregar producto\n");
	printf("2. Mostrar lista de productos\n");
	printf("3. Borrar producto por codigo\n");
	printf("4. Mostrar productos sin stock\n");
	printf("5. Salir\n");
	printf("Ingrese una opcion: ");
}

