#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define MAX_ESTUDIANTES 100

struct Estudiante{
	int Ident;
	char nombre[20];
	float notas[20];
	float promedio;
};

void Registrar(struct Estudiante *est, int *numEstudiantes);
void guardar(struct Estudiante *est, int numEstudiantes);
void Buscar(struct Estudiante *est, int numEstudiantes);



int main() {
	struct Estudiante est[MAX_ESTUDIANTES];
	int numEstudiantes= 0;
	char op=' ';
	
	do{
		printf("a. Registrar un nuevo estudiante y guardar sus datos en el archivo ""estudiantes.txt"".\nb. Buscar y mostrar los datos de un estudiante por id.\nc. Salir.");
		scanf(" %c", &op);
		
		switch(op){
			case 'a':
			case 'A':
				Registrar(est, &numEstudiantes);
				guardar(est, numEstudiantes);
				break;
				
			case 'b':
			case 'B':
				Buscar(est, numEstudiantes);
				break;
				
			case 'c':
			case 'C':
				break;
			
			default:
				printf("\nOpci�n no v�lida\n");
				break;
		}
		
	} while(op!='C' && op!='c');
	
	return 0;
}


void Registrar(struct Estudiante *est, int *numEstudiantes){
	if(*numEstudiantes>=MAX_ESTUDIANTES){
		printf("Error: Se ha alcanzado el limite de estudiantes.\n");
		return ;
	}
	
	struct Estudiante *nuevoEst= &est[*numEstudiantes];
	
	printf("\nIngrese los datos del nuevo estudiante:\n");
	printf("\nNumero de identificaci�n:\n");
	scanf("%d", &nuevoEst->Ident);
	
	printf("\nNombre:\n");
	scanf(" %s", nuevoEst->nombre);
	
	printf("\nIngrese 3 notas con espacio:\n");
	scanf("%f %f %f", &nuevoEst->notas[0], &nuevoEst->notas[1],&nuevoEst->notas[2]);
	
	nuevoEst->promedio = (nuevoEst->notas[0] + nuevoEst->notas[1] + nuevoEst->notas[2]) / 3.0;
	
	(*numEstudiantes)++;
}
	

void guardar(struct Estudiante *est, int numEstudiantes){
	FILE *archivo;
	archivo= fopen("Lista_Estudiantes.txt", "w");
	
	if (archivo == NULL) {
		printf("Error al abrir el archivo para escritura.\n");
		return ;
	}
	
	for(int i=0; i<numEstudiantes; i++){
		fprintf( archivo, "%d, %s, %.2f, %.2f, %.2f, %.2f", est[i].Ident, est[i].nombre, est[i].notas[0], est[i].notas[1], est[i].notas[2], est[i].promedio);
	}
	
	fclose(archivo);
	printf("Datos de estudiantes guardados en estudiantes.txt.\n");
}
	


void Buscar(struct Estudiante *est, int numEstudiantes){
	int buscar=0;
	printf("\nIngrese el numero de identificacion: ");
	scanf("%d", &buscar);
	
	for(int i=0; i<numEstudiantes; i++){
		if(buscar == est[i].Ident){
			printf("Nombre: %s", est[i].nombre);
			printf("Notas: %.2f %.2f %.2f", est[i].notas[0], est[i].notas[1], est[i].notas[2]);
			printf("Promedio: %.2f", est[i].promedio);
		}else{
			printf("Estudiante no encontrado.\n");
			
		}
	}
}


