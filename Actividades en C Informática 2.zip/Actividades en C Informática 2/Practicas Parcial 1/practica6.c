#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct ClienteBanco{
	int numero;
	char nombre[25];
	float saldo;
	char tipo_cuenta[20];
};


void checkMemoria(void *cliente);
void registrar(struct ClienteBanco *cliente, int *numCliente);
void guardar(struct ClienteBanco *cliente, int numCliente);
void leer(struct ClienteBanco *cliente, int *numCliente);
void mostrarNegativos(struct ClienteBanco *cliente, int numCliente);

int main() {
	struct ClienteBanco *cliente;
	int numCliente=0;
	char op;
	
	cliente = (struct ClienteBanco *)malloc((numCliente) * sizeof(struct ClienteBanco));
	checkMemoria(cliente);
	
	do{
		printf("\n---MENU DE OPCIONES---\n");
		printf("\na.Agregar cliente\nb.Leer archivo\nc.Clientes con saldo negativo\nd.Salir\n");
		scanf(" %c", &op);
		
		switch(op){
			case 'a':
			case 'A':
				registrar(cliente, &numCliente);
				guardar(cliente, numCliente);
				break;
				
			case 'b':
			case 'B':
				leer(cliente, &numCliente);
				break;
				
			case 'c':
			case 'C':
				break;
				
			case 'd':
			case 'D':
				printf("SALIENDO...\n");
				break;
				
			default:
				printf("\nOpcion no v�lida, intente de nuevo...\n");
				break;
		}
	} while(op!='d' && op!='D');
	
	free(cliente);
	return 0;
}

void checkMemoria(void *cliente){
	if(cliente==NULL){
		printf("ERROR: memoria insuficiente...\n");
		exit(1);
	}
}

void registrar(struct ClienteBanco *cliente, int *numCliente){
	
	printf("\n Ingrese los datos del nuevo cliente: \n");
	printf("\nNumero: \n");
	scanf("%d", &cliente->numero);
	
	printf("\nNombre: \n");
	scanf(" %s", cliente->nombre);
	
	printf("\nSaldo: \n");
	scanf("%.2f", &cliente->saldo);
	
	printf("\nTipo de cuenta ((CC=Cuenta Corriente, CA=Caja de Ahorros)): \n");
	scanf(" %.2s", cliente->tipo_cuenta);
	
	(*numCliente)++;
}
	
	
void guardar(struct ClienteBanco *cliente, int numCliente){
	FILE *archivo = fopen("ClienteBanco.txt","a");
	
	if(archivo==NULL){
		printf("\nError al abrir el archivo en modo escritura\n");
		return;
	}
	
	for(int i=0; i<numCliente; i++){
		fprintf(archivo, "%d, %s, %.2f, %.2s\n",
				(cliente+i)->numero,
				(cliente+i)->nombre,
				(cliente+i)->saldo,
				(cliente+i)->tipo_cuenta);
	}
	fclose(archivo);
	printf("\nSe registraron los clientes con �xito\n");
}
	
void leer(struct ClienteBanco *cliente, int *numCliente){
	int numero;
	char nombre[25];
	float saldo;
	char tipo_cuenta[20];
	
	FILE *archivo = fopen("ClienteBanco.txt", "r");
	
	if(archivo==NULL){
		printf("\nError al abrir el archivo en modo lectura\n");
		return;
	}
	
	printf("\n---CLIENTES---\n");
	printf("NUM\tNOMBRE\t\tSALDO\tTIPO CUENTA\n");
	while(fscanf(archivo, "%d, %s, %.2f, %.2s\n", &numero, nombre, &saldo, tipo_cuenta)==4){
		printf("%d\t%s\t%.2f\t%s\n", numero, nombre, saldo, tipo_cuenta);
	}
	fclose(archivo);
	
}
	

	
	

