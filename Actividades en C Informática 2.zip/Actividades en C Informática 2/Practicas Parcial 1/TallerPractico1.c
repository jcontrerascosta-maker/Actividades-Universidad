#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct ClienteBanco{
	int num;
	char nombre[25];
	float saldo;
	char tipo[3];
};

void checkMemoria(void *cliente);
void registrar(struct ClienteBanco *cliente, int num_clientes);
void guardar(struct ClienteBanco *cliente, int num_clientes);
void leer(struct ClienteBanco *cliente, int num_clientes);
void imprimirNegativos(struct ClienteBanco *cliente, int num_clientes);


int main() {
	struct ClienteBanco *cliente=NULL;
	char op;
	int num_clientes;
	
	printf("Cuantos clientes desea agregar?: ");
	scanf("%d", &num_clientes);
	
	cliente=(struct ClienteBanco *)malloc(num_clientes*sizeof(struct ClienteBanco));
	checkMemoria(cliente);
	
	do{
		printf("\n---MENU DE OPCIONES---\n");
		printf("\na.Agregar cliente\nb.Leer archivo\nc.Clientes con saldo negativo\nd.Salir\n");
		scanf(" %c", &op);
		
		switch(op){
		case 'a':
		case 'A':
			registrar(cliente, num_clientes);
			guardar(cliente, num_clientes);
			break;
			
		case 'b':
		case 'B':
			leer(cliente, num_clientes);
			break;
			
		case 'c':
		case 'C':
			imprimirNegativos(cliente, num_clientes);
			break;
			
		case 'd':
		case 'D':
			printf("SALIENDO...\n");
			break;
			
		default:
			printf("\nOpcion no v�lida, intente de nuevo...\n");
			break;
		}
	} while(op!='d' && op!='D');
	
	free(cliente);
	return 0;
}

void checkMemoria(void *cliente){
	if(cliente==NULL){
		printf("\nERROR: memoria insuficiente...\n");
		exit(1);;
	}
}

	
void registrar(struct ClienteBanco *cliente, int num_clientes){
	printf("\n---REGISTRO DE CLIENTES---\n");
	for(int i=0; i<num_clientes; i++){
		printf("\nIngrese los datos del cliente %d:\n", i+1);
		(cliente+i)->num=i+1;
		printf("Nombre: ");
		scanf("%s", (cliente+i)->nombre);
		printf("Saldo: ");
		scanf("%f", &(cliente+i)->saldo);
		printf("Tipo de cuenta(CC=Cuenta Corriente o CA=Caja de ahorro):  ");
		scanf("%s", (cliente+i)->tipo);
	}
}
	
void guardar(struct ClienteBanco *cliente, int num_clientes){
	FILE *archivo = fopen("ClienteBanco.txt", "w");
	
	if(archivo==NULL){
		printf("\n Error al abrir el archivo en modo escritura...\n");
		return;
	}
	
	for(int i=0; i<num_clientes; i++){
		fprintf(archivo, "%d, %s, %.2f, %s\n",(cliente+i)->num=i+1,(cliente+i)->nombre, (cliente+i)->saldo, (cliente+i)->tipo);
	}
	
	fclose(archivo);
	printf("Datos guardados en 'lista_cliente.txt'.\n");
}

	
void leer(struct ClienteBanco *cliente, int num_clientes){
	int num;
	char nombre[25];
	float saldo;
	char tipo[2];
	
	FILE *archivo = fopen("ClienteBanco.txt", "r");
	
	if(archivo==NULL){
		printf("\n Error al abrir el archivo en modo lectura...\n");
		return;
	}
	printf("\nArchivo Le�do con �xito...\n\n");
	printf("\n---CLIENTES---\n");
	printf("NUM\tNOMBRE\tSALDO\tTIPO CUENTA\n");
	
	while(fscanf(archivo, "%d, %24[^,], %f, %2s", &num, nombre, &saldo, tipo)==4){
		printf("%d\t%s\t%.2f\t%s\n", num, nombre, saldo, tipo);
	}
	
	fclose(archivo);
}

void imprimirNegativos(struct ClienteBanco *cliente, int num_clientes){
	int num;
	char nombre[25];
	float saldo;
	char tipo[3];
	
	FILE *archivo = fopen("ClienteBanco.txt", "r");
	
	if(archivo==NULL){
		printf("\n Error al abrir el archivo en modo lectura...\n");
		return;
	}
	printf("\nArchivo Le�do con �xito...\n\n");
	printf("\n---CLIENTES---\n");
	printf("NUM\tNOMBRE\tSALDO\tTIPO CUENTA\n");
	
	while(fscanf(archivo, "%d, %24[^,], %f, %2s", &num, nombre, &saldo, tipo)==4){
		if(saldo<0){
			printf("%d\t%s\t%.2f\t	%s\n", num, nombre, saldo, tipo);
		}
	}
	
	fclose(archivo);
}
	
	
