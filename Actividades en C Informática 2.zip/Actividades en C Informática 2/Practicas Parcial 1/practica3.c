
/*
Ejercicio 3

Desarrolle un programa que permita gestionar los datos de pacientes en un hospital. Para ello, defina una estructura llamada PacienteHospital que almacene la siguiente informaci�n: n�mero de paciente (entero), nombre (cadena de caracteres), diagn�stico (cadena de caracteres) y fecha de consulta(cadena de caracteres). Luego, implemente las siguientes funciones: 

Que permita registrar un nuevo paciente (debe agregar un paciente nuevo a la lista)

Que permita leer un archivo "paciente.txt".

Que permita buscar todas las consultas que realiz� un paciente.

Genere un men� de opciones con las distintas opciones que puede realizar el usuario. Recuerde presentar la informaci�n de manera ordenada y entendible.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PACIENTES_MAX 100

struct PacienteHospital{
	int numero;
	char nombre[25];
	char diagnostico[25];
	char consulta[25];
	
};

void cargar(struct PacienteHospital *paciente, int *numPacientes);
void guardar(struct PacienteHospital *paciente, int numPacientes);
void leerArchivo(struct PacienteHospital *paciente, int *numPacientes);
void buscarConsultas(struct PacienteHospital *paciente, int numPacientes);

int main(){
	struct PacienteHospital paciente[PACIENTES_MAX];
	int numPacientes=0;
	char op;
	
	do{
		printf("\n---MENU DE OPCIONES---\n");
		printf("\na.Agregar paciente\nb.Leer archivo\nc.Buscar consultas\nd.Salir\n");
		scanf(" %c", &op);
		switch(op){
			case 'a':
			case 'A':
				 cargar(paciente, &numPacientes);
				 guardar(paciente, numPacientes);
				break;
				
			case 'b':
			case 'B':
				leerArchivo(paciente, &numPacientes);
				break;
				 
			case 'c':
			case 'C':
				buscarConsultas(paciente, numPacientes);
				break;
				
			case 'd':
			case 'D':
				printf("\nSaliendo...\n");
				break;
				
			default:
				printf("Opcion no v�lida, intente de nuevo\n");
				break;
		}
	} while(op!='d' && op!='D');
	
	return 0;
}
	
	

void cargar(struct PacienteHospital *paciente, int *numPacientes){
	if(*numPacientes>=PACIENTES_MAX){
		printf("Error, exceso de pacientes\n");
		return;
	}
	struct PacienteHospital *nuevo= &paciente[*numPacientes];
	printf("\nIngrese los datos del nuevo paciente: \n");
	printf("\nNumero: ");
	scanf("%d", &nuevo->numero);
	
	printf("\nNombre: ");
	scanf(" %s", nuevo->nombre);
	
	printf("\nDiagnostico: ");
	scanf(" %s", nuevo->diagnostico);
	
	printf("\nFecha de Consulta: ");
	scanf(" %s", nuevo->consulta);
	
	(*numPacientes)++;
	printf("Paciente registrado con �xito.\n");
}
	
void guardar(struct PacienteHospital *paciente, int numPacientes){
	FILE *archivo= fopen("Pacientes.txt","a");
	
	if(archivo==NULL){
		perror("\nError al abrir el archivo en modo escritura\n");
		return;
	}
	
	for(int i=0; i<numPacientes; i++){
		fprintf(archivo, "%d, %s, %s, %s\n",
				paciente[i].numero, 
				paciente[i].nombre,
				paciente[i].diagnostico,
				paciente[i].consulta);
	}
	
	fclose(archivo);
	printf("Datos de pacientes guardados en paciente.txt.\n");
}
	
void leerArchivo(struct PacienteHospital *paciente, int *numPacientes){
	FILE *archivo= fopen("Pacientes.txt","r");
	
	if(archivo==NULL){
		perror("\nError al abrir el archivo en modo escritura\n");
		return;
	}
	*numPacientes = 0;
	while(fscanf(archivo,  "%d, %24[^,], %24[^,], %24[^\n]\n", &paciente[*numPacientes].numero, 
				 paciente[*numPacientes].nombre, 
				 paciente[*numPacientes].diagnostico, 
				 paciente[*numPacientes].consulta)==4){
		(*numPacientes)++;
		
	}
	fclose(archivo);
	printf("Pacientes le�dos del archivo con �xito. Total: %d\n", *numPacientes);
}
	
void buscarConsultas(struct PacienteHospital *paciente, int numPacientes){
	char nombreBuscado[25];
	int encontrado = 0;
	
	printf("\nIngrese el nombre del paciente que desea buscar: ");
	scanf("%s", nombreBuscado);
	
	for (int i = 0; i < numPacientes; i++) {
		if (strcmp(paciente[i].nombre, nombreBuscado) == 0) {
			printf("\nPaciente encontrado:\n");
			printf("Numero: %d\n", paciente[i].numero);
			printf("Nombre: %s\n", paciente[i].nombre);
			printf("Diagnostico: %s\n", paciente[i].diagnostico);
			printf("Fecha de Consulta: %s\n", paciente[i].consulta);
			encontrado = 1;
			break; // Salir del bucle despu�s de encontrar el paciente
		}
	}
	
	if (!encontrado) {
		printf("\nPaciente no encontrado.\n");
	}
}
	

	
	
