#include <stdio.h>
#include <stdlib.h>

struct persona{
	char nombre[25];
	char apellido[25];
	int edad;
};

struct persona *leer_arch(FILE *archivo){
	struct persona *persona = (struct persona *)malloc(sizeof(struct persona));
	
	if(persona==NULL){
		perror("\nError al asignar memoria \n");
		exit(1);
	}
	
	if(fscanf(archivo, "%s %s %d", persona->nombre, persona->apellido, &persona->edad)!= 3){
		free(persona);
		return NULL;
	}
	return persona;
}

	void imprimir_persona(struct persona *persona);

int main(){
	FILE *archivo= fopen("personas.txt", "r");
	
	if (archivo == NULL) {
		perror("Error al abrir el archivo");
	}
	
	struct persona *persona= NULL;
	while ((persona = leer_arch(archivo)) != NULL) {
		// Imprimimos los datos de la persona
		imprimir_persona(persona);
		
		// Liberamos la memoria de la persona
		free(persona);
	}
	
	// Cerramos el archivo de texto
	fclose(archivo);
	
	
	return 0;
}
	
	void imprimir_persona(struct persona *persona) {
		// Imprimimos los datos de la persona
		printf("Nombre: %s\n", persona->nombre);
		printf("Apellido: %s\n", persona->apellido);
		printf("Edad: %d\n", persona->edad);
	}

