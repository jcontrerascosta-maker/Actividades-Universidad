#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct Peaje{
	char patente[4];
	int eje;
	int precio;
	char direccion[2];
};

struct Node{
	struct Peaje peaje;
	struct Node *next;
};


void vehiculo(struct Peaje *peaje);
void push(struct Node **sp, struct Peaje peaje);
void pop(struct Node **sp);
void print(struct Node *sp);




int main(){
	struct Peaje peaje;
	struct Node *sp = NULL;
	int op= 0;
	
	do{
		printf("****MENU DE OPCIONES****\n");
		printf("1.Agregar un vehiculo a la cola\n2.Borrar el primer nodo de la cola\n3.Mostrar todos los veh�culos\n4.Mostrar los veh�culos por direcci�n\n5.Mostrar los veh�culos por ejes\n");
		scanf("%d", &op);
		
		switch(op){
		case 1:
			vehiculo(&peaje);
			push(&sp, peaje);
			break;
			
		case 2:
			pop(&sp);
			break;
			
		case 3:
			print(sp);
			break;
			
		case 4:
			
			break;
		case 5:
			break;
		}
	} while(op!=6);
	
	return 0;
}
	
	
	
	
void vehiculo(struct Peaje *peaje){
	printf("\nINgrese la patente de su vehiculo: ");
	scanf("%s", peaje->patente);
	printf("\nIngrese la cantidad de ejes de su vehiculo: ");
	scanf("%d", &peaje->eje);
	if(peaje->eje==1){
		printf("El cose del precio es: $100");
		peaje->precio=100;
	}
	if(peaje->eje==2){
		printf("El cose del precio es: $150");
		peaje->precio=150;
	}
	if(peaje->eje==3){
		printf("El cose del precio es: $200");
		peaje->precio=200;
	}
	if(peaje->eje>=4){
		printf("El cose del precio es: $300");
		peaje->precio=300;
	}
	printf("\nHacia donde se dirige? ");
	scanf("%s", peaje->direccion);
}
	
	
	
void push(struct Node **sp, struct Peaje peaje){
	struct Node *newNode = NULL;
	newNode = (struct Node*)malloc(sizeof(struct Node));
	if (newNode == NULL) {
		printf("No hay memoria disponible");
		exit(0);
	}
	
	newNode->peaje = peaje;
	newNode->next = *(sp);
	*(sp) = newNode;
}
	

	
void pop(struct Node **sp){
	if(*sp!=NULL){
		struct Node *temp = *(sp);
		*(sp) = (*sp)->next;
		free(temp);
	}else{
		printf("\nLa pila esta vac�a\n");
	}
}
	

	
void print(struct Node *sp){
	if(sp!=NULL){
		printf("\n****VEHICULOS****\n");
		printf("Patente\tCantidad de ejes\tCosto del peaje\t	Direccion\n");
		struct Node *temp = sp;
		while(temp!=NULL){
			printf("%s\t	%d\t	%d\t	%s\n", temp->peaje.patente,temp->peaje.eje,temp->peaje.precio,temp->peaje.direccion);
			temp = temp->next;
		}
	}else{
		printf("\nLa pila esta vac�a\n");
	}
}
	
	
	
