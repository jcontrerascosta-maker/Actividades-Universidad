#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct Peaje{
	char patente[4];
	int eje;
	int precio;
	char direccion[2];
};

struct node{
	struct Peaje peaje;
	struct node *link;
};

void vehiculo(struct Peaje *peaje);
void push(struct node **front, struct node **back, struct Peaje peaje);
void pop(struct node **front, struct node **back);
void imrimir(struct node *front);
void EJES(struct node *front);





int main(){
	struct Peaje peaje;
	struct node *front = NULL;
	struct node *back = NULL;
	int op= 0;
	do{
		printf("****MENU DE OPCIONES****\n");
		printf("1.Agregar un vehiculo a la cola\n2.Borrar el primer nodo de la cola\n3.Mostrar todos los veh�culos\n4.Mostrar los veh�culos por direcci�n\n5.Mostrar los veh�culos por ejes\n");
		scanf("%d", &op);
		
		switch(op){
			case 1:
				vehiculo(&peaje);
				push(&front, &back, peaje);	
				break;

			case 2:
				pop(&front, &back);
				break;
				
			case 3:
				imrimir(front);
				break;
				
			case 4:
				EJES(front);
					
				break;
			case 5:
				break;
		}
	} while(op!=6);
	return 0;
}
	
	
	
	
	
void vehiculo(struct Peaje *peaje){
	printf("\nINgrese la patente de su vehiculo: ");
	scanf("%s", peaje->patente);
	printf("\nIngrese la cantidad de ejes de su vehiculo: ");
	scanf("%d", &peaje->eje);
	if(peaje->eje==1){
		printf("El cose del precio es: $100");
		peaje->precio=100;
	}
	if(peaje->eje==2){
		printf("El cose del precio es: $150");
		peaje->precio=150;
	}
	if(peaje->eje==3){
		printf("El cose del precio es: $200");
		peaje->precio=200;
	}
	if(peaje->eje>=4){
		printf("El cose del precio es: $300");
		peaje->precio=300;
	}
	printf("\nHacia donde se dirige? ");
	scanf("%s", peaje->direccion);
}
	

	
void push(struct node **front, struct node **back, struct Peaje peaje){
	struct node *temp;
	
	temp = (struct node *)malloc(sizeof(struct node));
	if(temp==NULL){
		printf("\nNo hay suficiente memoria");
		exit(0);
	}
	
	temp->peaje = peaje;
	temp->link = NULL;
	
	if(*back==NULL){
		*front = temp;
		*back = temp;
	}else{
		(*back)->link = temp;
		*back = temp;
	}
}
	
	

void pop(struct node **front, struct node **back){
	if(*front==NULL){
		printf("\nLa cola esta vacia");
		exit(0);
	}
	
	struct node *temp = *front;
	*front = (*front)->link;
	
	if(*front==NULL){
		*back = NULL;
	}
	printf("Primer nodo borrado de la cola\n");
	free(temp);
}
	
	

void imrimir(struct node *front){
	struct node *temp = front;
	printf("\n****VEHICULOS****\n");
	printf("Patente\tCantidad de ejes\tCosto del peaje\t	Direccion\n");
	while(temp!=NULL){
		printf("%s\t	%d\t	%d\t	%s\n", temp->peaje.patente,temp->peaje.eje,temp->peaje.precio,temp->peaje.direccion);
		temp = temp->link;
	}
}
	
	void EJES(struct node *front){
		struct node *temp = front;
		printf("\n****VEHICULOS****\n");
		printf("Patente\tCantidad de ejes\tCosto del peaje\t	Direccion\n");
		while(temp!=NULL){
			if(temp->peaje.eje==1){
				printf("%s\t	%d\t	%d\t	%s\n", temp->peaje.patente,temp->peaje.eje,temp->peaje.precio,temp->peaje.direccion);
			}
			temp = temp->link;
		}
	}
	
