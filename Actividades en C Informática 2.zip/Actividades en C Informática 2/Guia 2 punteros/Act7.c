#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void sumatoria(int *);
void maximo(int *);
void minimo(int *);

int main() {
	int v[5];
	srand(time(NULL));
	int *pv=v;
		
	for(int i=0; i<5; i++){
		*(pv+i)=rand()%11;
	}
	for(int i=0; i<5; i++){
		printf("%d ", pv[i]);
	}

	sumatoria(pv);
	maximo(pv);
	minimo(pv);
	return 0;
}

void sumatoria(int *pv){
	int suma=0, *psuma=&suma;
	for(int i=0; i<5; i++){
		*psuma+=*(pv+i);
	}
	printf("\nLa sumatoria es: %d", *psuma);
}
	
void maximo(int *pv){
	int max=0, *pmax=&max;
	
	for(int i=0; i<5; i++){
		if(i==0){
			*pmax=*(pv+i);
		}
		if(*pmax<*(pv+i)){
			*pmax=*(pv+i);
		}
	}
	printf("\nEl maximo es: %d", *pmax);
}
	
	void minimo(int *pv){
		int min=0, *pmin=&min;
		
		for(int i=0; i<5; i++){
			if(i==0){
				*pmin=*(pv+i);
			}
			if(*pmin>*(pv+i)){
				*pmin=*(pv+i);
			}
		}
		printf("\nEl maximo es: %d", *pmin);
	}	
	
