#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main() {
	int v[10];
	int suma=0;
	int prom=0;
	srand(time(NULL));
	
	int *pv=v;
	int *pProm=&prom;
	
	
	for(int i=0; i<10; i++){
		v[i]= rand() %11;
		suma=suma+v[i];
	}
	
	prom=suma/10;
	
	printf("Los valores del vector son: ");
	for(int i=0; i<10; i++){
		printf("%d ", pv[i]);
	}
	
	printf("\nY su promedio es: %d", *pProm);
	return 0;
}

