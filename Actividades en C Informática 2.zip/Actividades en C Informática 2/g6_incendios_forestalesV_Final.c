/*Se debe diseñar y codificar un programa que sea capaz de cumplir los siguientes requerimientos:
    -Cantidad de superficie afectada por provincia
    -Cantidad de focos de incendio por provincia
    -Listar el top 3 de las provincias más afectadas por los incendios por cantidad de hectáreas afectadas.
    -Listar el top 3 de las provincias más afectadas por los incendios por cantidad de focos de incendios.
*/

//Librerias incluidas en el codigo
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Estructura para almacenar los datos de cada provincia
struct datos {
    
    int id_provincia;
    char provincia[30];
    float sup_afectada; 
    int cant_focos;
};

//Lista para almacenar los valores del top
typedef struct nodo{ 

	int id_provincia;
	char provincia[30];
	float sup_afectada;
	int cant_focos;

	struct nodo*next; 
}nodo;

//Prototipo de las funciones
void check_null(FILE *fp);
void leer_archivo(FILE *fp,struct datos *p);
void imprimir_datos(struct datos *p);
void sort_por_superficie(struct datos *p);
void sort_por_foco(struct datos *p);
void top_3_foco(nodo**, struct datos *p);
void top_3_superficie(nodo**,struct datos *p);
void liberar_memoria(nodo **head);

int main() {
    
    FILE *fp = fopen("datos.csv", "r");
    check_null(fp);

    struct nodo *head = NULL;
    struct datos provincias[17] = {0};
    struct datos *p = provincias;

    leer_archivo(fp,p);//Lectura de archivo
    printf("\n\nArreglo sin ordenar\n");
    imprimir_datos(p);

    printf("Arreglo ordenado por superficie\n");
    sort_por_superficie(p);//Se ordena el arreglo segun la superficie
    imprimir_datos(p);

    printf("Arreglo ordenado por foco:\n");
    sort_por_foco(p);//Se ordena el arreglo segun el foco
    imprimir_datos(p);
   
    printf("\n---------------------------------------------\n");
    printf("Top 3 provincias con mas focos\n");
    printf("---------------------------------------------\n");
    top_3_foco(&head, p);

    liberar_memoria(&head);//Se libera la memoria de los nodos
    
    printf("\n---------------------------------------------\n");
    printf("Top 3 provincias con mas superficie afectada\n");
    printf("---------------------------------------------\n");
    top_3_superficie(&head,p);
    printf("\n\n");

    fclose(fp);
    

    return 0;
}



// Función para verificar si el archivo se abrió correctamente
void check_null(FILE *fp) {
    if (fp == NULL) {
        printf("El archivo no se puede abrir\n");
        exit(1);
    }
}
//Funcion para leer los datos del archivo CSV
void leer_archivo(FILE *fp, struct datos *p) {
    char linea[1024];
    int id_provincia, i = 0;
    char nombre_provincia[30];
    float superficie_afectada=0;
    int foco=0;

    // Saltar la primera línea del archivo
    fgets(linea, sizeof(linea), fp);
    
    while (fgets(linea, sizeof(linea), fp)) {

        // Utilizar strtok para extraer los campos separados por coma
        char *token = strtok(linea, ",");
        int columna = 0;
    
        while (token != NULL) {
            columna++;
    
            //3ra columna esta el id
            if (columna == 3) {
                id_provincia = atoi(token); // atoi convierte el dato char a entero
            }
            //4ta columna esta el nombre
            else if (columna == 4) {
                strcpy(nombre_provincia, token); // copiar el nombre 
                nombre_provincia[29] = '\0'; // asegurar terminación en nulo
            }
            //7ma columna esta la superficie
            else if(columna==7){
                superficie_afectada = atof(token); //atof lo convierte de char a float
            }
            //9na columna estan los focos
            else if(columna==9){
                foco = atoi(token);
            }
            
            token = strtok(NULL, ","); // pasar al siguiente campo
            
        }

    // buscar una posición en el arreglo para almacenar la provincia
        for (i = 0; i < 17; i++) {
            struct datos *ptr = p + i;

            if (ptr->id_provincia == 0){ 
                ptr->id_provincia = id_provincia;
                strcpy(ptr->provincia, nombre_provincia);
                ptr->sup_afectada = superficie_afectada;
                ptr->cant_focos = foco;
                break;
            } 
            if (ptr->id_provincia == id_provincia) {
                ptr->sup_afectada += superficie_afectada;
                ptr->cant_focos += foco; 
                break;
            }
        }
    }
}

void imprimir_datos(struct datos *p){
    printf("-------------------------------------------------------------------------\n");
    printf("ID\tProvincia\t\tSuperficie afectada\tCantidad de focos\n");

    for(int i = 0; i < 17; i++) {
        struct datos *ptr = p + i;
        if(ptr->id_provincia != 0) {
            printf("%d\t%s\t%.2f\t\t\t%d\n", ptr->id_provincia, ptr->provincia, ptr->sup_afectada,ptr->cant_focos);
        }
    }
    printf("----------------------------------------------------------\n");
}

void sort_por_superficie(struct datos *p) {

	struct datos temp; // Estructura temporal para intercambio
	
    for (int i = 0; i < 17 - 1; i++) {
		for (int j = 0; j < 17 - i - 1; j++) {
            struct datos *ptr = p+j;
			if (ptr->sup_afectada < (ptr+1)->sup_afectada) { // Ordenar por superficie afectada
				// Intercambio completo de estructuras
				temp = *ptr;
				*ptr = *(ptr+1);
				*(ptr+1) = temp;
			}
		}
	}
}

//funcion para ordenar de mayor a menor segun los focos
void sort_por_foco(struct datos *p) {
	struct datos temp; 
	
    for (int i = 0; i < 17 - 1; i++) {
		for (int j = 0; j < 17 - i - 1; j++) {

            struct datos *ptr = p+j;
			if (ptr->cant_focos < (ptr+1)->cant_focos){ 
				// Intercambio completo de estructuras
				temp = *ptr;
				*ptr = *(ptr+1);
				*(ptr+1) = temp;
			}
		}
	}
}

//Funcion para guardar el top 3 provincias con mayor foco en nodos
void top_3_foco(nodo **head, struct datos *p) {
    nodo *new = NULL;

    sort_por_foco(p);
    // Crear y agregar los primeros 3 nodos
    for (int i = 0; i < 3; i++) {
        struct datos *ptr = p+i;
        // Asignar memoria para el nuevo nodo
        new = (nodo*)malloc(sizeof(nodo));
        if (new == NULL) {
            printf("Memoria insuficiente\n");
            exit(1);
        }

        // Asignar los valores del puntero `p` al nuevo nodo
        new->id_provincia = ptr->id_provincia;
        new->cant_focos = ptr->cant_focos;

        // Asignar la provincia directamente usando p-> como en tu código
        strcpy(new->provincia, ptr->provincia);  // Asegúrate de que new->provincia tiene suficiente espacio

        new->sup_afectada = ptr->sup_afectada;
        new->next = NULL;

        // Insertar el nodo en la lista enlazada
        if (*head == NULL) {
            *head = new;  // Si la lista está vacía, este es el primer nodo
        } else{
            nodo *temp = *head;
            // Avanzar hasta el final de la lista para insertar el nuevo nodo
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = new;  // Enlazar el nuevo nodo al final
        }
    }

    // Imprimir los nodos de la lista enlazada
    nodo *temp = *head;  // Reiniciar el puntero temp para recorrer la lista desde el inicio
    while (temp != NULL) {
        printf("\nProvincia: %s\nCant_focos: %d\n", temp->provincia, temp->cant_focos);
        temp = temp->next;  // Moverse al siguiente nodo
    }
}

//Funcion para guardar el top 3 provincias con mayor superficie afectada en nodos
void top_3_superficie(nodo **head, struct datos *p) {

    nodo *new = NULL;

    // Ordenar los datos por superficie afectada
    sort_por_superficie(p);

    // Crear y agregar los primeros 3 nodos
    for (int i = 0; i < 3; i++) {
        struct datos *ptr = p + i;

        // Asignar memoria para el nuevo nodo
        new = (nodo*)malloc(sizeof(nodo));
        if (new == NULL) {
            printf("Memoria insuficiente\n");
            exit(1);
        }

        // Asignar los valores del puntero `p` al nuevo nodo
        new->id_provincia = ptr->id_provincia;
        new->cant_focos = ptr->cant_focos;

        // Asignar la provincia directamente usando ptr
        strcpy(new->provincia, ptr->provincia);  // Asegúrate de que new->provincia tiene suficiente espacio

        new->sup_afectada = ptr->sup_afectada;
        new->next = NULL;

        // Insertar el nodo en la lista enlazada
         if (*head == NULL) {    
            *head = new;  // Si la lista no está vacía, este es el primer nodo
        } 
        else{
            nodo *temp = *head;
            // Avanzar hasta el final de la lista para insertar el nuevo nodo
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = new;  // Enlazar el nuevo nodo al final
        }
    }

    // Imprimir los nodos de la lista enlazada
    nodo *temp = *head;  // Reiniciar el puntero temp para recorrer la lista desde el inicio
    while (temp != NULL) {
        printf("\nProvincia: %s\nCant_focos: %d\nSuperficie afectada: %.2f\n", 
               temp->provincia, temp->cant_focos, temp->sup_afectada);
        temp = temp->next;  // Moverse al siguiente nodo
    }
}

//Funcion para liberar la memoria de los nodos 
void liberar_memoria(nodo **head) {
    nodo *temp;
    while (*head != NULL) {
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }
}
