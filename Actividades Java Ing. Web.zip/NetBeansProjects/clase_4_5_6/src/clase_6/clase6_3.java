package clase_6;

public class clase6_3 {
    public static void main(String[] args) {
        for(var contador = 0; contador < 10; contador++){
            System.out.println("contador= " + contador);
        }
    }

}
