
package clase_6;

public class clase6_1 {
     public static void main(String[] args) {
         var contador = 0;
         
         while(contador <= 3){
             System.out.println("Contador= " + contador);
             contador++;
         }
     }

}
