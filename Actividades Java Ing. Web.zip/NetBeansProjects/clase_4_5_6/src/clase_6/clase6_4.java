
package clase_6;

public class clase6_4 {
    public static void main(String[] args) {
        for(var contador = 0; contador < 10; contador++){
            if(contador%2 != 0){
                continue;
            }
            System.out.println("contador= " + contador);
        }
    }
}
