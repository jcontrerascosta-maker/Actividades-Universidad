
package clase_6;

public class clase6_2 {
     public static void main(String[] args) {
         var contador = 0;
         do{
             System.out.println("contador= " + contador);
             contador++;
         }while(contador <= 10);
     }
}
