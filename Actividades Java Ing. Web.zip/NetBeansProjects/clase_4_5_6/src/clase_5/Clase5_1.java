
package clase_5;

public class Clase5_1 {
    public static void main(String[] args) {
        var condicion = true;
        
        if(condicion){
            System.out.println("La condicion es verdadera");
        }else{
            System.out.println("La condicion es falsa");
        }
    }

}
