package clase_5;

public class clase5_2 {
    public static void main(String[] args) {
        var numero = 2;
        var numeroTexto = "Numero desconocido";
        
        if(numero == 1){
            numeroTexto= "numero uno";
        }
        else if(numero == 2){
            numeroTexto= "numero dos";
        }else{
            numeroTexto = "Numero no encontrado";
        }
        System.out.println("Numero texto = " + numeroTexto);
    }

}
