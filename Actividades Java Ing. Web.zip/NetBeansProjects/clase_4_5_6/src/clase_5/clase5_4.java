
package clase_5;

public class clase5_4 {
    public static void main(String[] args) {
        var mes = 8;
        var estacion = "Estacion desconocida";
        
        switch(mes){
            case 1: case 2: case 3:
                estacion = "verano";
                break;
            
            case 4: case 5:
                estacion = "otoño"; 
                break;

            case 6: case 7: case 8:
                estacion = "invierno";
                break;
                
            case 9: case 10: case 11: case 12:
                estacion = "primavera";
                break;
        }
        System.out.println("Estacion= " + estacion);

    }
            
}
