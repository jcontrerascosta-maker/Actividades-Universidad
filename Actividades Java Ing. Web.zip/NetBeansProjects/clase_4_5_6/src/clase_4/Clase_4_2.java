package clase_4;

public class Clase_4_2 {
    public static void main(String[] args) {
        int a=5, b=7;
        int c= a - 3 + b;
        
        System.out.println("C vale: " + c);
        
        a +=1;
        System.out.println("a= " + a);
        
        a -=2;
        System.out.println("a= " + a);
        
    }
}
