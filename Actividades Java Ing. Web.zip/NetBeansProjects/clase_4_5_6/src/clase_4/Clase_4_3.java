package clase_4;

public class Clase_4_3 {
    public static void main(String[] args) {
        var a= 5;
        var b= -a;
        
        System.out.println("a= " + a);
        System.out.println("b= " + b);
        
        var c = true;
        var d = !c;
        
        System.out.println("C= " + c);
        System.out.println("d= " + d);
        
        var e = a++;
        var f = ++a;
        
        System.out.println("e= " + e);
        System.out.println("f= " + f);
    }
}
