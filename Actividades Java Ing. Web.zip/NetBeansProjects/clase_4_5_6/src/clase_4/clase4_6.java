package clase_4;

public class clase4_6 {
    public static void main(String[] args){
        var a = 6;
        var valorMaximo = 10;
        var valorMinimo = 3;
        
        var resultado = (a>=valorMinimo && a<=valorMaximo);
        if(resultado){
            System.out.println("Dentro del rango");
        }else{
            System.out.println("Fuera del rango");
        }
    }
}
