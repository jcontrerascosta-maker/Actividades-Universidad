package clase_4;

public class clase4_7 {
    public static void main(String[] args) {
        var resultado = (1 > 2) ? "verdadero" : "falso";
        System.out.println("Resultado= " + resultado);
        
        var num = 10;
        resultado = (num % 2 == 0) ? "numero par" : "numero impar";
        System.out.println("Resultado= " + resultado);

    }

}
