
package clase_4;

public class Clase_4_4 {
    public static void main(String[] args) {
        var a = 5;
        var b = 7;
        
        var c = (a==b);
        System.out.println("C= " + c);
        
        var d = (a != b);
        System.out.println("d= " + d);
        
        var cadena = "hola";
        var cadena_2 = "hola";
        var e = (cadena==cadena_2);
        System.out.println("e= " + e);
        
        var f = cadena.equals(cadena_2);
        System.out.println("f= " + f);
    }

}
