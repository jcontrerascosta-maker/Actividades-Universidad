package clase_4;

public class clase4_8 {
    public static void main(String[] args) {
        var a = 3;
        var b = 6;
        var c = ++a + b--;
        System.out.println("a= " + a);
        System.out.println("b= " +  b);
        System.out.println("c= " + c);
        
        var resultado = 20 - 2 * 3 / 2;
        System.out.println("Resultado= " + resultado);
        resultado = (20 - 2) * 3 / 2;
        System.out.println("Resultado= " + resultado);


    }

}
