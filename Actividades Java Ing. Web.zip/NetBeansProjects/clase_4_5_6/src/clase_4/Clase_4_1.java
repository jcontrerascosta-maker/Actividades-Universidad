
package clase_4;

public class Clase_4_1 {

    public static void main(String[] args) {
        int a=4, b=2;
        var resultado = a + b;
        System.out.println("El resultado de la summa de a + b es " + resultado);
        
        resultado = b-a;
        System.out.println("El resultado de la resta de b - a es " + resultado);
        
        resultado = a*b;
        System.out.println("El resultado de la multiplicacion entre a y b es " + resultado);
        
        var resultado2 = 3./a;
        System.out.println("El resultado de la division es " + resultado2);

        resultado = a%b;
        System.out.println("El resultado del modulo es " + resultado);
        
        if(a%2 == 0){
            System.out.println("El numero es par");
        }else{
            System.out.println("El numero es impar");
        }
    }
    
}

