package clase_4;

public class Clase_4_5 {
    public static void main(String[] args) {
        var a = 5;
        var b = 7;
        
        var g = a>=b;
        System.out.println("g= " + g);
        
        
        var adulto = 18;
        var edad= 30;
        
        if(edad>=adulto){
            System.out.println("Es un adulto");
        }else{
            System.out.println("Es menor de edad");
        }
    }

}
