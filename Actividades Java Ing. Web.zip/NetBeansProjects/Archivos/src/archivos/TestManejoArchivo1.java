
package archivos;
import static archivos.ManejoArchivo1.crearArchivo;

        
public class TestManejoArchivo1 {
    public static void main(String[] args){
        var nombreArchivo = "/home/joaquin/Carpeta Compartida/Facultad/Ing Web/prueba2.txt";
        crearArchivo(nombreArchivo);
    }
}
