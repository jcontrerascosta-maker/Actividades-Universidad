
package archivos;
import java.io.*;


public class CrearArchivo1 {

    public static void main(String[] args) {
        File archivo = new File("/home/joaquin/Carpeta Compartida/Facultad/Ing Web/prueba.txt");
        
        try{
            PrintWriter salida = new PrintWriter(archivo);
            salida.close();
            
        }catch(IOException ex){
            ex.printStackTrace();
        }
        System.out.println("El archivo fue creado...");
        
    }
    
}
