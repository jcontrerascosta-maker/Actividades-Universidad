
package archivos;
import static archivos.ManejoArchivos2.*;

public class TestManejoArchivos2 {
    public static void main(String[] args){
        var nombreArchivo = "/home/joaquin/Carpeta Compartida/Facultad/Ing Web/prueba.txt";
        //escribirArchivo(nombreArchivo, "Hola desde java");
        //anexarArchivo(nombreArchivo, "adios");
        leerArchivo(nombreArchivo);
    }
}
