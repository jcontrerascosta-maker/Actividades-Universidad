package archivos;

import java.io.*;

public class EscribirArchivoEnUnPrograma {
    public static void main(String[] args) {
        File archivo = new File("/home/joaquin/Carpeta Compartida/Facultad/Ing Web/prueba6.txt");

        try {
            PrintWriter salida = new PrintWriter(new FileWriter(archivo, true));
            salida.println("Hola y chau desde Java");
            salida.close();
            System.out.println("Se ha escrito el archivo");
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
    }
}