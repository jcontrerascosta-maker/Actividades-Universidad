
package archivos;
import java.io.*;

public class ManejoArchivo1 {
    public static void crearArchivo(String nombreArchivo){
        File archivo = new File(nombreArchivo);
        
        System.out.println("ruta: "+archivo.getAbsolutePath()); 
        try{
        PrintWriter salida = new PrintWriter(archivo);
        salida.close();
        System.out.println("El archivo fue creado...");
        
        }catch(FileNotFoundException ex){
           ex.printStackTrace(System.out);
        }
    
    }
    
}
