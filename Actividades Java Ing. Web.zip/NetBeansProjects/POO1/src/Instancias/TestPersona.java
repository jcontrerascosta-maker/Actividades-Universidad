
package Instancias;
import ActividadFecha8.Fecha;

public class TestPersona {
    public static void main(String[] args){
        Persona p1 = new Persona("Juan", "21773803", new Fecha(23,3,1971));
        Persona p2 = new Persona("Pablo", "22559789", new Fecha(31,5,1930));
        
        System.out.println(p1);
        System.out.println(p1);
        System.out.println(p1);
        System.out.println(p1);
        
        System.out.println(p2);        
        System.out.println(p2);
        System.out.println(p2);


        
    }
}
