
package ActividadBanco2;

public class Principal {
    public static void main(String[] args){
    Cuenta cuentaCredito;
    Cuenta cuentaDebito;
        
    cuentaCredito = new Cuenta();        
    cuentaDebito = new Cuenta();
        
    cuentaCredito.nombre = "Pedro Sánchez";
    cuentaCredito.setSaldo(1500);
    cuentaCredito.setNumero(244513);
    cuentaCredito.tipo = "Crédito";
        
    cuentaDebito.nombre = "Pablo Garcia";
    cuentaDebito.setSaldo(7800);
    cuentaDebito.setNumero(273516);
    cuentaDebito.tipo = "Débito";
        
    cuentaCredito.imprimir();
    cuentaDebito.imprimir();
    }
}
