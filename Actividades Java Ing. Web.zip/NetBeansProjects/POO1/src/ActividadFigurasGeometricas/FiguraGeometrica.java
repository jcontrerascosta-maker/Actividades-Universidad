
package ActividadFigurasGeometricas;

public abstract class FiguraGeometrica {
    public abstract double area();
    
    public String toString(){
        return "area = " + area();
    }
}
