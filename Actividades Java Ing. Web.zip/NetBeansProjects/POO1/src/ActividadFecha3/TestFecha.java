
package ActividadFecha3;

public class TestFecha {
   public static void main(String[] args){
       Fecha f1 = new Fecha(22,03,2006);
       
       Fecha f2 = new Fecha();
       f2.setDia(23);
       f2.setMes(04);
       f2.setAnio(2017);
       
       System.out.println("La primera fecha es: " + f1);
       System.out.println("La segunda fecha es: " + f2);
       
       System.out.println("Las fechas son iguales: "+ f1.equals(f2));

   } 
}
