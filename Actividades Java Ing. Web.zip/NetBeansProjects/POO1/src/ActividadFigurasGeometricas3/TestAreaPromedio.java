
package ActividadFigurasGeometricas3;





 
public class TestAreaPromedio {
    public static void main(String[] args){
        FiguraGeometrica arr[]={ new Circulo(23),
                                 new Rectangulo(10,5),
                                 new Triangulo(3,6)};
       
        double prom = FiguraGeometrica.areaPromedio(arr);
        System.out.println("Promedio= " + prom);
    }
}
