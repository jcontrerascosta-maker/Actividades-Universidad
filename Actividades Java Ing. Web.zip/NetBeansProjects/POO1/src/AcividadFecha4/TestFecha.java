package AcividadFecha4;

public class TestFecha {
   public static void main(String[] args){
       Fecha f = new Fecha(22, 03 , 2006);
       Fecha f2 = new Fecha("22/03/2006");
       
       System.out.println(f);
       System.out.println(f2);
       System.out.println("Las fechas son iguales: "+ f.equals(f2));
   }
}
