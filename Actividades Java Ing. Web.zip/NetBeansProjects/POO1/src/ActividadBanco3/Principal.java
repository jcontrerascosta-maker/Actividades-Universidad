package ActividadBanco3;

public class Principal {
    public static void main(String[] args){
        Cuenta cuentaCredito = new Cuenta("Pedro Sánchez", 1500, 244513, "Crédito");
        Cuenta cuentaDebito = new Cuenta("Pablo Garcia", 7800, 273516, "Débito");

        cuentaCredito.imprimir();
        cuentaDebito.imprimir();
    }
}
