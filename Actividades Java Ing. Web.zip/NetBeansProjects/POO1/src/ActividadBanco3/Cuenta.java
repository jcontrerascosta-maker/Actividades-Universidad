package ActividadBanco3;

public class Cuenta {
    String nombre;
    double saldo;
    int numero;
    String tipo;
    
    public Cuenta(String n, double s, int num, String t){
        nombre = n;
        saldo = s;
        numero = num;
        tipo = t;
    }
    public void depositar(double deposito){
        saldo = saldo + deposito;
    }
    
    public void retirar(double retiro){
        if(saldo >= retiro){
            saldo = saldo - retiro;
        }
    }
    
    public void imprimir(){
        System.out.println("Informacion de la cuenta: ");
        System.out.println("Nombre de propietario: " + nombre +
                            "Numero de cuenta: " + numero +
                            "Tipo de cuenta: " + tipo +
                            "Saldo: " + saldo);
    }
}
