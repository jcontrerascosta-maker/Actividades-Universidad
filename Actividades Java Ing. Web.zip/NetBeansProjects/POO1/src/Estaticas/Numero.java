
package Estaticas;

public class Numero {
    private double valor;

    public Numero(int i) {
        valor = i;
    }
 
    public Numero sumar(double a){
        valor+=a;
        return this;
    }
    public static double sumar(double a, double b){
        return a+b;
    }
    
    public String toString(){
        return String.valueOf(valor);
    }
}
