
package ActividadFecha6;

public class TestFechaDetallada {
   public static void main(String[] args){
       FechaDetallada f = new FechaDetallada(22, 03, 2006);
       System.out.println(f);
   }
}
