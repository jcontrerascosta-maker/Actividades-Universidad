
package ActividadFigurasGeometricas2;

public abstract class FiguraGeometrica {
    private String nombre;
    
    public abstract double area();
    
    public FiguraGeometrica(String nom){
        nombre = nom;
    }
    public String toString(){
        return nombre + " (area = "+ area()+") ";
    }
    
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
}
