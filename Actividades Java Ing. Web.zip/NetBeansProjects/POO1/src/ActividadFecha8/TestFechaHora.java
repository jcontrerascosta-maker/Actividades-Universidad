
package ActividadFecha8;

public class TestFechaHora {
    public static void main(String[] args){
        FechaHora fh = new FechaHora("25/2/2006", 14,30,10);
        System.out.println(fh);
        
        fh.addDias(5);
                System.out.println(fh);

    }
}
