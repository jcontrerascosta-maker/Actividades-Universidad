
package ActividadBanco;

public class Cuenta {
    public String nombre;
    public double saldo;
    public int numero;
    public String tipo;
    
    public void depositar(double deposito){
        saldo = saldo + deposito;
    }
    
    public void retirar(double retiro){
        if(saldo >= retiro){
            saldo = saldo - retiro;
        }
    }
    
    public void imprimir(){
        System.out.println("Informacion de la cuenta: ");
        System.out.println("Nombre de propietario: " + nombre +
                            "Numero de cuenta: " + numero +
                            "Tipo de cuenta: " + tipo +
                            "Saldo: " + saldo);
    }
}
