
package ActividadBanco;

public class Principal {
    public static void main(String[] args){
        Cuenta cuentaCredito;
        Cuenta cuentaDebito;
        
        cuentaCredito = new Cuenta();        
        cuentaDebito = new Cuenta();
        
        cuentaCredito.nombre = "Pedro Sánchez";
        cuentaCredito.saldo = 1500;
        cuentaCredito.numero = 244513;
        cuentaCredito.tipo = "Crédito";
        
        cuentaDebito.nombre = "Pablo Garcia";
        cuentaDebito.saldo = 7800;
        cuentaDebito.numero = 273516;
        cuentaDebito.tipo = "Débito";
        
        cuentaCredito.imprimir();
        cuentaDebito.imprimir();
    }
}
