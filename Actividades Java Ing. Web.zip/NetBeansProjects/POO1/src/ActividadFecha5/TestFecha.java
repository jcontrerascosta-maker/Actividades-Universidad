
package ActividadFecha5;
import java.util.Scanner;

public class TestFecha {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Ingrese la fecha dd/mm/aaaa: ");
        String sFecha = scanner.nextLine();
        
        Fecha f = new Fecha(sFecha);
        System.out.println("La fecha ingresada es: " + f);
        
        System.out.println("Ingrese dias a sumar o restar: ");
        int diasSum = scanner.nextInt();
        
        f.addDias(diasSum);
        System.out.println("sumando " + diasSum + " dias, queda: " + f);
    }
}
