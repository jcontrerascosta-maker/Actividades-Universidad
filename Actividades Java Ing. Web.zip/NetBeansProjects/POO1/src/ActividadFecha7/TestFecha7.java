package ActividadFecha7;
import ActividadFecha5.Fecha;
import ActividadFecha6.FechaDetallada;

public class TestFecha7 {
    public static void main(String[] args){
        Object[] arr = {new Fecha(22,03,2006),
            new FechaDetallada(23,04,2017),
            new String("Esto es una cadena")};
        
        MuestraConjunto.mostrar(arr);
    }
}
