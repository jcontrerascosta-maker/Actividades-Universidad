
package List;
import java.util.*;

public class Sett{
    public static void main(String[] args){
        Set miSet = new HashSet();
        miSet.add("Lunes");
        miSet.add("Martes");
        miSet.add("Miércoles");
        miSet.add("Jueves");
        miSet.add("Viernes");
        
        imprimir(miSet);
    }
    
    public static void imprimir(Collection coleccion){
         coleccion.forEach(elemento->{
            System.out.println("Elemento: " + elemento);
        });
         
         System.out.println("****");
          for(Object elemento : coleccion){
            System.out.println("Elemento= " + elemento);
        }
    }
}
