
package List;
import java.util.*;

public class Array{
    public static void main(String[] args) {
        List miLista = new ArrayList();
        
        miLista.add("Lunes");
        miLista.add("Martes");
        miLista.add("Miércoles");
        miLista.add("Jueves");
        miLista.add("Viernes");
        
        for(Object elemento : miLista){
            System.out.println("Elemento= " + elemento);
        }
        
        miLista.forEach(elemento->{
            System.out.println("Elemento: " + elemento);
        });
    }
    
}
