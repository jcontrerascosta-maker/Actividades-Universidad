
package List;
import java.util.Vector;
        
public class Vector1 {
    public static void main(String[] args){
        Vector<String> v = new Vector<String>();
        
        v.add("Pablo");
        v.add("Juean");
        v.add("Patricio");
        
        String aux;
        
        for(int i=0; i < v.size(); i++){
            aux = v.get(i);
            System.out.println(aux);
        }
    }
}
