
package List;
import java.util.*;

public class Maps {
    public static void main(String[] args){
        Map miMapa = new HashMap();
        miMapa.put("Valor 1", "Juan");
        miMapa.put("Valor 2", "Mario");
        miMapa.put("Valor 3", "Ana");

        String elemento = (String) miMapa.get("Valor 1");
        System.out.println("Elemento: " + elemento);
        
        imprimir(miMapa.keySet());
        imprimir(miMapa.values());
    }
    
    public static void imprimir(Collection coleccion){
        coleccion.forEach(elemento->{
            System.out.println("Elemento: " + elemento);
        });
    }
}
