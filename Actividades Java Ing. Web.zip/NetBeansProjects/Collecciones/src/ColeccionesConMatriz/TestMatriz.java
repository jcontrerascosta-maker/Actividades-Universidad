
package ColeccionesConMatriz;
import java.util.Collection;

public class TestMatriz {
    public static void main(String[] args){
        Collection<String> coll = UNombres.obtenerLIsta();
        
        for(String nom : coll){
            System.out.println(nom);
        }
    }
}
