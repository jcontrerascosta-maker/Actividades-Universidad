package ColeccionesConMatriz;
import java.util.ArrayList;
import java.util.Collection;


public class UNombres {
    public static Collection<String> obtenerLIsta(){
        ArrayList<String> v = new ArrayList<String>();
        v.add("Pablo");
        v.add("Juean");
        v.add("Patricio");    
        
        return v;
    }
}

