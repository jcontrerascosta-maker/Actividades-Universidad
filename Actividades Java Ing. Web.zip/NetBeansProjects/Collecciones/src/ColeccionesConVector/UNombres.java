
package ColeccionesConVector;
import java.util.Vector;

public class UNombres {
    public static Vector<String> obtenerLIsta(){
        Vector<String> v = new Vector<String>();
        v.add("Pablo");
        v.add("Juean");
        v.add("Patricio");    
        
        return v;
    }
}
