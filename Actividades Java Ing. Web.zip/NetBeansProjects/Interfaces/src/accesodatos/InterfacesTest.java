
package accesodatos;

import accesodatos.*;

public class InterfacesTest {
    public static void main(String[] args){
        IAccesoDatos datos = new ImplementacionMySQL();
        datos.listar();
        
        datos = new ImplementacionOracle();
        imprimir(datos);
    }
    
    public static void imprimir(IAccesoDatos datos){
        datos.listar();
    }
}
