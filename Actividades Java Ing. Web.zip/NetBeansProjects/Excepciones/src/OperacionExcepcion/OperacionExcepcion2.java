
package OperacionExcepcion;

public class OperacionExcepcion2 extends RuntimeException {
    public OperacionExcepcion2(String mensaje){
        super(mensaje);
    }
}
