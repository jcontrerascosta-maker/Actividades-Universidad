
package OperacionExcepcion;

public class OperacionExcepcion extends Exception{
    public OperacionExcepcion(String mensaje){
        super(mensaje);
        
    }
}
