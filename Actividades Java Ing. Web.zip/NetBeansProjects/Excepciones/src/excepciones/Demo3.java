
package excepciones;

import java.util.Scanner;

public class Demo3 {
    public static void main(String[] args) {
        int resultado = 0;
        
        try{
            System.out.println("Ingrese un valor: ");
            var consola = new Scanner(System.in);
            Integer intro = consola.nextInt();
            resultado = 10 / intro;
            //return;

        }catch(Exception ex){
            System.out.println("Error!");
            
        }finally{
            System.out.println("Esto sale siempre: " + resultado);
        }
        
        System.out.println("Esto no sale siempre: " + resultado);
        
    }
}
