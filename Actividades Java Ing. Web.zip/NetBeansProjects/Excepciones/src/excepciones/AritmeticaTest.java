
package excepciones;

import static excepciones.Aritmetica.division;

public class AritmeticaTest {
    public static void main(String[] args) {
        int resultado = 0;
        
        try{
            resultado = division(10, 0);
            
        }catch(Exception e){
            System.out.println("Ocurrio un error");
            System.out.println(e.getMessage());
        }
        
        System.out.println("Resultado= " + resultado);
    }
}
