
package excepciones;
import java.util.Scanner;

public class Demo4 {
    public static void main(String[] args) {
        int resultado = 0;

        try {
            var consola = new Scanner(System.in);
            Integer intro = consola.nextInt();
            System.out.println("El dato ingresado es un Integer ");
            resultado = 10 / intro;
            // return;
        } catch (ArithmeticException ex) {
            System.out.println("Division por Cero !!");
        } catch (Exception ex) {
            System.out.println("No es un numero !!");
        } finally {
            System.out.println("Esto sale siempre ! " + resultado);
        }

        System.out.println("Esto NO SALE siempre ! " + resultado);
    }
}

