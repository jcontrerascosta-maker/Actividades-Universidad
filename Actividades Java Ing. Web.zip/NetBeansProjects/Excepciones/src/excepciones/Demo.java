package excepciones;

public class Demo {

    public static void main(String[] args) {
        int resultado = 10/0;
        System.out.println("Resultado= " + resultado);
    }
    
}
