
package excepciones;

import OperacionExcepcion.OperacionExcepcion;

public class Aritmetica2 {
    public static int division(int numerador, int denominador) 
            throws OperacionExcepcion{
                if(denominador==0){
                    throw new OperacionExcepcion("División entre cero");
                }
                  return numerador / denominador;
            }
    }
