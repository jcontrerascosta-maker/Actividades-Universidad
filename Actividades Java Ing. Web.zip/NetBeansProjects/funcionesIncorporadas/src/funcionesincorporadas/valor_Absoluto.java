
package funcionesincorporadas;
import java.util.Scanner;

public class valor_Absoluto {
    public static void main(String[] args) {
        System.out.println("Ingrese un numero: ");
        var numero= Integer.parseInt(new Scanner(System.in).nextLine());
        var valorAbs = Math.abs(numero);
        
        System.out.println("El valor absoluto de " + numero + " es " + valorAbs);
    }
}