package funcionesincorporadas;

public class numero_a_texto {
   public static void main(String[] args) {
       int a= 15, b= 10;
       System.out.println(a+b);
       
       System.out.println(String.valueOf(a) + Integer.toString(b));
       
       String resultado = String.format("%d %d", a, b);
       System.out.println(resultado);
   } 
}
