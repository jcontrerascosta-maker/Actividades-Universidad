package funcionesincorporadas;

public class subcadenas {
     public static void main(String[] args) {
        var cadena = "Hola Mundo";
        System.out.println("Cadena= " + cadena);
       
        var subcadena1 = cadena.substring(0, 4);
        var subcadena2 = cadena.substring(5, 10);

         System.out.println("Subcadena 1= " + subcadena1);
         System.out.println("Subcadena 2= " + subcadena2);

    }
}

