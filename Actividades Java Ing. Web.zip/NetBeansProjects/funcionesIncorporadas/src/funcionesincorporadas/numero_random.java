package funcionesincorporadas;
import java.util.Random;

public class numero_random {
    public static void main(String[] args) {
        var aleatorio= new Random();
        
        int valorRandom= aleatorio.nextInt(100+1);
        System.out.println(valorRandom);
    }
}
