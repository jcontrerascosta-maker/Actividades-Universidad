package funcionesincorporadas;

public class texto_a_numero {
     public static void main(String[] args) {
        String a= "15", b= "10";
        System.out.println(a+b);
         
        int c= Integer.parseInt(a) + Integer.parseInt(b);
         System.out.println(c);
     }
}
