package funcionesincorporadas;
import java.text.DecimalFormat;

public class redondeo_y_truncamiento {

    public static void main(String[] args){
       
        var numero = 8.5;
        var redondeo = Math.round(numero);
        System.out.println("Valor " + numero + " redondeado " + redondeo);
        
        var patron = "#"; 
        var decimalFormat = new DecimalFormat(patron);
        var truncado = decimalFormat.format(numero);
        System.out.println("Valor " + numero + " truncado " + truncado);
    }
}
