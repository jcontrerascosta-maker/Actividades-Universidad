
package funcionesincorporadas;
public class largo_de_cadenas {

    public static void main(String[] args) {
        var cadena = "Hola Mundo";
        System.out.println("Largo de cadena: " + cadena.length());
        
        for(int i=0; i<cadena.length(); i++){
            System.out.println(i + "-" + cadena.charAt(i));
        }
    }
    
}
