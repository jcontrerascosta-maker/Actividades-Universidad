
package funcionesincorporadas;

public class concatenacion {
     public static void main(String[] args) {
         var cadena1 = "Hola";
         var cadena2 = "Mundo";
         var cadena3 = cadena1 + " " + cadena2;
         System.out.println("Cadena 3= " + cadena3);
         
         int a=2, b=6;
         System.out.println("a+b= " + (a+b));
         
         String c= "11", d= " 10";
         System.out.println(c+d);
     }
    
}
