package GenericsArrayList;
import java.util.*;

public class GenericsArrayList {
    public static void main(String[] args){
        List<String> miLista = new ArrayList<>();
        miLista.add("Lunes");
        miLista.add("Martes");
        miLista.add("Miércoles");
        miLista.add("Jueves");
        miLista.add("Viernes");
        
        String elemento = miLista.get(3);
        System.out.println("Elemento: " + elemento);
        
        imprimir(miLista);
    }
    
    public static void imprimir(Collection<String> coleccion){
        coleccion.forEach(elemento -> {
            System.out.println("Elemento: " + elemento);
        });
    }
}
