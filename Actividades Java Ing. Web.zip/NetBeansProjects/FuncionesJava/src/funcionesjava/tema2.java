package funcionesjava;
import java.util.Scanner;

public class tema2 {
    static int sumar(int a, int b){
        int resultado = a+b;
        return resultado;
    }
    
    public static void main(String[] args){
        var consola = new Scanner(System.in);
        System.out.println("Ingrese el valor del primer argumento: ");
        var arg1 = Integer.parseInt(consola.nextLine());
        System.out.println("Ingrese el valor del segundo argumento: ");
        var arg2 = Integer.parseInt(consola.nextLine());
        
        var resultado = sumar(arg1, arg2);
        System.out.println("El resultado de la suma es: " + resultado);
        
    }
}
