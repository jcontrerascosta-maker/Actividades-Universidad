package funcionesjava;

import java.util.Scanner;

public class tema1 {

    static void saludo(String mensaje){
        System.out.println("Mensaje: " + mensaje);
    }
    
    public static void main(String[] args) {
        System.out.println("Ingrese el mensaje a mostrar: ");
        var mensaje = new Scanner(System.in).nextLine();
        saludo(mensaje);
    }
}
