package funcionesjava;

public class tema5 {
    static void cambiarValor(String parametro){
        parametro= "Chau";
    }
    
    public static void main(String[] args){
        var argumento = "Hola";
        System.out.println("Antes de la funcion= " + argumento);
        cambiarValor(argumento);
        System.out.println("Despues de la funcion: " + argumento);
     }
}
