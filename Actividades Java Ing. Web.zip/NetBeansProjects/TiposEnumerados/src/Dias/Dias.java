
package Dias;

public enum Dias {
    LUNES,
    MARTES,
    MIERCOLES,
    JUEVES, 
    VIERNES,
    SABADO,
    DOMINGO
}
