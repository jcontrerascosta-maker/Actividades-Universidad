
package Continentes;

public class ContinentesTest {
    public static void main(String[] args){
        System.out.println("Continente n°4: " + Continentes.AMERICA);
        System.out.println("Paises en America: " + Continentes.AMERICA.getPaises());
        
        System.out.println("");
        indicarPaises(Continentes.AFRICA);
        
        
        
        System.out.println("");
        imprimirContinentes();
    }
    
    
    
    
    
    public static void indicarPaises(Continentes continentes){
        switch(continentes){
            case AFRICA:
                System.out.println("N° paises en: " + continentes + ": " + continentes.getPaises());

        }
    }
    
    
    
    public static void imprimirContinentes(){
        for(Continentes c: Continentes.values()){
            System.out.println("Continente: " + c + " contiene " + c.getPaises() + " paises");
        }
    }
    
}



