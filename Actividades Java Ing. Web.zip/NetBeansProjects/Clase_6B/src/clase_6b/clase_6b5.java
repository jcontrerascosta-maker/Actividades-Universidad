package clase_6b;
import java.util.Scanner;

public class clase_6b5 {
     public static void main(String[] args) {
         int filas, columnas;
         var consola = new Scanner(System.in);
         
         System.out.println("Ingrese la cantidad de filas: ");
         filas = Integer.parseInt(consola.nextLine());
         
         System.out.println("Ingrese la cantidad de columnas: ");
         columnas = Integer.parseInt(consola.nextLine());
         
         int[][] matriz = new int[filas][columnas];
         
         for(int i=0; i<filas; i++){
             for(int j=0; j<columnas; j++){
                 System.out.println("Ingrese los datos ["+i+"]["+j+"]");
                 matriz[i][j] = Integer.parseInt(consola.nextLine());
             }
         }
         
         for(int i=0; i<filas; i++){
             for(int j=0; j<columnas; j++){
                 System.out.println("Matriz["+i+"]["+j+"]= " + matriz[i][j]);
             }
         }
     }
}
