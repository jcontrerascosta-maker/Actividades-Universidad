package clase_6b;

public class clase_6b2 {  
    public static void main(String[] args) {
        int enteros[] = {1,0,3,0,5};
        System.out.println("Entero 1= " + enteros[0]);
        System.out.println("Entero 2= " + enteros[2]);
        System.out.println("Entero 5= " + enteros[4]);
    }

    
}
