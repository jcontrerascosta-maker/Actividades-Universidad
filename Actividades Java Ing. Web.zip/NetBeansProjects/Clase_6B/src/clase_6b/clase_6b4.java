package clase_6b;
import java.util.Scanner;

public class clase_6b4 {
    public static void main(String[] args) {
     var consola = new Scanner(System.in);   
     
        System.out.println("Inserte el largo del arreglo: ");
        var largo = Integer.parseInt(consola.nextLine());
        
        int[] enteros = new int[largo];
        
        for(int i=0; i<largo; i++){
            System.out.println("Ingrese los valores del arreglo: ["+i+"]");
            enteros[i] = Integer.parseInt(consola.nextLine());
        }
         for(int i=0; i<largo; i++){
            System.out.println("Enteros["+i+"]= " + enteros[i]);
        }
    }

}
