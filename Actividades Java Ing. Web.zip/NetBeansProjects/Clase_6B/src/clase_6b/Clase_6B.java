
package clase_6b;

public class Clase_6B {

    public static void main(String[] args) {
        int[] enteros;
        enteros = new int[5];
        
        enteros[0] = 1;
        enteros[2] = 3;
        enteros[4] = 5;
        
        System.out.println("Entero 1= " + enteros[0]);
        System.out.println("Entero 2= " + enteros[2]);
        System.out.println("Entero 5= " + enteros[4]);

    }
    
}
