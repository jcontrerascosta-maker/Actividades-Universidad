package clase_6b;

public class clase_6b3 {    
    public static void main(String[] args) {
        int enteros[] = {1,0,3,0,5};
        System.out.println("Largo del arreglo " + enteros.length);
        
        for(int i=0; i<enteros.length; i++){
            System.out.println("Enteros["+i+"]= " + enteros[i]);
        }
    }

    
}
