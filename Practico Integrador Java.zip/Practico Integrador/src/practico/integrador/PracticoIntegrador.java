
package practico.integrador;

public class PracticoIntegrador {
    public static void main(String[] args) {         
        Menu.opciones();
    }
    
}
