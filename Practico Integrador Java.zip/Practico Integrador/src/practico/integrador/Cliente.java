
package practico.integrador;

public class Cliente extends Persona{
    private String dni;

    public Cliente(String nombre, String apellido, String dni) {
        super(nombre, apellido);
        this.dni = dni;
    }

    public String getDni() {
        return dni;
    }
    
    @Override
    public String toString() {
        return "Nombre: " + nombre + "\nApellido: " + apellido + "\nIngrese fecha de devolución: ";
    }
}
