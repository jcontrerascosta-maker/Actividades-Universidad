
package practico.integrador;
import java.util.*;

public class Menu {
    public static void opciones(){
        Scanner sc = new Scanner(System.in);
        int op;
        
         do {
            System.out.println("\nBIENVENIDO A NUESTRO SISTEMA DE BIBLIOTECA:");
            System.out.println("------------------------------------------");
            System.out.println("Que quiere hacer");
            System.out.println("1-Cargar préstamo libro");
            System.out.println("2-Listar todos los préstamos");
            System.out.println("3-Listar todos los libros de la biblioteca.");
            System.out.println("4-Terminar de usar el sistema de biblioteca");

            op = sc.nextInt();
            sc.nextLine(); // Limpiar buffer
            
            switch(op){
                case 1 -> {
                    System.out.println("Los libros disponibles son:");
                    for (int i = 0; i < ListasArray.libros.size(); i++) {
                        System.out.println((i + 1) + "-" + ListasArray.libros.get(i));
                    }
                    
                    System.out.print("Seleccione el número de libro: ");
                    int libroId = sc.nextInt() - 1;
                    sc.nextLine();
                    
                    System.out.print("Ingrese su dni: ");
                    String dni = sc.nextLine();
                    System.out.print("Ingrese su apellido: ");
                    String apellido = sc.nextLine();
                    System.out.print("Ingrese su nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Ingrese fecha de devolución: ");
                    String fecha = sc.nextLine();

                    Cliente cliente = new Cliente(nombre, apellido, dni);
                    ListasArray.clientes.add(cliente);
                    Prestamo prestamo = new Prestamo(ListasArray.libros.get(libroId), cliente, fecha);
                    ListasArray.prestamos.add(prestamo);

                    System.out.println("Su prestamo es:\n" + prestamo);
                }
                    
                    
                case 2 -> {
                    System.out.println("Sus pedidos hasta el momento son");
                    ListasArray.prestamos.forEach(p -> {
                        System.out.println(p + "\n");
                    });
                }

                    
                    
                    
                case 3 -> {
                    System.out.println("Los libros disponibles son:");
                    for (int i = 0; i < ListasArray.libros.size(); i++) {
                        System.out.println((i + 1) + "-" + ListasArray.libros.get(i));
                    }
                }
                    
                case 4 -> System.out.println("Adios");
            }
            
         }while(op!=4);
    }
}
