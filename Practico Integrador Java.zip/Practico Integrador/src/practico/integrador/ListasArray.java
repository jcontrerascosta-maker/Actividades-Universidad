
package practico.integrador;
import java.util.*;

public class ListasArray {
    public static ArrayList<Libro> libros = new ArrayList<>();
    public static ArrayList<Cliente> clientes = new ArrayList<>();
    public static ArrayList<Prestamo> prestamos = new ArrayList<>();
    
    
    static{
    //Lista autores
    Autor hernandez = new Autor("Jose", "Hernandez");
    Autor verne = new Autor("Julio", "Verne");
    Autor dickens = new Autor("Charles", "Dickens");
    Autor twain = new Autor("Mark", "Twain");
    
    // Lista de libros hardcodeada
      libros.add(new Libro("Martin Fierro", hernandez));
      libros.add(new Libro("De La Tierra a la Luna", verne));
      libros.add(new Libro("20.000 Leguas de Viaje Submarino", verne));
      libros.add(new Libro("Viaje al Centro de la Tierra", verne));
      libros.add(new Libro("David Copperfield", dickens));
      libros.add(new Libro("Cuento de Navidad", dickens));
      libros.add(new Libro("Tom Sawyer", twain));
      libros.add(new Libro("Huckleberry Fim", twain));
    }
  
    
    
}
    


