
package practico.integrador;

public class Prestamo {
    private Libro libro;
    private Cliente cliente;
    private String fechaDevolucion;
    
    public Prestamo(Libro libro, Cliente cliente, String fechaDevolucion) {
        this.libro = libro;
        this.cliente = cliente;
        this.fechaDevolucion = fechaDevolucion;
    }
    
    @Override
    public String toString() {
        return libro + "\nSocio:\nNombre: " + cliente.getNombre() + "\nApellido: " + cliente.getApellido() + "\nIngrese fecha de devolución: " + fechaDevolucion;
    }
}
