
package practico.integrador;

public class Autor extends Persona {
    public Autor(String nombre, String apellido){
        super(nombre, apellido);
    }
    
     @Override
    public String toString() {
        return nombre + " " + apellido;
    }
}
